// Full flow against a REAL Neon database. Skipped unless TEST_DATABASE_URL is set.
// Use a disposable branch/database. Required env:
//   TEST_DATABASE_URL, TOTP_ENC_KEY (64 hex), SESSION_PEPPER, SPACEFX_WHATSAPP_INVITE=https://chat.example/test
import test from 'node:test';
import assert from 'node:assert/strict';
const url = process.env.TEST_DATABASE_URL;
const skip = !url && 'TEST_DATABASE_URL not set';
if (url) { process.env.DATABASE_URL = url; process.env.REQUIRE_EMAIL_VERIFICATION = 'false'; process.env.SPACEFX_WHATSAPP_INVITE ||= 'https://chat.example/test-invite'; }
const mods = skip ? null : { api: await import('../netlify/functions/api.mjs'), db: await import('../netlify/lib/db.mjs') };
const call = (method, path, { cookie, body } = {}) => mods.api.handle(new Request('https://site.test/api' + path, { method, headers: { 'x-requested-with': 'sky', ...(cookie ? { cookie } : {}), ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined }));
const mk = n => ({ fullName: 'Test ' + n, email: `t${Date.now()}${n}@example.com`, country: 'Nigeria', region: 'Anambra', ageRange: '25-34', language: 'English', whatsapp: '+2348012345678', password: 'TestPassw0rd!!', acceptTerms: true, understandsRequirements: true });
async function signup(n) {
  const u = mk(n);
  const r = await call('POST', '/auth/register', { body: u });
  assert.equal(r.status, 200);
  return { u, cookie: r.headers.get('set-cookie').split(';')[0] };
}

test('SPACEFX invitation is released only after approval, and only to the approved member', { skip }, async () => {
  const a = await signup('a'), b = await signup('b');
  assert.equal((await call('PUT', '/me/platforms', { cookie: a.cookie, body: { platforms: ['spacefx'] } })).status, 200);
  assert.equal((await call('GET', '/spacefx/invite', { cookie: a.cookie })).status, 403);
  const id = (await mods.db.one('SELECT id FROM users WHERE email=$1', [a.u.email.toLowerCase()])).id;
  // a status flip alone (no approved proof) must still be refused
  await mods.db.q("UPDATE platform_access SET status='approved' WHERE user_id=$1 AND platform='spacefx'", [id]);
  assert.equal((await call('GET', '/spacefx/invite', { cookie: a.cookie })).status, 403);
  await mods.db.q("INSERT INTO purchase_proofs(user_id,selar_email,file_key,file_mime,file_sha256,status) VALUES($1,'x@y.co','k','image/png','h','approved')", [id]);
  const ok = await call('GET', '/spacefx/invite', { cookie: a.cookie });
  assert.equal(ok.status, 200);
  assert.equal((await ok.json()).url, process.env.SPACEFX_WHATSAPP_INVITE);
  assert.equal((await call('GET', '/spacefx/invite', { cookie: b.cookie })).status, 403);
});
test('members cannot call admin APIs and cannot grant themselves access', { skip }, async () => {
  const a = await signup('c');
  assert.equal((await call('GET', '/admin/overview', { cookie: a.cookie })).status, 401);
  assert.equal((await call('POST', '/admin/proofs/00000000-0000-0000-0000-000000000000/decision', { cookie: a.cookie, body: { action: 'approve', verifiedInSelar: true } })).status, 401);
  assert.equal((await call('POST', '/me/proofs', { cookie: a.cookie, body: { selarEmail: 'a@b.co', accurate: true, file: { data: Buffer.from('not an image').toString('base64') } } })).status, 400);
});
test('five-question onboarding: validates, resumes, completes once, and never reappears', { skip }, async () => {
  const a = await signup('d');
  const me0 = await (await call('GET', '/auth/me', { cookie: a.cookie })).json();
  assert.equal(me0.onboardingComplete, false);
  assert.equal((await (await call('GET', '/me/onboarding', { cookie: a.cookie })).json()).questions.length, 5);
  // invalid answer and incomplete submission are refused; completion flag stays false
  assert.equal((await call('PUT', '/me/onboarding/draft', { cookie: a.cookie, body: { answers: { path: 'Godlike' }, step: 1 } })).status, 400);
  assert.equal((await call('POST', '/me/onboarding/complete', { cookie: a.cookie, body: { answers: { path: 'Both' } } })).status, 400);
  assert.equal((await (await call('GET', '/auth/me', { cookie: a.cookie })).json()).onboardingComplete, false);
  // partial progress is saved and resumable
  assert.equal((await call('PUT', '/me/onboarding/draft', { cookie: a.cookie, body: { answers: { path: 'Both', level: 'Complete beginner' }, step: 2 } })).status, 200);
  const resumed = await (await call('GET', '/me/onboarding', { cookie: a.cookie })).json();
  assert.equal(resumed.answers.path, 'Both'); assert.equal(resumed.step, 2);
  // all five answers complete it, and the platform choice is applied
  const all = { path: 'Both', level: 'Complete beginner', goal: 'Learn a new skill', hours: '3-5 hours', format: 'Recorded videos' };
  assert.equal((await call('POST', '/me/onboarding/complete', { cookie: a.cookie, body: { answers: all } })).status, 200);
  const me1 = await (await call('GET', '/auth/me', { cookie: a.cookie })).json();
  assert.equal(me1.onboardingComplete, true);
  assert.ok(me1.platforms.filter(p => p.selected).length === 2);
  assert.equal((await (await call('GET', '/me/onboarding', { cookie: a.cookie })).json()).complete, true);
  // the member-facing questionnaire list is gone
  assert.equal((await call('GET', '/me/questionnaires', { cookie: a.cookie })).status, 404);
});
test('member sessions use a browser-session cookie (no Max-Age)', { skip }, async () => {
  const u = mk('e');
  const r = await call('POST', '/auth/register', { body: u });
  const c = r.headers.get('set-cookie');
  assert.ok(/^sid=/.test(c) && !/max-age/i.test(c) && /HttpOnly/i.test(c));
});
