-- 006: community posts (with optional image), comments, reactions, reports, and articles with bookmarks.
-- Runner note: scripts/migrate.mjs splits on ";" at end of line, so every statement ends with ";" + newline and none contains a ";" inside.
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  image_key text,
  image_mime text,
  audience text NOT NULL DEFAULT 'members' CHECK (audience IN ('members','friends')),
  status text NOT NULL DEFAULT 'published' CHECK (status IN ('published','hidden','removed')),
  moderation_note text,
  client_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS posts_feed_idx ON posts (created_at DESC, id DESC) WHERE status = 'published';
CREATE INDEX IF NOT EXISTS posts_author_idx ON posts (author_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS posts_client_uq ON posts (author_id, client_id) WHERE client_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS post_reactions (
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id)
);
CREATE INDEX IF NOT EXISTS post_reactions_user_idx ON post_reactions (user_id, updated_at DESC);
CREATE TABLE IF NOT EXISTS post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 1000),
  status text NOT NULL DEFAULT 'published' CHECK (status IN ('published','removed')),
  client_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS post_comments_post_idx ON post_comments (post_id, created_at, id);
CREATE INDEX IF NOT EXISTS post_comments_author_idx ON post_comments (author_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS post_comments_client_uq ON post_comments (author_id, client_id) WHERE client_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS post_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_type text NOT NULL CHECK (target_type IN ('post','comment')),
  target_id uuid NOT NULL,
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  reason text NOT NULL CHECK (reason IN ('spam','harassment','inappropriate','scam','other')),
  details text,
  snapshot text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','actioned','dismissed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  decided_by uuid REFERENCES users(id) ON DELETE SET NULL,
  UNIQUE (reporter_id, target_type, target_id)
);
CREATE INDEX IF NOT EXISTS post_reports_status_idx ON post_reports (status, created_at DESC);
CREATE TABLE IF NOT EXISTS articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL,
  title text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 160),
  summary text NOT NULL DEFAULT '' CHECK (char_length(summary) <= 300),
  body text NOT NULL DEFAULT '',
  cover_key text,
  category text NOT NULL DEFAULT 'General',
  author_name text NOT NULL DEFAULT 'SN Learning',
  platform text CHECK (platform IN ('ai','spacefx')),
  reading_minutes int NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS articles_slug_uq ON articles (lower(slug));
CREATE INDEX IF NOT EXISTS articles_pub_idx ON articles (published_at DESC, id DESC) WHERE status = 'published';
CREATE TABLE IF NOT EXISTS article_bookmarks (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  article_id uuid NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, article_id)
);
