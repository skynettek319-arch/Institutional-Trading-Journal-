// Runs before first paint (tiny, synchronous, same-origin so it passes the CSP).
// The auth page starts in the "launching" state; this removes it where the launch animation must not play:
// reduced-motion users, a launch already shown in this browser session, and deep links to #signin / #signup / #forgot.
(function () {
  var d = document.documentElement;
  try {
    var skip = window.matchMedia('(prefers-reduced-motion: reduce)').matches
      || sessionStorage.getItem('sn_launch') === '1'
      || /^#(signin|signup|forgot)$/.test(location.hash);
    if (skip) d.classList.remove('launching');
  } catch (e) { /* storage blocked: fall through and play the launch once */ }
})();
