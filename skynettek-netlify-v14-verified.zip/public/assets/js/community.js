// Community feed, Create Post, Explore and Articles. Every action calls the real /api/me/... endpoints (netlify/lib/routes/community.mjs).
// User text is always escaped (esc/nl2br) before it reaches innerHTML, and article bodies arrive as structured blocks, never HTML.
import { $, $$, api, esc, nl2br, msg, clearMsg, modal, confirmBox, busy, icon, fileToBase64, memberLayout } from './app.js';

const ago = d => { const s = (Date.now() - new Date(d)) / 1000; if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago'; if (s < 86400) return Math.floor(s / 3600) + ' h ago'; if (s < 604800) return Math.floor(s / 86400) + ' d ago'; return new Date(d).toLocaleDateString(undefined, { dateStyle: 'medium' }); };
const initial = n => (String(n || '?').trim()[0] || '?').toUpperCase();
const newId = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 14));

/* ---------- accessible tab bar (arrow keys, aria-selected) ---------- */
export function tabBar(el, items, onSelect, start = 0) {
  el.setAttribute('role', 'tablist');
  el.innerHTML = items.map(([k, label, ic], i) => `<button type="button" role="tab" id="tab-${k}" data-k="${k}" aria-selected="${i === start}" tabindex="${i === start ? 0 : -1}">${ic ? icon(ic) : ''}<span>${esc(label)}</span></button>`).join('');
  const tabs = $$('[role=tab]', el);
  const select = (b, focus) => { tabs.forEach(x => { x.setAttribute('aria-selected', String(x === b)); x.tabIndex = x === b ? 0 : -1; }); if (focus) b.focus(); onSelect(b.dataset.k); };
  tabs.forEach((b, i) => { b.onclick = () => select(b); b.onkeydown = e => { const d = { ArrowRight: 1, ArrowLeft: -1 }[e.key]; if (d) { e.preventDefault(); select(tabs[(i + d + tabs.length) % tabs.length], true); } }; });
  onSelect(items[start][0]);
}

/* ---------- post card ---------- */
const postCard = p => `<article class="post" data-id="${esc(p.id)}" aria-label="Post by ${esc(p.author.displayName)}">
  <header class="post-h"><span class="av" aria-hidden="true">${esc(initial(p.author.displayName))}</span>
    <div class="grow"><strong>${esc(p.author.displayName)}</strong><small class="muted">@${esc(p.author.username)} · ${esc(ago(p.createdAt))} · ${p.audience === 'friends' ? 'Friends only' : 'All members'}${p.status === 'hidden' ? ' · Hidden by moderators' : ''}</small></div>
    ${p.mine ? `<button type="button" class="btn-link" data-act="delete">Delete</button>` : `<button type="button" class="btn-link" data-act="report">Report</button>`}</header>
  <p class="post-body">${nl2br(p.body)}</p>
  ${p.imageUrl ? `<img class="post-img" src="${esc(p.imageUrl)}" alt="Photo shared by ${esc(p.author.displayName)}" loading="lazy">` : ''}
  <footer class="post-f">
    <button type="button" class="act" data-act="like" aria-pressed="${p.liked}" aria-label="Like. ${p.likes} likes">${icon('smile')}<span class="n">${p.likes}</span></button>
    <button type="button" class="act" data-act="comments" aria-expanded="false" aria-label="Comments. ${p.comments} comments">${icon('chat')}<span class="n">${p.comments}</span></button>
    <button type="button" class="act" data-act="share" aria-label="Share this post">${icon('send')}<span>Share</span></button>
  </footer><div class="cmts" hidden></div></article>`;
const commentHtml = c => `<div class="cmt" data-cid="${esc(c.id)}"><span class="av sm" aria-hidden="true">${esc(initial(c.author.displayName))}</span><div class="grow"><strong>${esc(c.author.displayName)}</strong> <small class="muted">${esc(ago(c.createdAt))}</small><p>${nl2br(c.body)}</p></div>
  ${c.canRemove ? `<button type="button" class="btn-link" data-act="cdelete">Delete</button>` : ''}${!c.mine ? `<button type="button" class="btn-link" data-act="creport">Report</button>` : ''}</div>`;

const EMPTY = {
  feed: `<div class="empty"><h3>No posts yet</h3><p class="muted">Be the first to share something with the community.</p><a class="btn btn-primary btn-sm" href="/post.html">Create a post</a></div>`,
  mine: `<div class="empty"><h3>You have not posted yet</h3><p class="muted">Share what you are learning. Your posts will appear here.</p><a class="btn btn-primary btn-sm" href="/post.html">Create a post</a></div>`,
  trending: `<div class="empty"><h3>Nothing trending yet</h3><p class="muted">Posts that get likes and comments in the last two weeks show up here.</p></div>`
};

/* ---------- feed ---------- */
export function mountFeed(box, { mode = 'feed', limit = 10, seeAll = null } = {}) {
  box.innerHTML = '<div class="msg" role="status"></div><div class="feed"></div><div class="feed-more"></div>';
  const [note, list, more] = box.children; let cursor = null, busyLoad = false;
  const say = (t, type = 'error') => msg(note, t, type);
  async function load(first) {
    if (busyLoad) return; busyLoad = true; clearMsg(note); more.innerHTML = '';
    if (first) { cursor = null; list.innerHTML = '<p class="muted"><span class="spinner"></span> Loading…</p>'; }
    try {
      const r = await api(`/me/posts?mode=${mode}&limit=${limit}${cursor ? '&cursor=' + encodeURIComponent(cursor) : ''}`);
      if (first) list.innerHTML = '';
      if (first && !r.posts.length) list.innerHTML = EMPTY[mode];
      list.insertAdjacentHTML('beforeend', r.posts.map(postCard).join(''));
      cursor = r.nextCursor;
      if (cursor) { more.innerHTML = '<button type="button" class="btn btn-outline btn-sm">Load more</button>'; more.firstChild.onclick = () => load(false); }
      else if (seeAll && r.posts.length) more.innerHTML = `<a class="btn btn-outline btn-sm" href="${seeAll}">See all</a>`;
    } catch (e) {
      if (first) list.innerHTML = '';
      more.innerHTML = `<p class="muted">${esc(e.message)}</p><button type="button" class="btn btn-outline btn-sm">Try again</button>`; more.lastChild.onclick = () => load(first);
    } finally { busyLoad = false; }
  }
  list.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const card = b.closest('.post'), id = card.dataset.id, act = b.dataset.act;
    if (act === 'like') return like(b, id, say);
    if (act === 'comments') return toggleComments(card, b, say);
    if (act === 'share') return share(id, say);
    if (act === 'delete') { if (!(await confirmBox('Delete this post? This cannot be undone.'))) return; try { await api(`/me/posts/${id}`, { method: 'DELETE' }); card.remove(); if (!list.children.length) list.innerHTML = EMPTY[mode]; } catch (err) { say(err.message); } return; }
    if (act === 'report') return report(id, null, say);
    if (act === 'cdelete') { const c = b.closest('.cmt'); if (!(await confirmBox('Delete this comment?'))) return; try { await api(`/me/comments/${c.dataset.cid}`, { method: 'DELETE' }); c.remove(); bump(card, -1); } catch (err) { say(err.message); } return; }
    if (act === 'creport') return report(id, b.closest('.cmt').dataset.cid, say);
  });
  load(true);
  return { reload: () => load(true), prepend: html => { list.querySelector('.empty')?.remove(); list.insertAdjacentHTML('afterbegin', html); } };
}
export { postCard };

const setLike = (b, on, n) => { b.setAttribute('aria-pressed', String(on)); b.querySelector('.n').textContent = n; b.setAttribute('aria-label', `Like. ${n} likes`); };
async function like(b, id, say) {
  if (b.disabled) return; const on = b.getAttribute('aria-pressed') !== 'true', prev = +b.querySelector('.n').textContent;
  setLike(b, on, Math.max(0, prev + (on ? 1 : -1))); b.disabled = true;           // optimistic, corrected by the server's answer
  try { const r = await api(`/me/posts/${id}/like`, { method: 'POST', body: { on } }); setLike(b, r.liked, r.likes); }
  catch (e) { setLike(b, !on, prev); say(e.message); } finally { b.disabled = false; }
}
const bump = (card, d) => { const b = card.querySelector('[data-act=comments] .n'); b.textContent = Math.max(0, +b.textContent + d); b.parentElement.setAttribute('aria-label', `Comments. ${b.textContent} comments`); };
async function share(id, say) {
  const url = `${location.origin}/community.html#post-${id}`;
  try { if (navigator.share) await navigator.share({ title: 'SN Learning Platform', url }); else { await navigator.clipboard.writeText(url); say('Link copied. Only members who are allowed to see this post can open it.', 'success'); } }
  catch (e) { if (e.name !== 'AbortError') say('Could not share. Copy the address from your browser instead.'); }
}
function report(postId, commentId, say) {
  const m = modal(`<h3>Report ${commentId ? 'comment' : 'post'}</h3><form id="rf2" novalidate><div class="field"><label for="rr">Reason</label><select id="rr"><option value="spam">Spam</option><option value="harassment">Harassment or bullying</option><option value="inappropriate">Inappropriate content</option><option value="scam">Scam or fraud</option><option value="other">Something else</option></select></div>
    <div class="field"><label for="rd">Details (optional)</label><textarea id="rd" rows="3" maxlength="500"></textarea></div><div class="msg" id="rm" role="status"></div>
    <div class="actions"><button class="btn btn-primary" type="submit">Send report</button><button class="btn btn-outline" type="button" id="rc">Cancel</button></div></form>`);
  $('#rc', m).onclick = () => m.close();
  $('#rf2', m).onsubmit = e => { e.preventDefault(); busy(e.submitter || $('button[type=submit]', m), async () => {
    try { await api(`/me/posts/${postId}/report`, { method: 'POST', body: { reason: $('#rr', m).value, details: $('#rd', m).value, commentId } }); m.close(); say('Thank you. Our team will review this report.', 'success'); }
    catch (err) { msg($('#rm', m), err.message); } }); };
}
async function toggleComments(card, btn, say) {
  const box = card.querySelector('.cmts'), open = btn.getAttribute('aria-expanded') !== 'true';
  btn.setAttribute('aria-expanded', String(open)); box.hidden = !open; if (!open || box.dataset.ready) return; box.dataset.ready = '1';
  const id = card.dataset.id; let cursor = null;
  box.innerHTML = `<div class="cmt-list"></div><div class="cmt-more"></div>
    <form class="cmt-form" novalidate><label class="sr-only" for="c-${esc(id)}">Write a comment</label><textarea id="c-${esc(id)}" rows="2" maxlength="1000" placeholder="Write a comment…"></textarea><button class="btn btn-primary btn-sm" type="submit">Send</button></form><div class="msg" role="status"></div>`;
  const list = $('.cmt-list', box), more = $('.cmt-more', box), form = $('.cmt-form', box), note = $('.msg', box);
  async function load() {
    more.innerHTML = '<span class="spinner"></span>';
    try { const r = await api(`/me/posts/${id}/comments?limit=20${cursor ? '&cursor=' + encodeURIComponent(cursor) : ''}`); list.insertAdjacentHTML('beforeend', r.comments.map(commentHtml).join('')); cursor = r.nextCursor; more.innerHTML = cursor ? '<button type="button" class="btn-link">Load more comments</button>' : (list.children.length ? '' : '<p class="muted small">No comments yet. Start the conversation.</p>'); if (cursor) more.firstChild.onclick = load; }
    catch (e) { more.innerHTML = `<p class="muted small">${esc(e.message)}</p>`; }
  }
  let attempt = newId();   // one id per attempt: a retry or double tap can never create two comments
  form.onsubmit = e => { e.preventDefault(); const ta = $('textarea', form), body = ta.value.trim(); if (!body) return; busy($('button', form), async () => {
    try { const r = await api(`/me/posts/${id}/comments`, { method: 'POST', body: { body, clientId: attempt } }); attempt = newId(); ta.value = ''; clearMsg(note);
      if (r.comment) { more.querySelector('p')?.remove(); list.insertAdjacentHTML('beforeend', commentHtml(r.comment)); } bump(card, 1); }
    catch (err) { msg(note, err.message); } }); };
  list.addEventListener('click', () => {}); load();
}

/* ---------- pages ---------- */
const page = document.body.dataset.page;

async function communityPage() {
  const me = await memberLayout(); if (!me) return;
  const out = $('#cout'); let feed;
  tabBar($('#ctabs'), [['feed', 'Community Feed', 'grid'], ['mine', 'My Posts', 'pen'], ['trending', 'Trending', 'fire']], k => { feed = mountFeed(out, { mode: k }); });
  const m = /^#post-([0-9a-f-]{36})$/i.exec(location.hash);
  if (m) try { const r = await api(`/me/posts/${m[1]}`); $('#pin').innerHTML = `<h2 class="small muted">Shared post</h2>${postCard(r.post)}`; $('#pin').addEventListener('click', e => { const b = e.target.closest('[data-act=like]'); if (b) like(b, m[1], t => msg($('#cmsg'), t)); }); } catch (e) { msg($('#cmsg'), e.message); }
}

const MAX_PHOTO = 1.8 * 1024 * 1024;
async function shrink(file) {
  if (!/^image\/(png|jpe?g|webp)$/.test(file.type)) throw new Error('Choose a PNG, JPEG or WEBP photo.');
  const bmp = await createImageBitmap(file), k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k); c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.82));
  if (!blob || blob.size > MAX_PHOTO) throw new Error('That photo is too large even after shrinking. Please choose a smaller one.');
  return blob;
}
async function postPage() {
  const me = await memberLayout(); if (!me) return;
  const f = $('#pf2'), ta = $('#pbody'), count = $('#pcount'), note = $('#pmsg'), pre = $('#ppre'), DRAFT = 'sn_post_draft';
  let photo = null, attempt = newId();      // the same id is reused for retries, so a failed-then-retried post is saved once
  try { ta.value = sessionStorage.getItem(DRAFT) || ''; } catch { /* ignore */ }
  const upd = () => { const n = ta.value.length; count.textContent = `${n} / 2000`; count.classList.toggle('over', n > 2000); try { sessionStorage.setItem(DRAFT, ta.value); } catch { /* ignore */ } };
  ta.addEventListener('input', upd); upd();
  $('#pphoto').onchange = async e => { const file = e.target.files[0]; clearMsg(note); if (!file) return;
    try { photo = await shrink(file); pre.innerHTML = `<img src="${URL.createObjectURL(photo)}" alt="Preview of the photo you are about to post"><button type="button" class="btn btn-outline btn-sm" id="prm">Remove photo</button>`; $('#prm').onclick = () => { photo = null; pre.innerHTML = ''; $('#pphoto').value = ''; }; }
    catch (err) { photo = null; pre.innerHTML = ''; e.target.value = ''; msg(note, err.message); } };
  f.onsubmit = e => { e.preventDefault(); clearMsg(note); const body = ta.value.trim();
    if (!body) return msg(note, 'Write something to post.'); if (body.length > 2000) return msg(note, 'Your post is over 2000 characters.');
    busy($('#psend'), async () => {
      try {
        const payload = { body, audience: $('#paud').value, clientId: attempt };
        if (photo) payload.image = await fileToBase64(new File([photo], 'photo.jpg', { type: 'image/jpeg' }));
        await api('/me/posts', { method: 'POST', body: payload });
        try { sessionStorage.removeItem(DRAFT); } catch { /* ignore */ }
        location.href = '/community.html';
      } catch (err) { msg(note, err.message + ' Your text has been kept, so you can try again.'); }   // text and photo stay on screen
    }); };
}

const cardHtml = a => `<article class="acard"><a class="acover" href="/article.html?slug=${encodeURIComponent(a.slug)}" tabindex="-1" aria-hidden="true">${a.coverUrl ? `<img src="${esc(a.coverUrl)}" alt="" loading="lazy" width="160" height="110">` : `<span class="acover-ph">${icon('book')}</span>`}</a>
  <div class="grow"><small class="muted">${esc(a.category)}${a.platform ? ' · ' + (a.platform === 'ai' ? 'AI Powered Workspace' : 'SPACEFX') : ''}</small>
  <h3><a href="/article.html?slug=${encodeURIComponent(a.slug)}">${esc(a.title)}</a></h3>${a.summary ? `<p class="small muted">${esc(a.summary)}</p>` : ''}
  <small class="muted">By ${esc(a.author)} · ${esc(ago(a.publishedAt))} · ${a.readingMinutes} min read</small></div>
  <button type="button" class="act bm" data-id="${esc(a.id)}" aria-pressed="${a.bookmarked}" aria-label="Save ${esc(a.title)}">${icon('file')}<span>${a.bookmarked ? 'Saved' : 'Save'}</span></button></article>`;
export { cardHtml };
export async function toggleBookmark(b, say) {
  const on = b.getAttribute('aria-pressed') !== 'true'; b.disabled = true;
  try { const r = await api(`/me/articles/${b.dataset.id}/bookmark`, { method: 'POST', body: { on } }); b.setAttribute('aria-pressed', String(r.bookmarked)); b.querySelector('span').textContent = r.bookmarked ? 'Saved' : 'Save'; }
  catch (e) { say(e.message); } finally { b.disabled = false; }
}

async function explorePage() {
  const me = await memberLayout(); if (!me) return;
  const out = $('#eout'), note = $('#emsg'), st = { q: '', category: '', platform: '', saved: false }; let cursor = null, seq = 0;
  async function load(first) {
    const my = ++seq; clearMsg(note);
    if (first) { cursor = null; out.innerHTML = '<p class="muted"><span class="spinner"></span> Loading…</p>'; }
    const qs = new URLSearchParams({ limit: '10' }); if (st.q) qs.set('q', st.q); if (st.category) qs.set('category', st.category); if (st.platform) qs.set('platform', st.platform); if (st.saved) qs.set('saved', '1'); if (cursor) qs.set('cursor', cursor);
    try {
      const r = await api('/me/articles?' + qs); if (my !== seq) return;
      if (first) out.innerHTML = '';
      if (first && !r.articles.length) out.innerHTML = `<div class="empty"><h3>${st.saved ? 'No saved articles yet' : st.q || st.category || st.platform ? 'No articles match your search' : 'No articles published yet'}</h3><p class="muted">${st.saved ? 'Tap Save on an article to keep it here.' : 'Try different words or clear the filters. New articles appear here as soon as they are published.'}</p></div>`;
      out.querySelector('.more')?.remove(); out.insertAdjacentHTML('beforeend', r.articles.map(cardHtml).join(''));
      cursor = r.nextCursor; if (cursor) { out.insertAdjacentHTML('beforeend', '<div class="more"><button type="button" class="btn btn-outline btn-sm">Load more</button></div>'); out.querySelector('.more button').onclick = () => load(false); }
    } catch (e) { if (my === seq) { out.innerHTML = ''; msg(note, e.message); } }
  }
  out.addEventListener('click', e => { const b = e.target.closest('.bm'); if (b) toggleBookmark(b, t => msg(note, t)); });
  let t; $('#esearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { st.q = e.target.value.trim().toLowerCase(); load(true); }, 300); });
  $('#esearch-f').onsubmit = e => { e.preventDefault(); st.q = $('#esearch').value.trim().toLowerCase(); load(true); };
  try { const c = await api('/me/articles/categories'); const sel = $('#ecat'); sel.insertAdjacentHTML('beforeend', c.categories.map(x => `<option value="${esc(x.category)}">${esc(x.category)} (${x.n})</option>`).join('')); } catch { /* filters are optional */ }
  $('#ecat').onchange = e => { st.category = e.target.value; load(true); }; $('#eplat').onchange = e => { st.platform = e.target.value; load(true); };
  $('#esaved').onchange = e => { st.saved = e.target.checked; load(true); };
  mountFeed($('#etrend'), { mode: 'trending', limit: 3 });
  load(true);
}

async function articlePage() {
  const me = await memberLayout(); if (!me) return;
  const out = $('#aout'), slug = new URLSearchParams(location.search).get('slug') || '';
  try {
    const r = await api('/me/articles/' + encodeURIComponent(slug)), a = r.article; document.title = a.title + ' | SN Learning Platform';
    const body = a.blocks.map(b => b.type === 'h' ? `<h2>${esc(b.text)}</h2>` : b.type === 'ul' ? `<ul>${b.items.map(i => `<li>${esc(i)}</li>`).join('')}</ul>` : `<p>${nl2br(b.text)}</p>`).join('');
    out.innerHTML = `<article class="article">${a.coverUrl ? `<img class="acover-lg" src="${esc(a.coverUrl)}" alt="">` : ''}<small class="muted">${esc(a.category)}${a.platform ? ' · ' + (a.platform === 'ai' ? 'AI Powered Workspace' : 'SPACEFX') : ''}</small>
      <h1>${esc(a.title)}</h1><p class="muted">By ${esc(a.author)} · ${new Date(a.publishedAt).toLocaleDateString(undefined, { dateStyle: 'long' })} · ${a.readingMinutes} min read</p>
      <div class="actions"><button type="button" class="act bm" data-id="${esc(a.id)}" aria-pressed="${a.bookmarked}">${icon('file')}<span>${a.bookmarked ? 'Saved' : 'Save'}</span></button><button type="button" class="act" id="ashare">${icon('send')}<span>Share</span></button></div><div class="msg" id="amsg" role="status"></div>
      <div class="article-body">${body}</div></article>
      ${r.related.length ? `<h2 class="small">Keep reading</h2><div class="related">${r.related.map(x => `<a class="card" href="/article.html?slug=${encodeURIComponent(x.slug)}"><small class="muted">${esc(x.category)}</small><br><strong>${esc(x.title)}</strong><br><small class="muted">${x.readingMinutes} min read</small></a>`).join('')}</div>` : ''}`;
    $('.bm', out).onclick = e => toggleBookmark(e.currentTarget, t => msg($('#amsg'), t));
    $('#ashare').onclick = async () => { const url = location.href; try { if (navigator.share) await navigator.share({ title: a.title, url }); else { await navigator.clipboard.writeText(url); msg($('#amsg'), 'Link copied.', 'success'); } } catch (e) { if (e.name !== 'AbortError') msg($('#amsg'), 'Could not share. Copy the address from your browser.'); } };
  } catch (e) { out.innerHTML = `<div class="empty"><h2>Article not found</h2><p class="muted">${esc(e.message)}</p><a class="btn btn-outline btn-sm" href="/explore.html">Back to Explore</a></div>`; }
}

if (page) await ({ community: communityPage, post: postPage, explore: explorePage, article: articlePage }[page])?.();
