// Shared core: API client, layout, helpers.
// Set to false to open public-site links in the same tab.
export const NEW_TAB_PUBLIC = false;

export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const fmtDate = d => d ? new Date(d).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '';
export const fmtDay = d => d ? new Date(d).toLocaleDateString(undefined, { dateStyle: 'medium' }) : '';
export const nl2br = s => esc(s).replace(/\n/g, '<br>');

export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method, credentials: 'same-origin',
    headers: { 'x-requested-with': 'sky', ...(body ? { 'content-type': 'application/json' } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  const ct = res.headers.get('content-type') || '';
  let data = {};
  if (ct.includes('json')) { try { data = await res.json(); } catch { /* ignore */ } }
  else if (res.ok) return res;
  if (!res.ok) { const e = new Error(data.error || 'Something went wrong. Please try again.'); e.status = res.status; e.data = data; throw e; }
  return data;
}
// Admin calls: transparently asks for the password again when the server requires re-authentication.
export async function adminApi(path, opts) {
  try { return await api(path, opts); }
  catch (e) {
    if (e.data?.code === 'reauth') {
      const pw = await askPassword();
      if (!pw) throw new Error('Action cancelled');
      await api('/admin/reauth', { method: 'POST', body: { password: pw } });
      return api(path, opts);
    }
    if (e.status === 401 && !path.startsWith('/admin/login') && !path.startsWith('/admin/totp')) { location.href = '/admin-login.html'; }
    throw e;
  }
}

export function msg(el, text, type = 'error') { if (!el) return; el.className = 'msg show ' + type; el.textContent = text; el.setAttribute('role', type === 'error' ? 'alert' : 'status'); }
export function clearMsg(el) { if (el) { el.className = 'msg'; el.textContent = ''; } }
export async function busy(btn, fn) {
  const label = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Working…';
  try { return await fn(); } finally { btn.disabled = false; btn.innerHTML = label; }
}
export function modal(html) {
  const bg = document.createElement('div'); bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  bg.addEventListener('mousedown', e => { if (e.target === bg) close(); });
  document.addEventListener('keydown', onKey);
  document.body.append(bg);
  bg.close = close;
  const first = $('input,textarea,select,button', bg); first?.focus();
  return bg;
}
export function askPassword() {
  return new Promise(res => {
    const m = modal(`<h3>Confirm your password</h3><p class="muted">This is a sensitive action. Re-enter your password to continue.</p>
      <form id="rp"><div class="field"><label for="rpw">Password</label><input id="rpw" type="password" autocomplete="current-password" required></div>
      <div class="msg" id="rpm"></div><div class="actions"><button class="btn btn-primary">Confirm</button><button type="button" class="btn btn-outline" id="rpc">Cancel</button></div></form>`);
    $('#rpc', m).onclick = () => { m.close(); res(null); };
    $('#rp', m).onsubmit = e => { e.preventDefault(); const v = $('#rpw', m).value; m.close(); res(v); };
  });
}
export const confirmBox = text => new Promise(res => {
  const m = modal(`<h3>Please confirm</h3><p>${esc(text)}</p><div class="actions"><button class="btn btn-danger" id="cy">Yes, continue</button><button class="btn btn-outline" id="cn">Cancel</button></div>`);
  $('#cy', m).onclick = () => { m.close(); res(true); }; $('#cn', m).onclick = () => { m.close(); res(false); };
});

let contentCache;
export async function loadContent() { return contentCache ??= await api('/public/content').catch(() => ({ settings: {}, ebooks: [], announcements: [], categories: [] })); }
export async function whoami() { try { const r = await api('/auth/me'); return r.user ? r : null; } catch { return null; } }

export const statusLabel = s => ({ pending: 'Pending', available: 'Available', reversed: 'Reversed', processing: 'Processing', paid: 'Paid', failed: 'Failed', completed: 'Completed', draft: 'Draft', published: 'Published', not_selected: 'Not selected', not_started: 'Not started', in_progress: 'In progress', proof_submitted: 'Proof submitted', awaiting_review: 'Awaiting review', approved: 'Approved', rejected: 'Rejected', suspended: 'Suspended', resubmit_requested: 'Resubmission requested', revoked: 'Access revoked', awaiting_payment: 'Awaiting payment', open: 'Open', upcoming: 'Upcoming', closed: 'Closed' }[s] || s);
export const badge = s => `<span class="status-tag s-${esc(s)}">${esc(statusLabel(s))}</span>`;

const IC = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  calendar: '<rect x="3" y="4" width="18" height="17" rx="3"/><path d="M8 2v4M16 2v4M3 10h18"/>',
  book: '<path d="M2 5c3-1.5 7-1.5 10 1 3-2.5 7-2.5 10-1v14c-3-1.5-7-1.5-10 1-3-2.5-7-2.5-10-1z"/><path d="M12 6v14"/>',
  bell: '<path d="M6 9a6 6 0 1112 0c0 6 2 7 2 7H4s2-1 2-7"/><path d="M10 20a2 2 0 004 0"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c3 0 5 1.5 5 4.5"/>',
  help: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M5.6 5.6l3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9"/>',
  logout: '<path d="M9 4H5a2 2 0 00-2 2v12a2 2 0 002 2h4"/><path d="M16 8l4 4-4 4M20 12H9"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>', compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 00-4 10.5c.7.7 1 1.5 1 2.5h6c0-1 .3-1.8 1-2.5A6 6 0 0012 3z"/>', crown: '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
  fire: '<path d="M12 3c1 3 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>', pen: '<path d="M4 20l4-1 11-11-3-3L5 16z"/>', arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>', close: '<path d="M6 6l12 12M18 6L6 18"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  wallet: '<rect x="2" y="5" width="20" height="14" rx="3"/><path d="M2 10h20M6 15h4"/>',
  megaphone: '<path d="M3 11v3a1 1 0 001 1h3l8 4V6L7 10H4a1 1 0 00-1 1z"/><path d="M19 9a4 4 0 010 6"/>',
  file: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5M9 13h7M9 17h7"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 018 0v3"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5L16 9.5"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  trend: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 8l9 6 9-6"/>',
  clipboard: '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h4"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>', cog: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  play: '<circle cx="12" cy="12" r="9"/><path d="M10 8.5l6 3.5-6 3.5z"/>', gift: '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M5 12v9h14v-9M12 8v13M12 8c-2-4-6-3-5 0M12 8c2-4 6-3 5 0"/>',
  send: '<path d="M3 11l18-8-8 18-2-8z"/>', smile: '<circle cx="12" cy="12" r="9"/><path d="M8 14c1 1.5 2.3 2 4 2s3-.5 4-2M9 9.5v.5M15 9.5v.5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>', receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>'
};
const icon = n => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${IC[n] || ''}</svg>`;
export { icon };
const LOGO = '<img class="logo-mark" src="/assets/img/sn-icon-192.webp" alt="" width="36" height="36">'; // the SN Learning Platform icon, always shown whole
const BRAND = 'SN Learning';
const initial = s => (String(s || '?').trim()[0] || '?').toUpperCase();

function drawerControls(menuBtn) {
  const set = open => { document.body.classList.toggle('nav-open', open); menuBtn?.setAttribute('aria-expanded', String(open)); };
  menuBtn?.addEventListener('click', () => { document.body.classList.add('nav-anim'); set(!document.body.classList.contains('nav-open')); });
  $('.nav-bg')?.addEventListener('click', () => set(false));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') set(false); });
  return set;
}

// Public pages: simple top bar, side drawer on phones, no footer.
export async function publicLayout() {
  const me = await whoami();
  const page = location.pathname;
  const links = [['/', 'Sign in or join', 'home'], ['/ai-powered-workspace.html', 'AI Powered Workspace', 'cpu'], ['/spacefx.html', 'SPACEFX', 'trend'], ['/contact.html', 'Help and support', 'help']];
  const cur = h => (page === h ? 'aria-current="page"' : '');
  const cta = me ? '<a class="btn btn-primary btn-sm" href="/dashboard.html">My dashboard</a>' : '<a class="btn btn-outline btn-sm" href="/#signin">Sign in</a> <a class="btn btn-primary btn-sm" href="/#signup">Get started</a>';
  $('#hdr').innerHTML = `<header class="pub-top"><div class="container in"><a class="brand" href="/">${LOGO}<span>${BRAND}</span></a>
    <nav class="pub-links" aria-label="Main">${links.map(([h, t]) => `<a href="${h}" ${cur(h)}>${t}</a>`).join('')}${cta}</nav>
    <button type="button" class="icon-btn menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="pubDrawer">${icon('menu')}</button></div></header>
    <div class="nav-bg"></div>
    <nav class="pub-drawer" id="pubDrawer" aria-label="Menu"><div style="display:flex;justify-content:space-between;align-items:center;padding:.2rem .4rem .8rem"><span class="brand">${LOGO}<span>${BRAND}</span></span><button type="button" class="icon-btn" id="menuClose" aria-label="Close menu">${icon('close')}</button></div>
    ${links.map(([h, t, i]) => `<a href="${h}" ${cur(h)}>${icon(i)}<span>${t}</span></a>`).join('')}
    ${me ? '<a class="btn btn-primary" href="/dashboard.html">My dashboard</a>' : '<a class="btn btn-primary" href="/#signup">Get started</a><a class="btn btn-outline" href="/#signin">Sign in</a>'}</nav>`;
  const set = drawerControls($('#menuBtn'));
  $('#menuClose')?.addEventListener('click', () => set(false));
  const f = $('#ftr'); if (f) f.remove(); // no footers anywhere
  const m = $('#main'); if (m && !m.hasAttribute('tabindex')) m.setAttribute('tabindex', '-1');
  return me;
}

export function fixLinks(root = document) {
  if (!NEW_TAB_PUBLIC) return;
  $$('a[href]', root).forEach(a => {
    const h = a.getAttribute('href');
    if (!h || h.startsWith('#') || h.startsWith('mailto:') || h.startsWith('tel:') || a.hasAttribute('data-same-tab') || a.closest('.shell') || a.closest('.modal')) return;
    a.target = '_blank'; a.rel = 'noopener noreferrer';
  });
}

// Every private page calls this. Signed-out visitors go to the sign-in screen; members who have not finished the
// one-time onboarding are sent there first, and members who have finished it can never open it again.
export async function requireMember() {
  const me = await whoami();
  if (!me?.user) { location.href = '/'; return null; }
  const onOnboarding = document.body.dataset.page === 'onboarding';
  if (!me.onboardingComplete && !onOnboarding) { location.href = '/onboarding.html'; return null; }
  if (me.onboardingComplete && onOnboarding) { location.href = '/dashboard.html'; return null; }
  return me;
}

// App shell for signed-in pages: top bar + side navigation (drawer on phones, fixed on desktop). No footer.
function buildShell({ home, name, sub, items, onLogout, badges, bottom }) {
  const cur = location.pathname;
  const box = $('.dash') || $('.shell');
  box.classList.remove('dash'); box.classList.add('shell');
  $('#hdr').innerHTML = `<header class="app-top"><div class="in"><button type="button" class="icon-btn menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="side">${icon('menu')}</button>
    <a class="brand" href="${home}">${LOGO}<span>${BRAND}</span></a><span class="grow"></span>
    <a class="icon-btn" href="/notifications.html" aria-label="Notifications" id="bellBtn">${icon('bell')}<span class="dot" id="bellDot" hidden></span></a>
    <a class="avatar" href="${home === '/admin.html' ? '/admin-security.html' : '/settings.html'}" aria-label="Settings">${esc(initial(name))}</a></div></header>`;
  const side = $('#side');
  side.setAttribute('aria-label', 'Side navigation');
  side.innerHTML = `<div class="who"><b>${esc(name)}</b><span>${esc(sub)}</span></div>
    <nav class="sidenav" aria-label="Menu">${items.map(i => `<a href="${i.href}" ${cur === i.href ? 'aria-current="page"' : ''}>${icon(i.icon)}<span>${i.label}</span>${i.badge ? `<span class="badge" data-badge="${i.badge}" hidden></span>` : ''}</a>`).join('')}</nav>
    <button type="button" class="logout-btn" id="logoutBtn">${icon('logout')}<span>Log out</span></button>`;
  document.body.insertAdjacentHTML('beforeend', '<div class="nav-bg"></div>');
  const set = drawerControls($('#menuBtn'));
  $$('.sidenav a', side).forEach(a => a.addEventListener('click', () => set(false)));
  $('#logoutBtn').onclick = onLogout;
  if (bottom) {
    // Mobile bottom navigation (hidden above 900px by CSS): Home, Friends, Explore, Post, Messages, More. Every item is a real page.
    const on = i => (i.match || [i.href]).includes(cur) ? 'aria-current="page"' : '';
    document.body.classList.add('has-bnav');
    const cell = i => {
      const inner = `${i.main ? `<span class="bn-disc">${icon(i.icon)}</span>` : icon(i.icon)}<span>${i.label}</span>${i.badge ? `<span class="badge" data-badge="${i.badge}" hidden></span>` : ''}`;
      const cls = i.main ? 'class="bn-main"' : '';
      return i.action ? `<button type="button" ${cls} data-bn="${i.action}" ${i.action === 'more' ? 'aria-controls="side" aria-haspopup="true"' : 'aria-haspopup="dialog"'}>${inner}</button>` : `<a href="${i.href}" ${on(i)} ${cls}>${inner}</a>`;
    };
    document.body.insertAdjacentHTML('beforeend', `<nav class="bnav" aria-label="Primary">${bottom.map(cell).join('')}</nav>`);
    $('[data-bn="more"]')?.addEventListener('click', () => $('#menuBtn')?.click());
  }
  const f = $('#ftr'); if (f) f.remove(); // no footers anywhere
  const m = $('main', box); if (m) m.classList.add('main');
  if (badges) api('/me/social-summary').then(s2 => {
    const put = (k, n) => { if (n > 0) $$(`[data-badge="${k}"]`).forEach(el => { el.textContent = n > 99 ? '99+' : n; el.setAttribute('aria-label', `${el.textContent} new`); el.hidden = false; }); };
    put('friends', s2.pendingIn); put('unread', s2.unread);
    if (s2.notifications > 0) { const d = $('#bellDot'); d.textContent = s2.notifications > 9 ? '9+' : s2.notifications; d.hidden = false; }
  }).catch(() => {});
}

const MEMBER_BOTTOM = [
  { href: '/dashboard.html', label: 'Home', icon: 'home' },
  { href: '/friends.html', label: 'Friends', icon: 'users', badge: 'friends' },
  { href: '/explore.html', label: 'Explore', icon: 'compass', match: ['/explore.html', '/article.html'] },
  { href: '/post.html', label: 'Post', icon: 'plus', main: true, match: ['/post.html', '/community.html'] },
  { href: '/chat.html', label: 'Messages', icon: 'chat', badge: 'unread' },
  { action: 'more', label: 'More', icon: 'menu' }
];
const MEMBER_NAV = [
  { href: '/dashboard.html', label: 'Home', icon: 'home' },
  { href: '/community.html', label: 'Community', icon: 'grid' },
  { href: '/explore.html', label: 'Explore and articles', icon: 'compass' },
  { href: '/trainings.html', label: 'Classes and events', icon: 'calendar' },
  { href: '/friends.html', label: 'Friends', icon: 'users', badge: 'friends' },
  { href: '/chat.html', label: 'Messages', icon: 'chat', badge: 'unread' },
  { href: '/wallet.html', label: 'Wallet and referrals', icon: 'wallet' },
  { href: '/store.html', label: 'Ebook store', icon: 'book' },
  { href: '/learn.html', label: 'AI lessons', icon: 'play' },
  { href: '/notifications.html', label: 'Notifications', icon: 'bell' },
  { href: '/contact.html', label: 'Help and support', icon: 'help' },
  { href: '/settings.html', label: 'Settings', icon: 'cog' }
];
export async function memberLayout() {
  const me = await requireMember(); if (!me) return null;
  buildShell({ home: '/dashboard.html', name: me.user.fullName || me.user.email, sub: me.user.email, items: MEMBER_NAV, badges: true, bottom: MEMBER_BOTTOM,
    onLogout: async () => { try { await api('/auth/logout', { method: 'POST' }); } finally { location.href = '/'; } } });
  return me;
}

const ADMIN_NAV = [
  { href: '/admin.html', label: 'Overview', icon: 'grid', perm: 'overview' },
  { href: '/admin-members.html', label: 'Members', icon: 'users', perm: 'members:read' },
  { href: '/admin-proofs.html', label: 'Purchase verification', icon: 'shield', perm: 'proofs:read' },
  { href: '/admin-enrollments.html', label: 'Class enrolments', icon: 'receipt', perm: 'enroll:read' },
  { href: '/admin-programs.html', label: 'Classes, events and notices', icon: 'megaphone', perm: 'trainings:write' },
  { href: '/admin-questionnaires.html', label: 'Questionnaires', icon: 'clipboard', perm: 'questionnaires:list' },
  { href: '/admin-store.html', label: 'Ebook store', icon: 'book', perm: 'store:write' },
  { href: '/admin-wallet.html', label: 'Wallet and withdrawals', icon: 'wallet', perm: 'wallet:read' },
  { href: '/admin-moderation.html', label: 'Reports and moderation', icon: 'info', perm: 'moderation:read' },
  { href: '/admin-community.html', label: 'Community moderation', icon: 'users', perm: 'community:moderate' },
  { href: '/admin-articles.html', label: 'Articles', icon: 'file', perm: 'content:write' },
  { href: '/admin-content.html', label: 'Content', icon: 'file', perm: 'content:write' },
  { href: '/admin-security.html', label: 'Security and settings', icon: 'lock', perm: '*' }
];
export async function adminLayout() {
  let me; try { me = await api('/admin/me'); } catch { location.href = '/admin-login.html'; return null; }
  const has = p => me.perms.includes('*') || me.perms.includes(p);
  buildShell({ home: '/admin.html', name: me.email, sub: me.role.replace('_', ' '), items: ADMIN_NAV.filter(i => i.perm === 'overview' || i.perm === '*' || has(i.perm)),
    onLogout: async () => { try { await api('/admin/logout', { method: 'POST' }); } finally { location.href = '/admin-login.html'; } } });
  return me;
}

export function pager(el, total, size, page, go) {
  const pages = Math.max(1, Math.ceil(total / size));
  el.innerHTML = `<span class="muted small">${total} result${total === 1 ? '' : 's'} · page ${page + 1} of ${pages}</span><button class="btn btn-outline btn-sm" ${page <= 0 ? 'disabled' : ''} data-d="-1">Previous</button><button class="btn btn-outline btn-sm" ${page + 1 >= pages ? 'disabled' : ''} data-d="1">Next</button>`;
  $$('button', el).forEach(b => b.onclick = () => go(page + Number(b.dataset.d)));
}
export function fileToBase64(file) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res({ name: file.name, type: file.type, data: String(r.result).split(',')[1] }); r.onerror = () => rej(new Error('Could not read the file')); r.readAsDataURL(file); });
}
export const COUNTRIES = 'Afghanistan|Albania|Algeria|Andorra|Angola|Antigua and Barbuda|Argentina|Armenia|Australia|Austria|Azerbaijan|Bahamas|Bahrain|Bangladesh|Barbados|Belarus|Belgium|Belize|Benin|Bhutan|Bolivia|Bosnia and Herzegovina|Botswana|Brazil|Brunei|Bulgaria|Burkina Faso|Burundi|Cabo Verde|Cambodia|Cameroon|Canada|Central African Republic|Chad|Chile|China|Colombia|Comoros|Congo (Republic)|Congo (DR)|Costa Rica|Cote d\'Ivoire|Croatia|Cuba|Cyprus|Czechia|Denmark|Djibouti|Dominica|Dominican Republic|Ecuador|Egypt|El Salvador|Equatorial Guinea|Eritrea|Estonia|Eswatini|Ethiopia|Fiji|Finland|France|Gabon|Gambia|Georgia|Germany|Ghana|Greece|Grenada|Guatemala|Guinea|Guinea-Bissau|Guyana|Haiti|Honduras|Hungary|Iceland|India|Indonesia|Iran|Iraq|Ireland|Israel|Italy|Jamaica|Japan|Jordan|Kazakhstan|Kenya|Kiribati|Kuwait|Kyrgyzstan|Laos|Latvia|Lebanon|Lesotho|Liberia|Libya|Liechtenstein|Lithuania|Luxembourg|Madagascar|Malawi|Malaysia|Maldives|Mali|Malta|Marshall Islands|Mauritania|Mauritius|Mexico|Micronesia|Moldova|Monaco|Mongolia|Montenegro|Morocco|Mozambique|Myanmar|Namibia|Nauru|Nepal|Netherlands|New Zealand|Nicaragua|Niger|Nigeria|North Macedonia|Norway|Oman|Pakistan|Palau|Palestine|Panama|Papua New Guinea|Paraguay|Peru|Philippines|Poland|Portugal|Qatar|Romania|Russia|Rwanda|Saint Kitts and Nevis|Saint Lucia|Saint Vincent and the Grenadines|Samoa|San Marino|Sao Tome and Principe|Saudi Arabia|Senegal|Serbia|Seychelles|Sierra Leone|Singapore|Slovakia|Slovenia|Solomon Islands|Somalia|South Africa|South Korea|South Sudan|Spain|Sri Lanka|Sudan|Suriname|Sweden|Switzerland|Syria|Taiwan|Tajikistan|Tanzania|Thailand|Timor-Leste|Togo|Tonga|Trinidad and Tobago|Tunisia|Turkey|Turkmenistan|Tuvalu|Uganda|Ukraine|United Arab Emirates|United Kingdom|United States|Uruguay|Uzbekistan|Vanuatu|Vatican City|Venezuela|Vietnam|Yemen|Zambia|Zimbabwe'.split('|');
export const DIAL = { Nigeria: '+234', Ghana: '+233', Kenya: '+254', 'South Africa': '+27', 'United Kingdom': '+44', 'United States': '+1', Canada: '+1', Cameroon: '+237', Uganda: '+256', Tanzania: '+255', India: '+91', 'United Arab Emirates': '+971', Germany: '+49', France: '+33', Australia: '+61', Rwanda: '+250', Zambia: '+260', Zimbabwe: '+263', Senegal: '+221', "Cote d'Ivoire": '+225' };
export const NG_STATES = ['Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa', 'Benue', 'Borno', 'Cross River', 'Delta', 'Ebonyi', 'Edo', 'Ekiti', 'Enugu', 'FCT Abuja', 'Gombe', 'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina', 'Kebbi', 'Kogi', 'Kwara', 'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun', 'Oyo', 'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara'];
export const AGE_RANGES = ['18-24', '25-34', '35-44', '45-54', '55+'];
export const LANGS = ['English', 'French', 'Igbo', 'Yoruba', 'Hausa', 'Nigerian Pidgin', 'Portuguese', 'Spanish', 'Arabic', 'Other'];
export function embedUrl(u) {
  try {
    const x = new URL(u);
    if (x.hostname.endsWith('youtube.com') && x.searchParams.get('v')) return 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(x.searchParams.get('v'));
    if (x.hostname === 'youtu.be') return 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(x.pathname.slice(1));
    if (x.hostname.endsWith('vimeo.com') && /^\/\d+/.test(x.pathname)) return 'https://player.vimeo.com/video/' + x.pathname.split('/')[1];
  } catch { /* ignore */ }
  return null;
}
