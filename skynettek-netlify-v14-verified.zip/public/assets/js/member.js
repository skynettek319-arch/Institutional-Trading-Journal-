import { tabBar, mountFeed } from './community.js';
import { icon } from './app.js';
import { $, $$, api, esc, msg, clearMsg, busy, memberLayout, loadContent, badge, statusLabel, fmtDate, fmtDay, nl2br, fixLinks, fileToBase64, embedUrl, modal, COUNTRIES, NG_STATES, AGE_RANGES, LANGS, confirmBox } from './app.js';

const page = document.body.dataset.page;
const me = await memberLayout();
if (!me) throw new Error('not signed in');
const plat = (list, p) => list.find(x => x.platform === p) || { selected: false, status: 'not_selected' };
const NEXT = {
  ai: { not_selected: 'Add AI Powered Workspace in your learning interests to start.', not_started: 'Open the AI lessons and start your first lesson.', in_progress: 'Keep going. Continue your next lesson.', suspended: 'Your access is suspended. Contact support.' },
  spacefx: { not_selected: 'Add SPACEFX in your learning interests to begin.', not_started: 'Buy the Forex Trading Mastery ebook on Selar, then submit your proof of purchase.', awaiting_review: 'Your proof is being checked against the Selar order. No action needed.', approved: 'Approved. Use the Request to join SPACEFX button on your dashboard.', rejected: 'Your last submission was not accepted. Read the note below and submit new proof.', suspended: 'Your access is suspended. Contact support.' }
};

async function joinSpacefx(btn, out) {
  const w = window.open('', '_blank');
  try {
    const d = await api('/spacefx/invite');
    if (w) w.location.href = d.url; else out.innerHTML = `<a class="btn btn-primary" href="${esc(d.url)}" target="_blank" rel="noopener noreferrer">Open the invitation</a>`;
  } catch (e) { w?.close(); msg(out, e.message); }
}

const dtf = x => x ? new Date(x).toLocaleString(undefined, { dateStyle: 'full', timeStyle: 'short' }) : 'Date to be announced';
async function joinTraining(id, out) {
  const w = window.open('', '_blank');
  try {
    const d = await api(`/me/trainings/${id}/join`);
    if (w) w.location.href = d.url; else out.innerHTML = `<a class="btn btn-primary" href="${esc(d.url)}" target="_blank" rel="noopener noreferrer">Open the workspace invitation</a>`;
  } catch (e) { w?.close(); msg(out, e.message); }
}
async function payModal(t, done) {
  let d;
  try { d = await api(`/me/trainings/${t.id}/payment`); }
  catch (e) { const m = modal(`<h2>Payment</h2><div class="msg show error">${esc(e.message)}</div><div class="actions"><button class="btn btn-outline" id="x">Close</button></div>`); $('#x', m).onclick = () => m.close(); return; }
  const m = modal(`<h2>Pay for ${esc(d.title)}</h2>
    <div class="paybox"><div class="small muted">Bank</div><strong>${esc(d.bank)}</strong>
      <div class="small muted" style="margin-top:.7rem">Account number</div><div class="copy"><code>${esc(d.accountNumber)}</code><button type="button" class="btn btn-outline btn-sm" id="cp">Copy</button></div>
      <div class="small muted" style="margin-top:.7rem">Account name</div><strong>${esc(d.accountName)}</strong>
      ${d.fee ? `<div class="small muted" style="margin-top:.7rem">Amount to pay</div><strong>${esc(d.fee)}</strong>` : '<p class="small muted" style="margin:.7rem 0 0">Pay the amount announced by the SKY-NET TEK team.</p>'}</div>
    <p class="small">After paying, upload a screenshot of your payment receipt. An administrator checks it against the payment and confirms your place.</p>
    <form id="rf"><div class="row"><div class="field"><label for="rpn">Account name you paid from *</label><input id="rpn" type="text" maxlength="120" required></div><div class="field"><label for="rpa">Amount paid</label><input id="rpa" type="text" maxlength="40"></div></div>
    <div class="row"><div class="field"><label for="rpr">Transaction reference (if shown)</label><input id="rpr" type="text" maxlength="100"></div><div class="field"><label for="rpd">Date paid</label><input id="rpd" type="date" max="${new Date().toISOString().slice(0, 10)}"></div></div>
    <div class="field"><label for="rpf">Receipt screenshot (PNG, JPG or WEBP, up to 4 MB) *</label><input id="rpf" type="file" accept="image/png,image/jpeg,image/webp" required></div>
    <label class="opt"><input type="checkbox" id="rpc" required> <span>I confirm this receipt is genuine and unedited. *</span></label>
    <div class="msg" id="rm"></div><div class="actions"><button class="btn btn-primary" type="submit">Submit receipt</button><button type="button" class="btn btn-outline" id="rx">Pay later</button></div></form>`);
  $('#cp', m).onclick = async e => { try { await navigator.clipboard.writeText(d.accountNumber); e.target.textContent = 'Copied'; } catch { e.target.textContent = d.accountNumber; } };
  $('#rx', m).onclick = () => { m.close(); done(); };
  $('#rf', m).onsubmit = async e => {
    e.preventDefault(); const f = e.target, file = $('#rpf', m).files[0], out = $('#rm', m); clearMsg(out);
    if (!file) return msg(out, 'Choose your receipt screenshot.');
    if (file.size > 4 * 1048576) return msg(out, 'The image must be smaller than 4 MB.');
    await busy($('button[type=submit]', f), async () => {
      try {
        await api(`/me/trainings/${t.id}/payment`, { method: 'POST', body: { payerName: $('#rpn', m).value, amountPaid: $('#rpa', m).value, reference: $('#rpr', m).value, paidOn: $('#rpd', m).value, accurate: $('#rpc', m).checked, file: await fileToBase64(file) } });
        m.close(); done(true);
      } catch (err) { msg(out, err.message); }
    });
  };
}
const trainCard = t => {
  const s = t.enrollment_status; let act = '';
  if (!s) act = t.status === 'closed' ? '' : `<button class="btn btn-primary" data-enrol="${t.id}">Enrol now</button>`;
  else if (['awaiting_payment', 'rejected', 'resubmit_requested'].includes(s)) act = `<button class="btn btn-primary" data-pay="${t.id}">${s === 'awaiting_payment' ? 'Make payment and upload receipt' : 'Upload a new receipt'}</button>`;
  else if (s === 'awaiting_review') act = '<div class="notice small">Your receipt is being checked against the payment. No action needed.</div>';
  else if (s === 'approved') act = t.join_ready ? `<button class="btn btn-primary" data-join="${t.id}">Request to join ${esc(t.workspace_name)}</button>` : '<div class="notice ok small">Your place is confirmed. The workspace link appears here as soon as it is added.</div>';
  else if (s === 'revoked') act = '<div class="notice bad small">Your place was withdrawn. Please contact support.</div>';
  const payW = t.price_ngn && (!s || ['awaiting_payment', 'rejected', 'resubmit_requested'].includes(s)) && t.status !== 'closed' ? `<button class="btn btn-primary" data-wpay="${t.id}" data-price="${t.price_ngn}" data-title="${esc(t.title)}">Pay ₦${Number(t.price_ngn).toLocaleString('en-NG')} from wallet</button>` : '';
  return `<article class="card gold"><div class="small gold-text" style="font-weight:700">${esc(dtf(t.starts_at))}</div><h2 style="font-size:1.25rem;margin:.4rem 0">${esc(t.title)}</h2>${s ? badge(s) : badge(t.status)}
    <p class="small" style="margin-top:.7rem">${esc(t.description || '')}</p><div class="kv">${t.duration_label ? `<span><b>${esc(t.duration_label)}</b></span>` : ''}${t.mode ? `<span>${esc(t.mode)}</span>` : ''}${t.requires_payment ? `<span>Fee: <b>${esc(t.fee_amount || 'announced by the team')}</b></span>` : '<span><b>Free</b></span>'}</div>
    ${['rejected', 'resubmit_requested'].includes(s) && t.note ? `<div class="notice warn small"><strong>Note from the team:</strong> ${esc(t.note)}</div>` : ''}
    <div class="actions">${payW}${act}</div><div class="msg" id="m-${t.id}"></div></article>`;
};
const evCard = e => `<article class="card blue"><div class="small" style="color:var(--color-primary);font-weight:700">${esc(dtf(e.starts_at))}</div><h3 style="margin:.4rem 0">${esc(e.title)}</h3><p class="small">${esc(e.description || '')}</p>${e.location ? `<div class="kv"><span>${esc(e.location)}</span></div>` : ''}${e.link_url ? `<a class="btn btn-outline btn-sm" href="${esc(e.link_url)}" target="_blank" rel="noopener noreferrer">Event link</a>` : ''}</article>`;

const pages = {
  async trainings() {
    let cur = [];
    const load = async () => {
      const d = await api('/me/trainings'); cur = d.trainings;
      $('#tr').innerHTML = d.trainings.length ? d.trainings.map(trainCard).join('') : '<p class="muted">No trainings are open right now. New ones appear here as soon as they are announced.</p>';
      $('#ev').innerHTML = d.events.length ? d.events.map(evCard).join('') : '<p class="muted">No upcoming events yet.</p>';
      const find = id => cur.find(x => x.id === id);
      $$('[data-enrol]').forEach(b => b.onclick = () => busy(b, async () => {
        try { await api(`/me/trainings/${b.dataset.enrol}/enrol`, { method: 'POST' }); await load(); const t = find(b.dataset.enrol); if (t?.enrollment_status === 'awaiting_payment') payModal(t, load); } catch (e) { msg($('#tm'), e.message); }
      }));
      $$('[data-pay]').forEach(b => b.onclick = () => payModal(find(b.dataset.pay), ok => { load(); if (ok) msg($('#tm'), 'Receipt submitted. We will review it and notify you.', 'success'); }));
      $$('[data-wpay]').forEach(b => b.onclick = async () => {
        if (!(await confirmBox(`Pay ₦${Number(b.dataset.price).toLocaleString('en-NG')} from your wallet for "${b.dataset.title}"?`))) return;
        await busy(b, async () => { try { const r = await api(`/me/trainings/${b.dataset.wpay}/pay-wallet`, { method: 'POST' }); await load(); msg($('#tm'), `Payment complete. Reference ${r.reference}. Your place is confirmed.`, 'success'); } catch (e) { msg($('#tm'), e.message); } });
      });
      $$('[data-join]').forEach(b => b.onclick = () => busy(b, () => joinTraining(b.dataset.join, $('#m-' + b.dataset.join))));
    };
    try { await load(); } catch (e) { msg($('#tm'), e.message); }
  },
  async dashboard() {
    const d = await api('/me/dashboard');
    const ai = plat(d.platforms, 'ai'), fx = plat(d.platforms, 'spacefx');
    const pct = d.progress.total ? Math.round(100 * d.progress.done / d.progress.total) : 0;
    const lastRejected = d.proofs.find(p => ['rejected', 'resubmit_requested', 'revoked'].includes(p.status));
    const hr = new Date().getHours();
    $('#greet').textContent = (hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening') + ',';
    $('#welcome').textContent = d.profile?.full_name || me.user.fullName || 'Member';
    // Signing in requires an active account, so a member who can see this page is an active member.
    const pill = $('#hpill'); pill.innerHTML = `${icon('crown')}<span>Active Member</span>`; pill.hidden = false;
    const LINES = ['Better skills. Bigger opportunities. Keep showing up!', 'Small steps every day add up to big results.', 'Learn something new today and use it tomorrow.', 'Progress, not perfection. Keep going.', 'Your future self will thank you for learning today.', 'Ask questions, share answers, grow together.', 'Consistency beats intensity. One lesson at a time.'];
    $('#motiv').innerHTML = `<span class="m-ic">${icon('bulb')}</span><div class="grow"><small>Today's Motivation</small><p>“${esc(LINES[Math.floor(Date.now() / 864e5) % LINES.length])}”</p></div><img class="m-logo" src="/assets/img/sn-icon-192.webp" alt="" width="52" height="52">`;
    $('#cards').innerHTML = `
      <section class="pcard ai" aria-labelledby="h-ai"><div class="pc-top"><img class="pc-logo" src="/assets/img/ai-workspace-logo.webp" alt="" width="64" height="64"><div class="grow"><h2 id="h-ai">AI Powered Workspace</h2><p class="muted small">Tools, learning and productivity</p>${ai.selected ? badge(ai.status) : badge('not_selected')}</div></div>
        <p class="small">${esc(NEXT.ai[ai.status] || '')}</p>
        ${ai.selected ? `<div class="bar" aria-label="Lesson progress"><i style="width:${pct}%"></i></div><p class="small muted">${d.progress.done} of ${d.progress.total} published lessons completed</p><a data-same-tab class="btn btn-primary pc-btn" href="/learn.html">Open lessons ${icon('arrow')}</a>` : `<a data-same-tab class="btn btn-primary pc-btn" href="/settings.html#platforms">Add AI Powered Workspace ${icon('arrow')}</a>`}</section>
      <section class="pcard fx" aria-labelledby="h-fx"><div class="pc-top"><img class="pc-logo" src="/assets/img/spacefx-logo.webp" alt="" width="64" height="64"><div class="grow"><h2 id="h-fx">SPACEFX</h2><p class="muted small">Trading education and resources</p>${fx.selected ? badge(fx.status) : badge('not_selected')}</div></div>
        <p class="small">${esc(NEXT.spacefx[fx.status] || '')}</p>
        ${lastRejected && fx.status === 'rejected' && lastRejected.rejection_reason ? `<div class="notice warn small"><strong>Note from the team:</strong> ${esc(lastRejected.rejection_reason)}</div>` : ''}
        <div id="fx-actions" class="actions">
        ${fx.status === 'approved' ? `<button class="btn btn-primary btn-sm" id="join">Request to join SPACEFX</button>` : ''}
        ${['not_started', 'rejected'].includes(fx.status) ? `<a data-same-tab class="btn btn-primary btn-sm" href="/submit-proof.html">Submit proof of purchase</a>` : ''}
        ${!fx.selected ? `<a data-same-tab class="btn btn-outline btn-sm" href="/settings.html#platforms">Add SPACEFX</a>` : ''}</div><div class="msg" id="jm"></div>
        <a class="btn btn-outline pc-btn" href="/spacefx.html">View Details ${icon('arrow')}</a></section>`;
    // community tabs: all four are live (feed, own posts and trending come from /me/posts; messages from /me/chat/conversations)
    tabBar($('#htabs'), [['feed', 'Community Feed', 'grid'], ['mine', 'My Posts', 'pen'], ['chat', 'Messages', 'chat'], ['trending', 'Trending', 'fire']], async k => {
      const box = $('#hpanel');
      if (k !== 'chat') return mountFeed(box, { mode: k, limit: 5, seeAll: '/community.html' });
      box.innerHTML = '<p class="muted"><span class="spinner"></span> Loading…</p>';
      try {
        const r = await api('/me/chat/conversations'), c = (r.conversations || []).slice(0, 6);
        box.innerHTML = c.length ? `<ul class="conv-list">${c.map(x => `<li><a href="/chat.html?c=${esc(x.id)}"><span class="av" aria-hidden="true">${esc((x.display_name || '?')[0].toUpperCase())}</span><span class="grow"><strong>${esc(x.display_name)}</strong><span class="muted small">${esc((x.last_body || '').slice(0, 80))}</span></span>${x.unread > 0 ? `<span class="badge-n" aria-label="${x.unread} unread">${x.unread}</span>` : ''}</a></li>`).join('')}</ul><a class="btn btn-outline btn-sm" href="/chat.html">Open all messages</a>`
          : `<div class="empty"><h3>No conversations yet</h3><p class="muted">Add a friend and, once they accept, you can message each other.</p><a class="btn btn-primary btn-sm" href="/friends.html">Find friends</a></div>`;
      } catch (e) { box.innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
    });
    api('/me/articles?limit=3').then(r => {
      $('#hart').innerHTML = r.articles.length ? r.articles.map(a => `<a class="art-row" href="/article.html?slug=${encodeURIComponent(a.slug)}">${a.coverUrl ? `<img src="${esc(a.coverUrl)}" alt="" width="64" height="64" loading="lazy">` : `<span class="acover-ph sm">${icon('book')}</span>`}<span><strong>${esc(a.title)}</strong><small class="muted">By ${esc(a.author)} · ${a.readingMinutes} min read</small></span></a>`).join('') : '<p class="muted small">No articles published yet. New articles will appear here.</p>';
    }).catch(() => { $('#hart').innerHTML = '<p class="muted small">Articles could not be loaded right now.</p>'; });
    $('#join')?.addEventListener('click', e => busy(e.target, () => joinSpacefx(e.target, $('#jm'))));
    try {
      const tr = await api('/me/trainings'), mine = tr.trainings.filter(t => t.enrollment_status);
      $('#mytr').innerHTML = mine.length ? mine.map(t => `<div class="card" style="margin-bottom:.8rem"><strong>${esc(t.title)}</strong> ${badge(t.enrollment_status)}<div class="actions" style="margin-top:.6rem"><a data-same-tab class="btn ${t.enrollment_status === 'approved' && t.join_ready ? 'btn-primary' : 'btn-outline'} btn-sm" href="/trainings.html">${t.enrollment_status === 'approved' && t.join_ready ? 'Request to join' : 'Open'}</a></div></div>`).join('') + '<p><a data-same-tab href="/trainings.html">See all trainings</a></p>' : '<p class="muted">You have not enrolled in a training yet. <a data-same-tab href="/trainings.html">See what is open</a>.</p>';
      $('#myev').innerHTML = tr.events.length ? `<div class="grid-2">${tr.events.slice(0, 4).map(evCard).join('')}</div>` : '<p class="muted">No upcoming events yet.</p>';
    } catch { /* optional blocks */ }
    $('#ann').innerHTML = (d.announcements || []).length ? `<h2 class="small" style="margin-top:1rem">Announcements</h2>` + d.announcements.map(a => `<div class="notice"><strong>${esc(a.title)}</strong><br>${nl2br(a.body)}</div>`).join('') : '';
    $('#proofs').innerHTML = d.proofs.length ? `<div class="table-wrap"><table><thead><tr><th>Submitted</th><th>Order reference</th><th>Status</th></tr></thead><tbody>${d.proofs.map(p => `<tr><td>${fmtDate(p.created_at)}</td><td>${esc(p.order_ref || '—')}</td><td>${badge(p.status)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No proof submitted yet.</p>';
    $('#notifs').innerHTML = d.notifications.length ? d.notifications.map(n => `<div class="notice ${n.read ? '' : 'ok'}"><strong>${esc(n.title)}</strong> <span class="small muted">${fmtDate(n.created_at)}</span><br>${esc(n.body)}</div>`).join('') : '<p class="muted">No notifications yet.</p>';
    $('#ebooks').innerHTML = d.ebooks.map(b => `<article class="card book"><img src="${esc(b.cover_path || '')}" alt="Cover of ${esc(b.title)}" loading="lazy" width="160" height="240" style="max-width:160px"><h3 style="font-size:1rem">${esc(b.title)}</h3><a class="btn btn-outline btn-sm" href="${esc(b.selar_url)}" target="_blank" rel="noopener noreferrer">Buy on Selar</a></article>`).join('');
    $('#prefs').innerHTML = `<p class="small">${esc(d.profile?.country || '')}${d.profile?.region ? ', ' + esc(d.profile.region) : ''} · ${esc(d.profile?.language || '')}<br>Schedule: ${esc(d.profile?.schedule || 'not set')}<br><a data-same-tab href="/settings.html#platforms">Update learning platforms</a></p>`;
  },

  async status() {
    const d = await api('/me/dashboard');
    const ai = plat(d.platforms, 'ai'), fx = plat(d.platforms, 'spacefx');
    $('#st').innerHTML = `<div class="grid-2"><div class="card blue"><h2 style="font-size:1.2rem"><img class="plogo-sm" src="/assets/img/ai-workspace-logo.webp" alt="" width="44" height="44"> AI Powered Workspace</h2>${badge(ai.selected ? ai.status : 'not_selected')}<p class="small" style="margin-top:.6rem">${esc(NEXT.ai[ai.status] || '')}</p></div>
      <div class="card gold"><h2 style="font-size:1.2rem"><img class="plogo-sm" src="/assets/img/spacefx-logo.webp" alt="" width="44" height="44"> SPACEFX</h2>${badge(fx.selected ? fx.status : 'not_selected')}<p class="small" style="margin-top:.6rem">${esc(NEXT.spacefx[fx.status] || '')}</p></div></div>
      <p class="small muted">The two platforms are managed separately. AI Powered Workspace access never grants SPACEFX access, and SPACEFX does not require buying the optional AI ebooks.</p>
      <h2 style="margin-top:2rem">Submission history</h2>` +
      (d.proofs.length ? d.proofs.map(p => `<div class="card" style="margin-bottom:1rem"><div>${badge(p.status)} <span class="muted small">Submitted ${fmtDate(p.created_at)}${p.decided_at ? ' · Decided ' + fmtDate(p.decided_at) : ''}</span></div><p class="small" style="margin:.6rem 0 0">Selar email: ${esc(p.selar_email)} · Order: ${esc(p.order_ref || '—')}</p>${p.rejection_reason ? `<div class="notice warn small"><strong>Message from the team:</strong> ${esc(p.rejection_reason)}</div>` : ''}</div>`).join('') : '<p class="muted">You have not submitted proof yet.</p>');
  },

  async notifications() {
    const load = async () => {
      const { notifications } = await api('/me/notifications');
      $('#nl').innerHTML = notifications.length ? notifications.map(n => `<div class="notice ${n.read ? '' : 'ok'}"><strong>${esc(n.title)}</strong> <span class="small muted">${fmtDate(n.created_at)}</span><br>${esc(n.body)}</div>`).join('') : '<p class="muted">You have no notifications. Decisions on your submissions will appear here.</p>';
    };
    await load();
    $('#markread').onclick = async () => { await api('/me/notifications/read', { method: 'POST' }); load(); };
  },

  async account() {
    const d = await api('/me/dashboard'), p = d.profile, f = $('#pf'), m = $('#pm');
    f.fullName.value = p.full_name; f.city.value = p.city || ''; f.whatsapp.value = p.whatsapp;
    f.country.innerHTML = COUNTRIES.map(c => `<option ${c === p.country ? 'selected' : ''}>${esc(c)}</option>`).join('');
    f.ageRange.innerHTML = AGE_RANGES.map(c => `<option ${c === p.age_range ? 'selected' : ''}>${c}</option>`).join('');
    f.language.innerHTML = LANGS.map(c => `<option ${c === p.language ? 'selected' : ''}>${c}</option>`).join('');
    f.region.value = p.region;
    f.onsubmit = async e => { e.preventDefault(); clearMsg(m); await busy($('button', f), async () => { try { await api('/me/profile', { method: 'PUT', body: Object.fromEntries(new FormData(f)) }); msg(m, 'Profile saved.', 'success'); } catch (err) { msg(m, err.message); } }); };
    const pf = $('#pwf'), pm = $('#pwm');
    pf.onsubmit = async e => {
      e.preventDefault(); clearMsg(pm);
      const b = Object.fromEntries(new FormData(pf));
      if (b.newPassword !== b.newPassword2) return msg(pm, 'The new passwords do not match.');
      await busy($('button', pf), async () => { try { await api('/me/password', { method: 'POST', body: { currentPassword: b.currentPassword, newPassword: b.newPassword } }); pf.reset(); msg(pm, 'Password changed. Other devices were signed out.', 'success'); } catch (err) { msg(pm, err.message); } });
    };
    $('#soall').onclick = async () => { if (await confirmBox('Sign out of every device, including this one?')) { await api('/me/sign-out-everywhere', { method: 'POST' }); location.href = '/'; } };
    $('#delreq').onclick = async () => { if (await confirmBox('Request deletion of your account and data? We will review it and confirm by email. Some records may be kept where the law or fraud prevention requires.')) { await api('/me/deletion-request', { method: 'POST' }); msg($('#dm'), 'Your request was sent. We will confirm by email.', 'success'); } };
  },

  async proof() {
    const d = await api('/me/dashboard'), fx = plat(d.platforms, 'spacefx'), c = await loadContent();
    $$('.buy-forex').forEach(a => { a.href = c.settings.selar_forex_url || 'https://selar.com/017j91l781'; a.target = '_blank'; a.rel = 'noopener noreferrer'; });
    const f = $('#xf'), m = $('#xm');
    f.fullName.value = d.profile.full_name; f.accountEmail.value = d.email;
    const block = (text, type = 'info') => { f.hidden = true; $('#state').innerHTML = `<div class="notice ${type === 'ok' ? 'ok' : ''}">${text}</div>`; };
    if (!fx.selected) block('Add SPACEFX to your <a data-same-tab href="/settings.html#platforms">learning platforms</a> before submitting proof.');
    else if (fx.status === 'awaiting_review') block('Your proof is awaiting review. We will notify you here and by email once it has been checked.');
    else if (fx.status === 'approved') block('Your SPACEFX access is approved. Join from your <a data-same-tab href="/dashboard.html">dashboard</a>.', 'ok');
    else if (fx.status === 'suspended') block('Your access is suspended. Please contact support.');
    f.onsubmit = async e => {
      e.preventDefault(); clearMsg(m);
      const file = f.proof.files[0];
      if (!file) return msg(m, 'Attach a screenshot of your Selar purchase confirmation.');
      if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) return msg(m, 'Only PNG, JPEG or WEBP images are accepted.');
      if (file.size > 4 * 1024 * 1024) return msg(m, 'The image is larger than 4 MB. Please upload a smaller screenshot.');
      await busy($('button[type=submit]', f), async () => {
        try {
          await api('/me/proofs', { method: 'POST', body: { selarEmail: f.selarEmail.value, orderRef: f.orderRef.value, purchaseDate: f.purchaseDate.value, notes: f.notes.value, accurate: f.accurate.checked, file: await fileToBase64(file) } });
          f.hidden = true; $('#state').innerHTML = `<div class="notice ok"><strong>Proof submitted.</strong> Status: Awaiting review. An administrator will check it against the actual Selar order. A screenshot alone never approves access. You can follow progress on your <a data-same-tab href="/membership-status.html">membership status</a> page.</div>`;
        } catch (err) { msg(m, err.message); }
      });
    };
    fixLinks();
  },

  async learn() {
    const d = await api('/lessons'), list = $('#lessons'), view = $('#lesson-view');
    if (!d.access) { list.innerHTML = '<div class="notice">AI Powered Workspace is not active on your account. <a data-same-tab href="/settings.html#platforms">Add it in Settings</a> to see lessons.</div>'; return; }
    let only = false;
    const render = () => {
      const rows = d.lessons.filter(l => !only || l.bookmarked);
      if (!d.lessons.length) { list.innerHTML = '<div class="notice">No lessons are published yet. Lessons appear here as soon as they are released. Check the announcements on your dashboard.</div>'; return; }
      list.innerHTML = d.categories.map(c => {
        const ls = rows.filter(l => l.category_id === c.id); if (!ls.length) return '';
        return `<h2 style="font-size:1.25rem;margin-top:1.4rem">${esc(c.name)}</h2>` + ls.map(l => `<button class="card" style="width:100%;text-align:left;margin-bottom:.6rem;cursor:pointer;color:inherit;font:inherit" data-id="${l.id}">${l.completed ? '✓ ' : ''}<strong>${esc(l.title)}</strong>${l.bookmarked ? ' ★' : ''}<br><span class="small muted">${esc(l.summary || '')}</span></button>`).join('');
      }).join('') || '<p class="muted">No saved lessons yet.</p>';
      $$('button[data-id]', list).forEach(b => b.onclick = () => open(b.dataset.id));
    };
    async function open(id) {
      const { lesson: l } = await api('/lessons/' + id);
      const emb = l.video_url ? embedUrl(l.video_url) : null;
      view.innerHTML = `<div class="card gold"><h2>${esc(l.title)}</h2>${l.thumbnail_key ? `<img src="/api/thumb/${esc(l.thumbnail_key)}" alt="" style="max-width:360px;border-radius:8px;margin-bottom:1rem">` : ''}<p class="lead">${esc(l.summary || '')}</p>
        ${l.objectives ? `<h3>Learning objectives</h3><p>${nl2br(l.objectives)}</p>` : ''}
        ${emb ? `<div style="aspect-ratio:16/9;margin:1rem 0"><iframe src="${esc(emb)}" title="${esc(l.title)}" style="width:100%;height:100%;border:0;border-radius:8px" allowfullscreen loading="lazy"></iframe></div>` : l.video_url ? `<p><a class="btn btn-primary" href="${esc(l.video_url)}" target="_blank" rel="noopener noreferrer">Open lesson video</a></p>` : ''}
        ${l.content ? `<div>${nl2br(l.content)}</div>` : ''}
        <div class="actions"><button class="btn btn-primary" id="done">${l.completed ? 'Mark as not complete' : 'Mark as complete'}</button><button class="btn btn-outline" id="bm">${l.bookmarked ? 'Remove bookmark' : 'Save for later'}</button></div><div class="msg" id="lm"></div></div>`;
      view.scrollIntoView({ behavior: 'smooth' });
      const set = async patch => { try { await api(`/lessons/${id}/progress`, { method: 'POST', body: patch }); Object.assign(d.lessons.find(x => x.id === id), patch); render(); open(id); } catch (e) { msg($('#lm'), e.message); } };
      $('#done').onclick = () => set({ completed: !l.completed }); $('#bm').onclick = () => set({ bookmarked: !l.bookmarked });
    }
    $('#only-saved').onchange = e => { only = e.target.checked; render(); };
    render();
  }
};
await pages[page]?.();
fixLinks();
