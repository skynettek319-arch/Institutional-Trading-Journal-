-- 004: one-time five-question onboarding. Members who registered but never finished the old wizard get the new flow once;
-- old questionnaire rows (onboarding_responses, questionnaire_responses) are left untouched for the admin tools.
-- Completion is tracked on the member profile. Draft/final answers live in questionnaire_responses (slug 'onboarding'),
-- so resume-after-sign-in works and the admin questionnaire tools can read them.
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS onboarding_completed_at timestamptz;

-- Existing members who already finished the old onboarding (they picked a platform and/or saved onboarding answers)
-- keep their completed status. They are never asked to repeat it.
UPDATE user_profiles p
   SET onboarding_completed_at = COALESCE(
         (SELECT min(o.submitted_at) FROM onboarding_responses o WHERE o.user_id = p.user_id),
         p.updated_at, now())
 WHERE p.onboarding_completed_at IS NULL
   AND (EXISTS (SELECT 1 FROM onboarding_responses o WHERE o.user_id = p.user_id)
     OR EXISTS (SELECT 1 FROM platform_access a WHERE a.user_id = p.user_id AND a.selected));
