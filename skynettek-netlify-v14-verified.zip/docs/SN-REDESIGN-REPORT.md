# SN Learning Platform: UI/UX transformation report

Scope: enhancement of the existing static-pages + Netlify Functions + Neon app. No backend, database, API, auth or business-rule code was changed.

## 1. What changed
- **Official SN icon** integrated from the supplied upload. Original kept byte-for-byte as `assets/img/sn-icon-source.png` (1254×1254, white surround). Because the upload has a white surround and soft shadow, one derivative was made: the rounded square was cut out with transparent corners (silhouette fill, no redraw, no recolour, nothing cropped inside the icon), giving `sn-icon.png`. From it: `sn-icon-512.webp`/`sn-icon-192.webp` (page use), `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` (icon at 80 % on #071A3D), `apple-touch-icon.png` (180, opaque because iOS masks it itself), `favicon-32.png`.
- **Launch + welcome** (`index.html`, `launch-gate.js`, `launch.js`, `launch.css`, `auth.js`): navy surface, the whole icon (one `<img>`) fades/scales in at centre, then moves up and shrinks into the top of the welcome screen (FLIP: only transform/opacity animate, no layout shift) while the light sheet fades in. Copy: "Welcome to SN Learning Platform" / "Learn. Build Skills. Grow." with **Sign In** and **Create Account**.
- **Auth state**: the existing `whoami()` call decides. Signed in: redirect immediately, no animation. Not signed in: reveal. Session check is capped at 4 s for the UI (a late valid session still redirects). CSS failsafe reveals the page after 6 s if the script stalls. Reduced-motion: no launch at all. Once per browser session; deep links (`/#signin`, `/#signup`, `/#forgot`, `/?ref=CODE#signup`) skip the welcome step; Back returns to it.
- **Design tokens** in `style.css` (palette, radii, shadows, spacing, z-index, motion, bottom-nav height). Legacy `--color-*` names were kept and remapped so every existing page picks up the palette. Gold remains only for SPACEFX-style cards and payment notices.
- **App shell**: navy top bar with the SN icon and "SN Learning"; **mobile bottom navigation** (Home, Friends, Learn, Messages, Wallet) with unread badges, active state not colour-only, safe-area padding; hidden on desktop and while a chat conversation is open. The existing drawer holds the secondary destinations. Home got a greeting hero.
- Fixed two existing glitches found on the way: the mobile drawer visibly slid away on every page load, and an empty sidebar column was reserved on phones before JS ran.

## 2. Architecture findings
Static multi-page site (`public/*.html`, ES modules), one Netlify Function API (`netlify/functions/api.mjs`), Neon Postgres, cookie sessions with CSRF header, strict CSP (`script-src 'self'`, so no inline scripts; the launch gate is a tiny external file). No framework, no build step, no service worker, no Google sign-in (Google Authenticator is only admin 2FA).

## 3. Files
Created: `assets/js/launch.js`, `launch-gate.js`, `assets/css/launch.css`, `tests/brand.test.mjs`, this report, icon derivatives in `assets/img/`.
Modified: `index.html`, `onboarding.html`, `dashboard.html`, `platforms.html`, `404.html`, `admin-login.html`, `manifest.webmanifest`, `assets/js/app.js`, `auth.js`, `member.js`, `money.js`, `public.js`, `assets/css/style.css`, `auth.css`, and the `<head>` (favicons, og:image, title suffix, theme-color) of every page.

## 4. Branding audit (verified by test)
No page or script references `sky-net-tek-logo.webp` or `sky-net-tek-mark.webp`; the files remain on disk. The header wordmark "SKY-NET TEK" is gone from the UI (now "SN Learning"). SPACEFX and AI Powered Workspace logos are untouched and still used on their pages/cards. Legal and About copy that names the company as a legal entity was left as written.

## 5. Feature integration: what is and is not built
| Area | Status |
|---|---|
| Sign in / register / forgot / verify / onboarding | Existing endpoints and fields unchanged; new front screen only |
| Home | Greeting, learning progress, AI Workspace and SPACEFX cards (official logos), announcements, events, notifications, wallet/referral summary, quick actions |
| Friends, Messages, Wallet, referrals, store, trainings, notifications | Existing pages, existing services; now inherit tokens, top bar and bottom nav. Not redesigned screen by screen |
| **Community feed, posts, comments, reactions, create-post, articles, bookmarks, profile with posts** | **Not built.** There are no tables or endpoints for them. The bottom-nav centre button is Learn, not Post, so nothing pretends to exist. Needs a new migration, API routes with authorization, moderation and media validation |
| PWA | Manifest + icons updated. No service worker added (deliberately: nothing private or financial is cached). Installability not tested on a device |

## 6. Test report (what was actually run)
- `node --test` on the files that run without installed packages: **28 passed, 0 failed** (7 unit, 4 onboarding, 8 questionnaires, 9 new brand/launch/manifest/CSP/auth-wiring/contrast tests).
- Real Chromium (Playwright) against a static server with mocked `/api`: launch frames (icon centred then moved up, final position stable), welcome → sign-in → Back → create-account, deep link with `?ref=`, referral chip, reduced-motion (no veil), no replay in the same session, slow session check (welcome revealed at 4.7 s), signed-in user redirected to `/dashboard.html`, mobile bottom nav + badges + current page, drawer, desktop sidebar (bottom nav absent), landscape 667×375, keyboard tab order on welcome, all 46 pages at 390 px and 1280 px: **no missing local assets, no horizontal overflow**.
- **Not run:** `tests/access.test.mjs`, `rewards.test.mjs` and the two Neon integration tests (need `npm install` and a database; no network here). No live sign-in, registration, email, payment, wallet, withdrawal or messaging flow was exercised against a real backend. Screen-reader and real-device (iOS/Android) testing, Lighthouse/performance measurement and PWA install were not done. All mocked-API results prove front-end behaviour only.

## 7. Deployment
No migrations, no new environment variables, no new dependencies. Upload as before (see `docs/DEPLOY.md`). Run `npm install && npm test` in your environment to execute the suites that could not run here. Existing members with the old PWA installed will pick up the new icon after reinstalling.

## 8. Outstanding
1. Decide the community model (feed/posts/articles) before building it; it needs backend work first.
2. Screen-by-screen restyle of Friends, Messages, Wallet and Notifications to match the reference more closely.
3. Review icon rendering on real iOS and Android home screens.
4. Optional: a service worker limited to static assets once you want offline support.


---

## Update 2: Home redesign, Community (posts) and Articles

### Bottom navigation (phones), in this order
Home · Friends · Explore · Post (+) · Messages · More. Friends is where members find each other and send requests; once a request is accepted they can message each other (existing behaviour, unchanged). More opens the side menu (Community, Classes, Wallet, Ebook store, AI lessons, Notifications, Help, Settings). The top bar keeps the "SN Learning" heading.

### Database: migration `006_community_articles.sql` (new, additive only)
Tables: `posts`, `post_reactions`, `post_comments`, `post_reports`, `articles`, `article_bookmarks`, plus 10 indexes. Nothing existing is altered or dropped. **Run `npm run migrate` against the database before deploying the new code**; the code needs these tables.

### API (`netlify/lib/routes/community.mjs`, registered in `api.mjs`)
Members: list posts (feed, my posts, trending) with keyset pagination; create post (text up to 2000 characters, optional PNG/JPEG/WEBP up to 2 MB, audience All members or Friends only); delete own post; like/unlike; comments (list, add, delete); report a post or comment; articles (search, category, learning path, saved-only, pagination, detail, bookmarks). Administrators: article create/edit/publish/delete (delete needs re-authentication) and community moderation (reports queue with remove/hide/dismiss, latest posts, change post status). New permission `community:moderate` (super admin, membership admin, support admin); articles use the existing `content:write`.

Rules enforced on the server: only active members take part; blocked pairs never see each other's posts or comments; "Friends only" posts are visible to accepted friends and the author only; post images are served through an authenticated route that re-checks visibility; per-member rate limits (10 posts/hour, 40 comments/hour, 120 reactions/10 minutes, 20 reports/day); creating a post or comment is idempotent through a client-generated id, so retries and double taps never duplicate; the author is notified once on the first like (un-like then re-like does not notify again) and on each comment; user text is stored as plain text and escaped on display; article bodies are plain text turned into structured blocks (never HTML).

### Pages
`dashboard.html` (new Home per the reference: greeting, Active Member pill, daily motivation, AI Powered Workspace and SPACEFX cards with official logos, Community Feed / My Posts / Messages / Trending tabs, Latest Articles, Connect panel, announcements), `community.html`, `post.html` (Create post: counter, photo preview with automatic downsizing, audience, text kept on failure, draft kept in the session), `explore.html`, `article.html`, `admin-articles.html`, `admin-community.html`.

### Tests actually run for this update
- `node --test` (dependency-free files): **37 passed, 0 failed**. The 9 new community tests cover input validation, cursor tampering, slug and reading time, article body parsing, migration structure, the unique-index/`ON CONFLICT` match, auth on every route, SQL parameterisation, permissions and front-end escaping.
- Route logic was also run in this environment against a stubbed database (stubs removed afterwards): idempotent create, duplicate return, image store, all rate limits, invalid mode/cursor/platform, notify-once on likes, comment notification, own-content reports, dynamic search parameters and LIKE-wildcard escaping: **35 of 35 checks passed**.
- Chromium end-to-end against an in-memory mock of the new endpoints: create post (failure keeps text, retry stores one post), like, comment, report, delete, Explore search and empty state, bookmark, article render (script text shown as text, not executed), 6-item nav order, Home tabs, admin article save, admin report decision, desktop layout without bottom nav, and all 50 pages at 390 px and 1280 px with no missing assets and no horizontal overflow. This also caught and fixed a real defect: the Home tab bar was stretching the phone layout to 621 px.

### What was NOT verified
- **No SQL was executed against PostgreSQL** (no database or network here). The statements were reviewed by hand and checked structurally, but the first real run is `npm run migrate` followed by exercising the feature on a staging or Neon branch database. If any statement needs adjusting, it will show on that first run.
- No real Netlify Blobs upload, no live friends/blocks data, no real notifications delivery, no multi-user or load testing, no screen-reader or device testing.
- Not built: video posts, hashtags, mentions, edit-post, article comments, public (signed-out) articles, push notifications, real-time updates (the feed updates on load or refresh).


---

## Update 3: full verification pass on the delivered zip

Everything below was run against a fresh unpack of the final zip.

**Found and fixed**
1. `UPDATE post_comments c SET ...` used an alias without `AS`. PostgreSQL accepts it, but stricter SQL engines do not, so it was changed to `UPDATE post_comments AS c` (same meaning, portable). A test now guards this.
2. Secondary-text colour `#61718A` measured 4.32:1 to 4.48:1 on some tinted surfaces (tab bar, composer bar), just under the 4.5:1 AA minimum. The `--sn-muted` token is now `#56667F` (5.08:1 or better everywhere). Tests cover every surface it is used on.
3. The "Saved only" checkbox on Explore was a 13 px target; it is now 20 px inside a 44 px row.
4. (Earlier in the same pass) the Home tab bar was stretching the phone layout to 621 px; grid tracks can now shrink.

**Verified**
- 49 tests pass across 8 files (3 new brand/contrast pairs, 1 new SQL-form test); 8 integration tests skip because they need a live database.
- The real API entry point (`api.mjs`) loads with the new route module (third-party packages stubbed). 182 routes registered, no path collisions. All 24 new member and admin routes return 401 to anonymous callers, all 18 state-changing ones return 403 without the CSRF header, and forged cookies are refused.
- The real route handlers were run against a relational engine (SQLite, with the real migration 006 applied and the real queries translated for it) in a 71-check, five-user scenario: friends-only posts, blocked members, suspended members, keyset pagination under concurrent inserts, idempotent post and comment creation, like counts and notify-once, comment permissions, report de-duplication and moderation (remove, hide, dismiss, restore, notifications, audit), trending ranking and the 14-day cut-off, photo access control and deletion, article draft/publish/unpublish, search (including `%` and `_` as literals and an injection string), filters, pagination, bookmarks, related articles, categories, deletion cascades. **71 of 71 pass.**
- Every table and column the new queries touch was checked against migrations 001 to 005 (including `user_profiles.username/display_name` from 003).
- Browser: every named import resolves to a real export; no broken internal links; no duplicate element IDs; every control has an accessible name; all images have alt text; arrow keys move between tabs; Escape closes dialogs; all 50 pages load with no missing assets and no horizontal overflow at 390 px and 1280 px.

**Still not verified (cannot be, in this environment)**
SQLite is a faithful check of the query logic but is not PostgreSQL. PostgreSQL-specific syntax (type casts, `to_char`, `interval`, `ON CONFLICT ... WHERE`) was reviewed by hand but not executed. Real Netlify Blobs, real Neon latency, concurrent load, real phones and screen readers were not tested. The first `npm run migrate` and a short manual run-through on a staging database remain the final check.
