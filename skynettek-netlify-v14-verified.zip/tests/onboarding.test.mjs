import test from 'node:test';
import assert from 'node:assert/strict';
import { ONBOARDING_QUESTIONS, ONBOARDING_DEF, PATH_TO_PLATFORMS, publicOnboarding } from '../netlify/lib/onboarding.mjs';
import { validate } from '../netlify/lib/questionnaires.mjs';
import { sessionCookie, setCookie } from '../netlify/lib/http.mjs';

const good = { path: 'AI Powered Workspace', level: 'Know the basics', goal: 'Learn a new skill', hours: '3-5 hours', format: 'Live sessions' };

test('onboarding has exactly five required single-choice questions with unique ids', () => {
  assert.equal(ONBOARDING_QUESTIONS.length, 5);
  assert.equal(new Set(ONBOARDING_QUESTIONS.map(q => q.id)).size, 5);
  for (const q of ONBOARDING_QUESTIONS) { assert.equal(q.required, true); assert.equal(q.type, 'single'); assert.ok(q.options.length >= 2); }
  assert.equal(ONBOARDING_DEF.steps.length, 5);
  assert.equal(publicOnboarding().length, 5);
});
test('every learning-path option maps to real platforms', () => {
  const path = ONBOARDING_QUESTIONS.find(q => q.id === 'path');
  for (const o of path.options) assert.ok(PATH_TO_PLATFORMS[o]?.every(p => ['ai', 'spacefx'].includes(p)), o);
  assert.deepEqual(PATH_TO_PLATFORMS.Both, ['ai', 'spacefx']);
});
test('completion needs all five valid answers; partial saves allow gaps but not bad values', () => {
  assert.deepEqual(validate(ONBOARDING_DEF, good).errors, {});
  const { errors } = validate(ONBOARDING_DEF, { path: 'Both' });
  assert.deepEqual(Object.keys(errors).sort(), ['format', 'goal', 'hours', 'level']);
  assert.deepEqual(validate(ONBOARDING_DEF, { path: 'Both' }, { partial: true }).errors, {});
  assert.ok(validate(ONBOARDING_DEF, { ...good, hours: 'Always' }, { partial: true }).errors.hours);
  assert.ok(validate(ONBOARDING_DEF, { ...good, path: ['Both'] }).errors.path);
});
test('member session cookie has no Max-Age but stays HttpOnly/Secure/SameSite=Strict; admin cookies are unchanged', () => {
  const c = sessionCookie('sid', 'abc');
  assert.ok(!/max-age/i.test(c)); assert.ok(/HttpOnly/.test(c) && /Secure/.test(c) && /SameSite=Strict/.test(c));
  assert.ok(/Max-Age=600/.test(setCookie('apsid', 'x', 600)));
});
