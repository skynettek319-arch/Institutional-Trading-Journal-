# Deploy to Netlify + Neon

## 1. Neon
Create a project, copy the pooled connection string into `DATABASE_URL`. Optionally create a second branch for testing.

## 2. Push the code
Put this folder in a GitHub/GitLab repo (`.env` is git-ignored).

## 3. Netlify
New site from Git. Build command: empty. Publish directory: `public`. Functions directory: `netlify/functions` (already in `netlify.toml`).

Site configuration > Environment variables, add:

| Variable | Value |
|---|---|
| `DATABASE_URL` | Neon pooled connection string |
| `TOTP_ENC_KEY` | `openssl rand -hex 32` (keep a backup; losing it means every admin must re-enrol 2FA) |
| `SESSION_PEPPER` | `openssl rand -hex 32` |
| `APP_URL` | your final https URL, no trailing slash |
| `SPACEFX_WHATSAPP_INVITE` | the WhatsApp group invitation link |
| `RESEND_API_KEY`, `EMAIL_FROM` | see step 5 |
| `ADMIN_NOTIFY_EMAIL` | `skynettek319@gmail.com` |
| `REQUIRE_EMAIL_VERIFICATION` | `true` once email works. Use `false` only while testing without email |

Mark the keys and invitation as secret values and scope them to Functions. Do not use any `VITE_`/public prefix.

## 4. Migrate and create the admin
Run both from your own computer with the production `DATABASE_URL` in your shell (not in git):

    npm run migrate
    npm run create-admin -- you@example.com super_admin

## 5. Email (Resend)
Create an account, add and verify your sending domain (DNS records), create an API key, set `EMAIL_FROM` to an address on that domain. Until this is done no email is sent (the code logs "not configured" and the site keeps working; dashboards always show the true status). With `REQUIRE_EMAIL_VERIFICATION=true` members cannot sign in without the email, so finish this before launch.

## 6. Custom domain and HTTPS
Add your domain in Netlify, set `APP_URL` to it, redeploy. Cookies are `Secure`, so HTTPS is required.

## 7. File storage
Netlify Blobs is used automatically for private proof screenshots (`proofs` store, only readable through the admin API) and public thumbnails (`thumbs`). No extra configuration.

## Before launch
Work through `docs/TEST-REPORT.md` (section "Needs your environment"). Have a lawyer review the legal pages.
