CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('member','super_admin','membership_admin','content_admin','support_admin')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  suspend_reason text,
  email_verified boolean NOT NULL DEFAULT false,
  totp_secret_enc text,
  totp_pending_enc text,
  totp_enabled boolean NOT NULL DEFAULT false,
  totp_last_step bigint,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz,
  password_changed_at timestamptz
);
CREATE UNIQUE INDEX users_email_uq ON users (lower(email));
CREATE INDEX users_role_idx ON users (role);
CREATE TABLE user_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  country text NOT NULL,
  region text NOT NULL,
  city text,
  age_range text NOT NULL,
  language text NOT NULL,
  whatsapp text NOT NULL,
  background text,
  occupation text,
  schedule text,
  device_access text,
  discovered_via text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE platform_access (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform text NOT NULL CHECK (platform IN ('ai','spacefx')),
  selected boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'not_selected' CHECK (status IN ('not_selected','not_started','in_progress','proof_submitted','awaiting_review','approved','rejected','suspended')),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, platform)
);
CREATE INDEX platform_access_status_idx ON platform_access (platform, status);
CREATE TABLE onboarding_responses (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform text NOT NULL CHECK (platform IN ('ai','spacefx','both')),
  answers jsonb NOT NULL DEFAULT '{}'::jsonb,
  submitted_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, platform)
);
CREATE TABLE purchase_proofs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  selar_email text NOT NULL,
  order_ref text,
  purchase_date date,
  file_key text NOT NULL,
  file_mime text NOT NULL,
  file_sha256 text NOT NULL,
  notes text,
  accuracy_confirmed boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'awaiting_review' CHECK (status IN ('awaiting_review','approved','rejected','resubmit_requested','revoked')),
  flagged boolean NOT NULL DEFAULT false,
  flag_reason text,
  admin_note text,
  rejection_reason text,
  decided_by uuid REFERENCES users(id),
  decided_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX proofs_user_idx ON purchase_proofs (user_id, created_at DESC);
CREATE INDEX proofs_status_idx ON purchase_proofs (status, created_at DESC);
CREATE INDEX proofs_order_idx ON purchase_proofs (lower(order_ref));
CREATE INDEX proofs_sha_idx ON purchase_proofs (file_sha256);
CREATE TABLE verification_decisions (
  id bigserial PRIMARY KEY,
  proof_id uuid NOT NULL REFERENCES purchase_proofs(id) ON DELETE CASCADE,
  admin_id uuid NOT NULL REFERENCES users(id),
  action text NOT NULL CHECK (action IN ('approve','reject','resubmit','revoke')),
  reason text,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX decisions_proof_idx ON verification_decisions (proof_id);
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  sort_order int NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT false
);
CREATE TABLE lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  title text NOT NULL,
  summary text,
  objectives text,
  video_url text,
  content text,
  thumbnail_key text,
  sort_order int NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX lessons_cat_idx ON lessons (category_id, sort_order);
CREATE TABLE lesson_progress (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id uuid NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  completed boolean NOT NULL DEFAULT false,
  bookmarked boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, lesson_id)
);
CREATE TABLE ebooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  description text,
  cover_path text,
  selar_url text NOT NULL,
  price_label text,
  sort_order int NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT true
);
CREATE TABLE announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text NOT NULL,
  published boolean NOT NULL DEFAULT true,
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text NOT NULL,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON notifications (user_id, created_at DESC);
CREATE TABLE settings (
  key text PRIMARY KEY,
  value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE sessions (
  id_hash text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('member','admin','admin_pending')),
  ip text,
  user_agent text,
  reauth_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);
CREATE INDEX sessions_user_idx ON sessions (user_id);
CREATE INDEX sessions_exp_idx ON sessions (expires_at);
CREATE TABLE recovery_codes (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash text NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX recovery_user_idx ON recovery_codes (user_id);
CREATE TABLE auth_tokens (
  token_hash text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  purpose text NOT NULL CHECK (purpose IN ('verify_email','reset_password')),
  expires_at timestamptz NOT NULL,
  used_at timestamptz
);
CREATE TABLE login_attempts (
  id bigserial PRIMARY KEY,
  key text NOT NULL,
  ip text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX login_attempts_key_idx ON login_attempts (key, created_at DESC);
CREATE TABLE audit_logs (
  id bigserial PRIMARY KEY,
  actor_id uuid,
  action text NOT NULL,
  target_type text,
  target_id text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_created_idx ON audit_logs (created_at DESC);
CREATE INDEX audit_target_idx ON audit_logs (target_type, target_id);
CREATE TABLE security_events (
  id bigserial PRIMARY KEY,
  user_id uuid,
  event text NOT NULL,
  ip text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX security_events_created_idx ON security_events (created_at DESC);
CREATE TABLE support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL DEFAULT 'contact' CHECK (kind IN ('contact','deletion_request')),
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  name text NOT NULL,
  email text NOT NULL,
  message text NOT NULL,
  handled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO settings(key,value) VALUES
 ('selar_forex_url','https://selar.com/017j91l781'),
 ('support_email','skynettek319@gmail.com'),
 ('contact_phone',''),
 ('home_ai_blurb','Learn AI-powered video creation first, with structured lessons, practical exercises and progress tracking. AI automation, AI-assisted analysis, software development with AI and advanced AI engineering are planned next.'),
 ('home_spacefx_blurb','A Forex education and trading community. Access is requested by purchasing the Forex Trading Mastery ebook and submitting proof of purchase for review.');
INSERT INTO categories(slug,name,description,sort_order,published) VALUES
 ('ai-video-creation','AI video creation','Create videos with AI tools, from first idea to finished export.',1,true),
 ('ai-content-image','AI content and image creation','Produce images and written content with AI tools.',2,false),
 ('ai-automation','AI automation','Automate repeatable work with AI-assisted workflows.',3,false),
 ('ai-agents','AI agents and workflow development','Design agents and multi-step workflows.',4,false),
 ('ai-market-analysis','AI-assisted market analysis','Use AI as a research aid. It does not predict markets or guarantee returns.',5,false),
 ('ai-software','Software development with AI','Build software with AI coding assistants.',6,false),
 ('ai-business','Building AI-powered businesses','Plan, sell and deliver AI-powered services.',7,false),
 ('ai-engineering','Advanced AI engineering','Advanced topics for experienced builders.',8,false);
INSERT INTO ebooks(slug,title,description,cover_path,selar_url,sort_order) VALUES
 ('30-days-ai-automation-company','30 Days to Start Your AI Automation Company','A practical roadmap to building, selling and delivering AI-powered automations. By Chika Offor.','/assets/img/book-ai-automation.webp','https://selar.com/87596eu737',1),
 ('brain-hack','Brain Hack: 30 Days to Transform the Way You Think, Learn & Solve Problems','A 30-day journey covering better food, a stronger body, a clearer mind and smarter thinking. By Chika Offor A.','/assets/img/book-brain-hack.webp','https://selar.com/5q87881744',2);
