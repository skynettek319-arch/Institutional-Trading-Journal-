import { $, $$, api, adminApi, esc, msg, clearMsg, busy, modal, confirmBox, adminLayout, badge, statusLabel, fmtDate, pager, fileToBase64, nl2br, COUNTRIES } from './app.js';

const page = document.body.dataset.page;
const flag = ok => ok ? '<span class="status-tag s-approved">Yes</span>' : '<span class="status-tag">No</span>';
const act = (el, fn) => el.addEventListener('click', e => busy(e.currentTarget, fn));

const pages = {
  // ------------------------------------------------ sign in + Google Authenticator enrolment
  login() {
    const f1 = $('#l1'), f2 = $('#l2'), enr = $('#enroll'), m = $('#lm');
    const toStep = s => { f1.hidden = s !== 'password'; f2.hidden = s !== 'totp'; enr.hidden = s !== 'enroll'; clearMsg(m); if (s === 'enroll') startEnroll(); };
    f1.onsubmit = async e => {
      e.preventDefault(); clearMsg(m);
      await busy($('button', f1), async () => { try { const r = await api('/admin/login', { method: 'POST', body: Object.fromEntries(new FormData(f1)) }); f1.reset(); toStep(r.step); } catch (err) { msg(m, err.message); } });
    };
    f2.onsubmit = async e => {
      e.preventDefault(); clearMsg(m);
      const b = Object.fromEntries(new FormData(f2));
      await busy($('button', f2), async () => {
        try { await api('/admin/totp/verify', { method: 'POST', body: b.recoveryCode ? { recoveryCode: b.recoveryCode } : { code: b.code } }); location.href = '/admin.html'; }
        catch (err) { msg(m, err.message); }
      });
    };
    $('#use-recovery').onclick = () => { $('#rec').hidden = false; $('#code').required = false; };
    async function startEnroll() {
      try {
        const s = await api('/admin/totp/setup', { method: 'POST' });
        $('#qr').innerHTML = `<img class="qr" src="${s.qr}" alt="QR code for Google Authenticator" width="240" height="240">`;
        $('#secret').textContent = s.secret;
      } catch (err) { msg(m, err.message); }
    }
    $('#ef').onsubmit = async e => {
      e.preventDefault(); clearMsg(m);
      await busy($('#ef button'), async () => {
        try {
          const r = await api('/admin/totp/enable', { method: 'POST', body: { code: $('#ecode').value } });
          $('#ef').hidden = true; $('#qrbox').hidden = true;
          $('#codes').innerHTML = `<h3>Save your recovery codes</h3><p class="notice warn">Each code works once if you lose your phone. They are shown only now. Store them somewhere safe and offline.</p><ul class="codes">${r.recoveryCodes.map(c => `<li>${esc(c)}</li>`).join('')}</ul><div class="actions"><button class="btn btn-outline" id="cp">Copy codes</button><a class="btn btn-primary" href="/admin.html" data-same-tab>I have saved them. Continue</a></div>`;
          $('#cp').onclick = () => navigator.clipboard?.writeText(r.recoveryCodes.join('\n'));
        } catch (err) { msg(m, err.message); }
      });
    };
  },

  // ------------------------------------------------ overview
  async overview() {
    if (!await adminLayout()) return;
    const { metrics: x, recent } = await adminApi('/admin/overview');
    const items = [['Registered members', x.members], ['AI Powered Workspace selected', x.aiSelected], ['SPACEFX selected', x.spacefxSelected], ['Both platforms', x.bothSelected], ['Pending purchase proofs', x.pendingProofs], ['Approved SPACEFX members', x.approvedSpacefx], ['Rejected or flagged', x.rejectedOrFlagged], ['Active AI learners', x.activeAiLearners], ['Published lessons', x.publishedLessons], ['Draft lessons', x.draftLessons], ['Payments awaiting review', x.pendingPayments], ['Confirmed training places', x.approvedEnrollments], ['Open trainings', x.openTrainings], ['Upcoming events', x.upcomingEvents], ['New registrations (7 days)', x.newRegistrations7d], ['Successful referrals', x.successfulReferrals], ['Rewards credited (₦)', Number(x.rewardsCredited).toLocaleString('en-NG')], ['Withdrawals to pay', x.openWithdrawals], ['Needs attention', x.openAlerts]];
    $('#metrics').innerHTML = items.map(([l, v]) => `<div class="metric"><b>${v}</b><span>${l}</span></div>`).join('');
    $('#recent').innerHTML = recent.length ? `<div class="table-wrap"><table><thead><tr><th>When</th><th>Administrator</th><th>Action</th></tr></thead><tbody>${recent.map(r => `<tr><td>${fmtDate(r.created_at)}</td><td>${esc(r.actor || 'system')}</td><td>${esc(r.action)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No activity recorded yet.</p>';
  },

  // ------------------------------------------------ members
  async members() {
    const me = await adminLayout(); if (!me) return;
    let pg = 0;
    const can = p => me.perms.includes('*') || me.perms.includes(p);
    const load = async () => {
      const p = new URLSearchParams({ page: pg, q: $('#q').value, platform: $('#fplat').value, spacefxStatus: $('#fst').value, sort: $('#fsort').value, suspended: $('#fsusp').checked ? '1' : '' });
      try {
        const d = await adminApi('/admin/members?' + p);
        $('#rows').innerHTML = d.members.length ? d.members.map(r => `<tr><td>${esc(r.full_name || '')}<br><span class="small muted">${esc(r.email)}</span></td><td>${esc(r.country || '')}</td><td>${(r.platforms || []).map(x => `${x.platform === 'ai' ? 'AI' : 'SPACEFX'}: ${badge(x.status)}`).join('<br>') || '<span class="muted">none</span>'}</td><td>${r.status === 'suspended' ? badge('suspended') : 'Active'}</td><td>${new Date(r.created_at).toLocaleDateString()}</td><td><button class="btn btn-outline btn-sm" data-id="${r.id}">View</button></td></tr>`).join('') : '<tr><td colspan="6" class="muted">No members match these filters.</td></tr>';
        $$('button[data-id]', $('#rows')).forEach(b => b.onclick = () => detail(b.dataset.id));
        pager($('#pg'), d.total, d.pageSize, pg, n => { pg = n; load(); });
      } catch (e) { $('#rows').innerHTML = `<tr><td colspan="6">${esc(e.message)}</td></tr>`; }
    };
    $('#filters').onsubmit = e => { e.preventDefault(); pg = 0; load(); };
    if (can('members:export')) { $('#export').hidden = false; $('#export').onclick = e => busy(e.currentTarget, async () => { try { const r = await adminApi('/admin/members/export'); const b = await r.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'members.csv'; a.click(); } catch (err) { msg($('#mm'), err.message); } }); }
    async function detail(id) {
      const d = await adminApi('/admin/members/' + id);
      const p = d.profile, mm = d.member;
      const m = modal(`<h2>${esc(p.full_name)}</h2><p class="small muted">${esc(mm.email)} · Joined ${fmtDate(mm.created_at)} · Last sign-in ${fmtDate(mm.last_login_at) || 'never'} · Email verified: ${mm.email_verified ? 'yes' : 'no'}</p>
        ${mm.status === 'suspended' ? `<div class="notice bad">Suspended: ${esc(mm.suspend_reason || '')}</div>` : ''}
        <p>${esc(p.country)}, ${esc(p.region)}${p.city ? ', ' + esc(p.city) : ''} · ${esc(p.age_range)} · ${esc(p.language)} · WhatsApp ${esc(p.whatsapp)}</p>
        <p>${d.platforms.map(x => `${x.platform === 'ai' ? 'AI Powered Workspace' : 'SPACEFX'}: ${badge(x.selected ? x.status : 'not_selected')}`).join(' &nbsp; ')}</p>
        ${d.answers ? `<details><summary>Questionnaire answers</summary>${Object.entries(d.answers).map(([k, v]) => `<h4>${esc(k)}</h4>${Object.entries(v).map(([q, a]) => `<p class="small"><strong>${esc(q)}:</strong> ${esc(Array.isArray(a) ? a.join(', ') : a)}</p>`).join('')}`).join('') || '<p class="muted">None submitted.</p>'}</details>` : ''}
        ${d.proofs ? `<h3>Purchase submissions</h3>${d.proofs.map(x => `<p class="small">${badge(x.status)} ${x.flagged ? badge('flagged') : ''} ${esc(x.order_ref || '')} · ${fmtDate(x.created_at)} · <a data-same-tab href="/admin-proofs.html">Open queue</a></p>`).join('') || '<p class="muted small">None.</p>'}` : ''}
        <h3>Audit trail</h3>${d.trail.map(t => `<p class="small">${fmtDate(t.created_at)} · ${esc(t.actor || 'system')} · ${esc(t.action)}</p>`).join('') || '<p class="muted small">No account actions recorded.</p>'}
        <div class="msg" id="dm"></div>
        <div class="actions">${can('members:write') ? `<button class="btn btn-outline btn-sm" id="notif">Send notification</button>${mm.status === 'suspended' ? '<button class="btn btn-primary btn-sm" id="reinstate">Reinstate</button>' : '<button class="btn btn-danger btn-sm" id="suspend">Suspend</button>'}` : ''}<button class="btn btn-outline btn-sm" id="close">Close</button></div>`);
      $('#close', m).onclick = () => m.close();
      $('#suspend', m)?.addEventListener('click', async () => {
        const reason = prompt('Reason for suspension (shown in the audit trail):'); if (!reason) return;
        try { await adminApi(`/admin/members/${id}/suspend`, { method: 'POST', body: { reason } }); m.close(); load(); } catch (e) { msg($('#dm', m), e.message); }
      });
      $('#reinstate', m)?.addEventListener('click', async () => { if (!await confirmBox('Reinstate this member? Platform statuses are recalculated from their evidence.')) return; try { await adminApi(`/admin/members/${id}/reinstate`, { method: 'POST' }); m.close(); load(); } catch (e) { msg($('#dm', m), e.message); } });
      $('#notif', m)?.addEventListener('click', async () => {
        const title = prompt('Notification title:'); if (!title) return; const body = prompt('Message:'); if (!body) return;
        try { await adminApi(`/admin/members/${id}/notify`, { method: 'POST', body: { title, body } }); msg($('#dm', m), 'Notification sent.', 'success'); } catch (e) { msg($('#dm', m), e.message); }
      });
    }
    if (can('support:read')) {
      $('#support-section').hidden = false;
      const ls = async () => {
        const { messages } = await adminApi('/admin/support');
        $('#support').innerHTML = messages.length ? messages.map(s => `<div class="card" style="margin-bottom:.7rem"><strong>${esc(s.name)}</strong> (${esc(s.email)}) ${s.kind === 'deletion_request' ? badge('suspended').replace('Suspended', 'Deletion request') : ''} <span class="muted small">${fmtDate(s.created_at)}</span><p class="small">${nl2br(s.message)}</p>${s.handled ? '<span class="status-tag s-approved">Handled</span>' : `<button class="btn btn-outline btn-sm" data-h="${s.id}">Mark handled</button>`}</div>`).join('') : '<p class="muted">No support messages.</p>';
        $$('[data-h]', $('#support')).forEach(b => b.onclick = async () => { await adminApi(`/admin/support/${b.dataset.h}/handled`, { method: 'POST' }); ls(); });
      };
      ls();
    }
    load();
  },

  // ------------------------------------------------ purchase verification
  async proofs() {
    const me = await adminLayout(); if (!me) return;
    let pg = 0;
    const load = async () => {
      const p = new URLSearchParams({ page: pg, status: $('#pst').value, flagged: $('#pfl').checked ? '1' : '' });
      try {
        const d = await adminApi('/admin/proofs?' + p);
        $('#rows').innerHTML = d.proofs.length ? d.proofs.map(r => `<tr><td>${esc(r.full_name || '')}<br><span class="small muted">${esc(r.account_email)}</span></td><td>${esc(r.selar_email)}</td><td>${esc(r.order_ref || '—')}</td><td>${fmtDate(r.created_at)}</td><td>${badge(r.status)} ${r.flagged ? badge('flagged').replace('Flagged', 'Flagged') : ''}</td><td><button class="btn btn-primary btn-sm" data-id="${r.id}">Review</button></td></tr>`).join('') : '<tr><td colspan="6" class="muted">Nothing in this queue.</td></tr>';
        $$('button[data-id]', $('#rows')).forEach(b => b.onclick = () => review(b.dataset.id));
        pager($('#pg'), d.total, d.pageSize, pg, n => { pg = n; load(); });
      } catch (e) { $('#rows').innerHTML = `<tr><td colspan="6">${esc(e.message)}</td></tr>`; }
    };
    $('#pfilters').onsubmit = e => { e.preventDefault(); pg = 0; load(); };
    async function review(id) {
      const d = await adminApi('/admin/proofs/' + id), p = d.proof;
      const pending = p.status === 'awaiting_review';
      const m = modal(`<h2>Review submission</h2><p>${badge(p.status)} ${p.flagged ? badge('flagged') : ''}</p>
        <p><strong>${esc(p.full_name || '')}</strong> · account ${esc(p.account_email)}<br>Selar purchase email: <strong>${esc(p.selar_email)}</strong><br>Order reference: ${esc(p.order_ref || 'not provided')} · Purchase date: ${esc(p.purchase_date ? String(p.purchase_date).slice(0, 10) : 'not provided')}<br>Submitted ${fmtDate(p.created_at)}</p>
        ${p.notes ? `<p class="small"><strong>Member note:</strong> ${esc(p.notes)}</p>` : ''}
        ${p.flagged ? `<div class="notice bad"><strong>Flag:</strong> ${esc(p.flag_reason)}</div>` : ''}
        ${d.duplicates.length ? `<div class="notice warn"><strong>Possible reuse</strong>${d.duplicates.map(x => `<br>${esc(x.account_email)} · ${statusLabel(x.status)} · ${fmtDate(x.created_at)}`).join('')}</div>` : ''}
        <div id="img"><span class="spinner"></span> Loading private proof…</div>
        <div class="notice small">A screenshot is not proof. Open your <strong>Selar seller dashboard</strong>, find this order by email or reference, and confirm it is a paid order for the Forex Trading Mastery ebook before approving.</div>
        <div class="field"><label for="note">Internal verification note</label><textarea id="note">${esc(p.admin_note || '')}</textarea></div>
        <div class="field"><label for="reason">Reason (required to reject, request clearer proof or revoke; shown to the member)</label><input id="reason" type="text" maxlength="500" value=""></div>
        <label class="opt"><input type="checkbox" id="verified"> I verified this paid order in the Selar seller dashboard</label>
        <div class="msg" id="pm"></div>
        <div class="actions">${pending ? `<button class="btn btn-primary" id="approve">Approve</button><button class="btn btn-outline" id="resubmit">Request clearer proof</button><button class="btn btn-danger" id="reject">Reject</button>` : ''}${p.status === 'approved' ? '<button class="btn btn-danger" id="revoke">Reverse approval</button>' : ''}<button class="btn btn-outline" id="savenote">Save note</button><button class="btn btn-outline" id="close">Close</button></div>
        <h3 style="margin-top:1.4rem">Decision history</h3>${d.history.map(h => `<p class="small">${fmtDate(h.created_at)} · ${esc(h.admin)} · <strong>${esc(h.action)}</strong>${h.reason ? ' · ' + esc(h.reason) : ''}</p>`).join('') || '<p class="muted small">No decisions yet.</p>'}`);
      $('#close', m).onclick = () => m.close();
      try { const r = await adminApi(`/admin/proofs/${id}/file`); const url = URL.createObjectURL(await r.blob()); $('#img', m).innerHTML = `<img class="proof-img" src="${url}" alt="Submitted proof screenshot">`; } catch (e) { $('#img', m).textContent = e.message; }
      const decide = (action) => async () => {
        const body = { action, reason: $('#reason', m).value, note: $('#note', m).value, verifiedInSelar: $('#verified', m).checked };
        try { await adminApi(`/admin/proofs/${id}/decision`, { method: 'POST', body }); m.close(); load(); } catch (e) { msg($('#pm', m), e.message); }
      };
      for (const a of ['approve', 'reject', 'resubmit', 'revoke']) { const b = $('#' + a, m); if (b) b.onclick = async () => { if (a === 'revoke' && !await confirmBox('Reverse this approval? The member will lose access to the invitation.')) return; decide(a)(); }; }
      $('#savenote', m).onclick = async () => { try { await adminApi(`/admin/proofs/${id}/note`, { method: 'POST', body: { note: $('#note', m).value } }); msg($('#pm', m), 'Note saved.', 'success'); } catch (e) { msg($('#pm', m), e.message); } };
    }
    load();
  },

  // ------------------------------------------------ content
  async content() {
    const me = await adminLayout(); if (!me) return;
    let D, tab = 'lessons';
    const reload = async () => { D = await adminApi('/admin/content/all'); show(); };
    const tabs = [['lessons', 'Lessons'], ['categories', 'Categories'], ['ebooks', 'Ebooks'], ['announcements', 'Announcements'], ['settings', 'Settings']];
    $('#tabs').innerHTML = tabs.map(([k, t]) => `<button role="tab" data-t="${k}" aria-selected="${k === tab}">${t}</button>`).join('');
    $$('#tabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; $$('#tabs button').forEach(x => x.setAttribute('aria-selected', x === b)); show(); });
    const out = $('#panel'), M = $('#cm');
    const form = (title, fields, vals, onSave, extraHtml = '') => {
      const m = modal(`<h2>${title}</h2><form id="cf">${fields.map(f => {
        const v = vals[f.k] ?? ''; const id = 'f-' + f.k;
        if (f.t === 'check') return `<label class="opt"><input type="checkbox" name="${f.k}" ${vals[f.k] ? 'checked' : ''}> ${f.l}</label>`;
        if (f.t === 'select') return `<div class="field"><label for="${id}">${f.l}</label><select id="${id}" name="${f.k}">${f.o.map(([ov, ol]) => `<option value="${esc(ov)}" ${ov === v ? 'selected' : ''}>${esc(ol)}</option>`).join('')}</select></div>`;
        if (f.t === 'area') return `<div class="field"><label for="${id}">${f.l}</label><textarea id="${id}" name="${f.k}">${esc(v)}</textarea></div>`;
        return `<div class="field"><label for="${id}">${f.l}</label><input id="${id}" name="${f.k}" type="${f.t || 'text'}" value="${esc(v)}"></div>`;
      }).join('')}${extraHtml}<div class="msg" id="fm"></div><div class="actions"><button class="btn btn-primary">Save</button><button type="button" class="btn btn-outline" id="x">Cancel</button></div></form>`);
      $('#x', m).onclick = () => m.close();
      $('#cf', m).onsubmit = async e => {
        e.preventDefault();
        const fd = new FormData(e.target), o = {};
        for (const f of fields) o[f.k] = f.t === 'check' ? fd.has(f.k) : fd.get(f.k);
        await busy($('#cf button', m), async () => { try { await onSave(o, m); m.close(); await reload(); msg(M, 'Saved.', 'success'); } catch (err) { msg($('#fm', m), err.message); } });
      };
      return m;
    };
    const uploadInput = '<div class="field"><label for="up">Upload image (PNG, JPEG or WEBP, up to 2 MB)</label><input id="up" type="file" accept="image/png,image/jpeg,image/webp"><div class="hint">Leave empty to keep the current image.</div></div>';
    const upload = async m => { const f = $('#up', m).files[0]; if (!f) return null; if (f.size > 2 * 1024 * 1024) throw new Error('Image is larger than 2 MB'); return (await adminApi('/admin/upload-thumb', { method: 'POST', body: { file: await fileToBase64(f) } })).key; };

    function show() {
      clearMsg(M);
      if (tab === 'lessons') {
        out.innerHTML = `<div class="actions" style="margin-top:0"><button class="btn btn-primary" id="new">Add lesson</button></div><div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>Order</th><th>Lesson</th><th>Category</th><th>Status</th><th></th></tr></thead><tbody>${D.lessons.map(l => `<tr><td>${l.sort_order}</td><td>${esc(l.title)}</td><td>${esc(D.categories.find(c => c.id === l.category_id)?.name || '')}</td><td>${l.published ? badge('approved').replace('Approved', 'Published') : '<span class="status-tag">Draft</span>'}</td><td><button class="btn btn-outline btn-sm" data-e="${l.id}">Edit</button> <button class="btn btn-outline btn-sm" data-d="${l.id}">Delete</button></td></tr>`).join('') || '<tr><td colspan="5" class="muted">No lessons yet. Add the first one.</td></tr>'}</tbody></table></div>`;
        const edit = l => form(l ? 'Edit lesson' : 'Add lesson', [
          { k: 'title', l: 'Title' }, { k: 'categoryId', l: 'Category', t: 'select', o: D.categories.map(c => [c.id, c.name + (c.published ? '' : ' (unpublished)')]) },
          { k: 'summary', l: 'Short description', t: 'area' }, { k: 'objectives', l: 'Learning objectives (one per line)', t: 'area' },
          { k: 'videoUrl', l: 'Video URL (YouTube, Vimeo or any https link)', t: 'url' }, { k: 'content', l: 'Lesson notes and exercises', t: 'area' },
          { k: 'sortOrder', l: 'Order (lowest first)', t: 'number' }, { k: 'published', l: 'Published (visible to AI Powered Workspace members)', t: 'check' }],
          l ? { ...l, categoryId: l.category_id, videoUrl: l.video_url, sortOrder: l.sort_order } : { categoryId: D.categories[0]?.id, sortOrder: D.lessons.length + 1 },
          async (o, m) => { const key = await upload(m); o.thumbnailKey = key || l?.thumbnail_key || null; await adminApi(l ? '/admin/lessons/' + l.id : '/admin/lessons', { method: l ? 'PUT' : 'POST', body: o }); }, uploadInput);
        $('#new').onclick = () => edit(null);
        $$('[data-e]', out).forEach(b => b.onclick = () => edit(D.lessons.find(x => x.id === b.dataset.e)));
        $$('[data-d]', out).forEach(b => b.onclick = async () => { if (!await confirmBox('Delete this lesson permanently? Member progress for it is also removed.')) return; try { await adminApi('/admin/lessons/' + b.dataset.d, { method: 'DELETE' }); reload(); } catch (e) { msg(M, e.message); } });
      }
      if (tab === 'categories') {
        out.innerHTML = `<p class="muted small">Unpublished categories stay hidden from members and are shown as "Planned" on the public roadmap.</p><div class="actions" style="margin-top:0"><button class="btn btn-primary" id="new">Add category</button></div><div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>Order</th><th>Name</th><th>Status</th><th></th></tr></thead><tbody>${D.categories.map(c => `<tr><td>${c.sort_order}</td><td>${esc(c.name)}<br><span class="small muted">${esc(c.slug)}</span></td><td>${c.published ? badge('approved').replace('Approved', 'Published') : '<span class="status-tag">Unpublished</span>'}</td><td><button class="btn btn-outline btn-sm" data-e="${c.id}">Edit</button></td></tr>`).join('')}</tbody></table></div>`;
        const edit = c => form(c ? 'Edit category' : 'Add category', [{ k: 'name', l: 'Name' }, { k: 'description', l: 'Description', t: 'area' }, { k: 'sortOrder', l: 'Order', t: 'number' }, { k: 'published', l: 'Published', t: 'check' }],
          c ? { ...c, sortOrder: c.sort_order } : { sortOrder: D.categories.length + 1 }, o => adminApi(c ? '/admin/categories/' + c.id : '/admin/categories', { method: c ? 'PUT' : 'POST', body: o }));
        $('#new').onclick = () => edit(null); $$('[data-e]', out).forEach(b => b.onclick = () => edit(D.categories.find(x => x.id === b.dataset.e)));
      }
      if (tab === 'ebooks') {
        out.innerHTML = `<div class="actions" style="margin-top:0"><button class="btn btn-primary" id="new">Add ebook</button></div><div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>Title</th><th>Selar link</th><th>Price</th><th>Status</th><th></th></tr></thead><tbody>${D.ebooks.map(b => `<tr><td>${esc(b.title)}</td><td class="small">${esc(b.selar_url)}</td><td>${esc(b.price_label || '—')}</td><td>${b.published ? 'Listed' : 'Hidden'}</td><td><button class="btn btn-outline btn-sm" data-e="${b.id}">Edit</button> <button class="btn btn-outline btn-sm" data-d="${b.id}">Delete</button></td></tr>`).join('')}</tbody></table></div>`;
        const edit = b => form(b ? 'Edit ebook' : 'Add ebook', [{ k: 'title', l: 'Title' }, { k: 'description', l: 'Description', t: 'area' }, { k: 'selarUrl', l: 'Selar checkout URL', t: 'url' }, { k: 'priceLabel', l: 'Price label (optional, for example the amount you set on Selar)' }, { k: 'sortOrder', l: 'Order', t: 'number' }, { k: 'published', l: 'Listed publicly', t: 'check' }],
          b ? { ...b, selarUrl: b.selar_url, priceLabel: b.price_label, sortOrder: b.sort_order } : { published: true, sortOrder: D.ebooks.length + 1 },
          async (o, m) => { const key = await upload(m); o.coverPath = key ? '/api/thumb/' + key : b?.cover_path || null; await adminApi(b ? '/admin/ebooks/' + b.id : '/admin/ebooks', { method: b ? 'PUT' : 'POST', body: o }); }, uploadInput);
        $('#new').onclick = () => edit(null); $$('[data-e]', out).forEach(x => x.onclick = () => edit(D.ebooks.find(y => y.id === x.dataset.e)));
        $$('[data-d]', out).forEach(x => x.onclick = async () => { if (!await confirmBox('Delete this ebook listing?')) return; try { await adminApi('/admin/ebooks/' + x.dataset.d, { method: 'DELETE' }); reload(); } catch (e) { msg(M, e.message); } });
      }
      if (tab === 'announcements') {
        out.innerHTML = `<div class="actions" style="margin-top:0"><button class="btn btn-primary" id="new">Publish announcement</button></div>${D.announcements.map(a => `<div class="card" style="margin-top:1rem"><strong>${esc(a.title)}</strong> <span class="muted small">${fmtDate(a.created_at)}</span><p class="small">${nl2br(a.body)}</p><button class="btn btn-outline btn-sm" data-d="${a.id}">Delete</button></div>`).join('') || '<p class="muted" style="margin-top:1rem">No announcements.</p>'}`;
        $('#new').onclick = () => form('New announcement', [{ k: 'title', l: 'Title' }, { k: 'body', l: 'Message', t: 'area' }], {}, o => adminApi('/admin/announcements', { method: 'POST', body: { ...o, published: true } }));
        $$('[data-d]', out).forEach(x => x.onclick = async () => { if (!await confirmBox('Delete this announcement?')) return; await adminApi('/admin/announcements/' + x.dataset.d, { method: 'DELETE' }); reload(); });
      }
      if (tab === 'settings') {
        const s = D.settings;
        out.innerHTML = `<form id="sf" style="max-width:640px"><div class="field"><label for="s1">Forex Trading ebook checkout URL (Selar)</label><input id="s1" name="selar_forex_url" type="url" value="${esc(s.selar_forex_url)}"></div><div class="field"><label for="s2">Support email shown on the site</label><input id="s2" name="support_email" type="email" value="${esc(s.support_email)}"></div><div class="field"><label for="s3">Contact phone or WhatsApp (optional, with country code)</label><input id="s3" name="contact_phone" type="tel" value="${esc(s.contact_phone)}"></div><div class="field"><label for="s4">Homepage: AI Powered Workspace description</label><textarea id="s4" name="home_ai_blurb">${esc(s.home_ai_blurb)}</textarea></div><div class="field"><label for="s5">Homepage: SPACEFX description</label><textarea id="s5" name="home_spacefx_blurb">${esc(s.home_spacefx_blurb)}</textarea></div><button class="btn btn-primary">Save settings</button></form><p class="muted small" style="margin-top:1rem">The SPACEFX WhatsApp invitation is not editable here on purpose. It lives in the server environment variable SPACEFX_WHATSAPP_INVITE so it can never appear in the browser or in an admin page.</p>`;
        $('#sf').onsubmit = async e => { e.preventDefault(); await busy($('#sf button'), async () => { try { await adminApi('/admin/settings', { method: 'PUT', body: Object.fromEntries(new FormData(e.target)) }); msg(M, 'Settings saved.', 'success'); D = await adminApi('/admin/content/all'); } catch (err) { msg(M, err.message); } }); };
      }
    }
    reload();
  },

  // ------------------------------------------------ security
  async security() {
    const me = await adminLayout(); if (!me) return;
    const M = $('#sm'), isSuper = me.perms.includes('*');
    const load = async () => {
      const s = await adminApi('/admin/security/overview');
      $('#tfa').innerHTML = `<p>Two-factor authentication: ${s.totpEnabled ? '<span class="status-tag s-approved">Enabled</span>' : '<span class="status-tag s-rejected">Not enabled</span>'}<br><span class="small muted">Unused recovery codes: ${s.recoveryCodesRemaining}</span></p>`;
      $('#sessions').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Started</th><th>IP</th><th>Device</th><th></th></tr></thead><tbody>${s.sessions.map(x => `<tr><td>${fmtDate(x.created_at)}</td><td>${esc(x.ip)}</td><td class="small">${esc((x.user_agent || '').slice(0, 60))}</td><td>${x.current ? '<span class="status-tag s-approved">This session</span>' : `<button class="btn btn-outline btn-sm" data-r="${x.ref}">Revoke</button>`}</td></tr>`).join('')}</tbody></table></div>`;
      $$('[data-r]', $('#sessions')).forEach(b => b.onclick = async () => { await adminApi('/admin/security/sessions/revoke', { method: 'POST', body: { ref: b.dataset.r } }); load(); });
    };
    await load();
    $('#revoke-others').onclick = async () => { await adminApi('/admin/security/sessions/revoke-others', { method: 'POST' }); load(); };
    $('#regen').onclick = async () => {
      if (!await confirmBox('Generate new recovery codes? Your old codes stop working immediately.')) return;
      try { const r = await adminApi('/admin/security/recovery-codes', { method: 'POST' }); const m = modal(`<h3>New recovery codes</h3><p class="notice warn">Shown once. Store them offline.</p><ul class="codes">${r.recoveryCodes.map(c => `<li>${esc(c)}</li>`).join('')}</ul><div class="actions"><button class="btn btn-primary" id="ok">Done</button></div>`); $('#ok', m).onclick = () => { m.close(); load(); }; } catch (e) { msg(M, e.message); }
    };
    $('#replace').onclick = async () => {
      try {
        const s = await adminApi('/admin/totp/setup', { method: 'POST' });
        const m = modal(`<h3>Replace authenticator device</h3><p>Scan this QR code with Google Authenticator, then enter the 6-digit code to confirm. Your old device stops working only after you confirm.</p><div class="qr"><img src="${s.qr}" alt="QR code" width="240" height="240"></div><p class="small">Manual key: <code class="secret">${esc(s.secret)}</code></p><form id="rf"><div class="field"><label for="rc">6-digit code</label><input id="rc" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required></div><div class="msg" id="rm2"></div><div class="actions"><button class="btn btn-primary">Confirm</button></div></form>`);
        $('#rf', m).onsubmit = async e => { e.preventDefault(); try { const r = await adminApi('/admin/totp/enable', { method: 'POST', body: { code: $('#rc', m).value } }); m.close(); const m2 = modal(`<h3>Device replaced. New recovery codes</h3><ul class="codes">${r.recoveryCodes.map(c => `<li>${esc(c)}</li>`).join('')}</ul><div class="actions"><button class="btn btn-primary" id="ok">Done</button></div>`); $('#ok', m2).onclick = () => { m2.close(); load(); }; } catch (err) { msg($('#rm2', m), err.message); } };
      } catch (e) { msg(M, e.message); }
    };
    const pf = $('#apw');
    pf.onsubmit = async e => {
      e.preventDefault(); clearMsg(M);
      const b = Object.fromEntries(new FormData(pf));
      if (b.newPassword !== b.newPassword2) return msg(M, 'The new passwords do not match.');
      await busy($('button', pf), async () => { try { await adminApi('/admin/security/password', { method: 'POST', body: { currentPassword: b.currentPassword, newPassword: b.newPassword } }); pf.reset(); msg(M, 'Password changed. Other sessions were signed out.', 'success'); } catch (err) { msg(M, err.message); } });
    };
    if (!isSuper) return;
    $$('.super').forEach(x => x.hidden = false);
    let ep = 0, ap = 0;
    const events = async () => {
      const d = await adminApi('/admin/security/events?page=' + ep);
      $('#events').innerHTML = `<div class="table-wrap"><table><thead><tr><th>When</th><th>Event</th><th>Account</th><th>IP</th></tr></thead><tbody>${d.events.map(x => `<tr><td>${fmtDate(x.created_at)}</td><td>${esc(x.event)}</td><td>${esc(x.email || '')}</td><td>${esc(x.ip || '')}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No events.</td></tr>'}</tbody></table></div><div class="pager"><button class="btn btn-outline btn-sm" id="ep" ${ep ? '' : 'disabled'}>Newer</button><button class="btn btn-outline btn-sm" id="en" ${d.events.length < d.pageSize ? 'disabled' : ''}>Older</button></div>`;
      $('#ep').onclick = () => { ep--; events(); }; $('#en').onclick = () => { ep++; events(); };
      $('#failed').innerHTML = d.failed.length ? `<div class="table-wrap"><table><thead><tr><th>Target (last 24h)</th><th>Failed attempts</th><th>Last attempt</th></tr></thead><tbody>${d.failed.map(x => `<tr><td>${esc(x.key)}</td><td>${x.attempts}</td><td>${fmtDate(x.last_attempt)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No failed sign-ins in the last 24 hours.</p>';
    };
    const audits = async () => {
      const d = await adminApi('/admin/audit?page=' + ap);
      $('#audit').innerHTML = `<div class="table-wrap"><table><thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Target</th></tr></thead><tbody>${d.entries.map(x => `<tr><td>${fmtDate(x.created_at)}</td><td>${esc(x.actor || 'system')}</td><td>${esc(x.action)}</td><td class="small">${esc(x.target_type || '')} ${esc((x.target_id || '').slice(0, 8))}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No entries.</td></tr>'}</tbody></table></div><div class="pager"><button class="btn btn-outline btn-sm" id="ap" ${ap ? '' : 'disabled'}>Newer</button><button class="btn btn-outline btn-sm" id="an" ${d.entries.length < d.pageSize ? 'disabled' : ''}>Older</button></div>`;
      $('#ap').onclick = () => { ap--; audits(); }; $('#an').onclick = () => { ap++; audits(); };
    };
    const admins = async () => {
      const { admins: list } = await adminApi('/admin/admins');
      const roles = ['super_admin', 'membership_admin', 'content_admin', 'support_admin'];
      $('#admins').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Administrator</th><th>Role</th><th>2FA</th><th>Status</th><th></th></tr></thead><tbody>${list.map(a => `<tr><td>${esc(a.email)}<br><span class="small muted">Last sign-in ${fmtDate(a.last_login_at) || 'never'}</span></td><td><select data-role="${a.id}" aria-label="Role for ${esc(a.email)}">${roles.map(r => `<option ${r === a.role ? 'selected' : ''}>${r}</option>`).join('')}</select></td><td>${flag(a.totp_enabled)}</td><td>${a.status}</td><td><button class="btn btn-outline btn-sm" data-2fa="${a.id}">Reset 2FA</button> ${a.id === undefined ? '' : `<button class="btn btn-outline btn-sm" data-st="${a.id}" data-to="${a.status === 'active' ? 'suspended' : 'active'}">${a.status === 'active' ? 'Suspend' : 'Reactivate'}</button>`}</td></tr>`).join('')}</tbody></table></div><p class="muted small">New administrators are created only through the controlled command-line provisioning step. See the admin setup guide.</p>`;
      $$('[data-role]').forEach(s => s.onchange = async () => { try { await adminApi(`/admin/admins/${s.dataset.role}/role`, { method: 'PUT', body: { role: s.value } }); msg(M, 'Role updated. That administrator was signed out.', 'success'); } catch (e) { msg(M, e.message); } admins(); });
      $$('[data-2fa]').forEach(b => b.onclick = async () => { if (!await confirmBox('Reset two-factor authentication for this administrator? They must enrol a new device at next sign-in.')) return; try { await adminApi(`/admin/admins/${b.dataset['2fa']}/reset-2fa`, { method: 'POST' }); msg(M, '2FA reset.', 'success'); admins(); } catch (e) { msg(M, e.message); } });
      $$('[data-st]').forEach(b => b.onclick = async () => { try { await adminApi(`/admin/admins/${b.dataset.st}/status`, { method: 'POST', body: { status: b.dataset.to } }); admins(); } catch (e) { msg(M, e.message); } });
    };
    events(); audits(); admins();
  }
};
await pages[page]?.();
