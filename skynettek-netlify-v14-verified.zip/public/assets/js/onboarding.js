// One-time onboarding: exactly five questions, one per screen, saved as you go, resumable after sign-in.
import { $, api, esc, msg, clearMsg, busy, whoami } from './app.js';

const me = await whoami();
if (!me) { location.replace('/'); await new Promise(() => {}); }
if (me.onboardingComplete) { location.replace('/dashboard.html'); await new Promise(() => {}); }

$('#so').onclick = async () => { try { await api('/auth/logout', { method: 'POST' }); } finally { location.replace('/'); } };

const root = $('#ob');
let data;
try { data = await api('/me/onboarding'); } catch (e) { root.innerHTML = `<div class="msg show error">${esc(e.message)}</div>`; await new Promise(() => {}); }
if (data.complete) { location.replace('/dashboard.html'); await new Promise(() => {}); }

const Q = data.questions, N = Q.length;
const answers = { ...data.answers };
const firstOpen = () => { const i = Q.findIndex(q => !answers[q.id]); return i === -1 ? N - 1 : i; };
// The learning-path question shows each group's official logo (decorative: the option text names the group).
const AI = '/assets/img/ai-workspace-logo.webp', FX = '/assets/img/spacefx-logo.webp';
const LOGOS = { 'AI Powered Workspace': [AI], 'SPACEFX Trading Group': [FX], Both: [AI, FX] };
const logos = (q, o) => q.id === 'path' && LOGOS[o] ? `<span class="ob-logos">${LOGOS[o].map(src => `<img src="${src}" alt="" width="40" height="40">`).join('')}</span>` : '';
let step = Math.min(Math.max(firstOpen(), 0), N - 1);

function render(focus = false) {
  const q = Q[step];
  root.innerHTML = `<div class="ob-head"><b>Question ${step + 1} of ${N}</b><span>${Math.round((step / N) * 100)}% done</span></div>
    <div class="ob-bar" role="progressbar" aria-valuemin="0" aria-valuemax="${N}" aria-valuenow="${step + 1}" aria-label="Onboarding progress"><i style="width:${((step + 1) / N) * 100}%"></i></div>
    <div class="msg" id="om"></div>
    <form id="of" novalidate><fieldset class="ob-q"><legend id="oq" tabindex="-1">${esc(q.label)}</legend>${q.help ? `<p class="ob-help">${esc(q.help)}</p>` : ''}
      ${q.options.map((o, i) => `<label class="ob-opt"><input type="radio" name="${esc(q.id)}" value="${esc(o)}" ${answers[q.id] === o ? 'checked' : ''} ${i === 0 ? 'required' : ''}> ${logos(q, o)}<span>${esc(o)}</span></label>`).join('')}</fieldset>
      <div class="ob-actions">${step > 0 ? '<button type="button" class="a-back" id="ob-back">Back</button>' : ''}<button type="submit" class="a-btn" id="ob-next">${step === N - 1 ? 'Finish' : 'Next'}</button></div></form>`;
  const m = $('#om'), f = $('#of');
  f.addEventListener('change', e => { if (e.target.name === q.id) { answers[q.id] = e.target.value; clearMsg(m); } });
  $('#ob-back')?.addEventListener('click', () => { step--; render(true); });
  f.onsubmit = async e => {
    e.preventDefault(); clearMsg(m);
    if (!answers[q.id]) return msg(m, 'Please choose an answer to continue.');
    await busy($('#ob-next'), async () => {
      try {
        if (step < N - 1) { await api('/me/onboarding/draft', { method: 'PUT', body: { answers, step: step + 1 } }); step++; render(true); return; }
        await api('/me/onboarding/complete', { method: 'POST', body: { answers } });
        root.innerHTML = '<div class="ob-done"><h2>You are all set</h2><p class="a-small">Taking you to your dashboard…</p></div>';
        location.replace('/dashboard.html');
      } catch (err) {
        if (err.data?.errors) { const bad = Q.findIndex(x => err.data.errors[x.id]); if (bad >= 0) { delete answers[Q[bad].id]; step = bad; render(true); msg($('#om'), err.data.errors[Q[bad].id]); return; } }
        msg(m, err.message);
      }
    });
  };
  if (focus) { $('#oq').focus({ preventScroll: true }); window.scrollTo(0, 0); }
}
render();
