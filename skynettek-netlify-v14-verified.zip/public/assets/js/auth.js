// Sign in / Create account / Forgot password: the first screen of the app (no landing page).
import { $, $$, api, esc, msg, clearMsg, busy, whoami, COUNTRIES, DIAL, NG_STATES, AGE_RANGES, LANGS } from './app.js';
import { beginLaunch } from './launch.js';
const launch = beginLaunch(); // starts the icon entrance immediately; the welcome screen is revealed once the session check settles

/* ---- referral code: capture from the link, keep it across Sign in / Create account switches ---- */
const REF_RE = /^[A-Za-z0-9]{4,20}$/;
let refCode = '';
try {
  const fromUrl = new URLSearchParams(location.search).get('ref');
  if (fromUrl && REF_RE.test(fromUrl)) { refCode = fromUrl.toUpperCase(); try { localStorage.setItem('sky_ref', refCode); } catch { /* storage unavailable: kept in memory */ } }
  else { const saved = localStorage.getItem('sky_ref'); if (saved && REF_RE.test(saved)) refCode = saved.toUpperCase(); }
} catch { /* ignore */ }
if (refCode) { $('#refCode').textContent = refCode; $('#refChip').hidden = false; }

const goAfterAuth = me => { location.replace(me?.onboardingComplete ? '/dashboard.html' : '/onboarding.html'); };

/* ---- modes: welcome (default) | signin | signup | forgot. Deep links (/#signin, /#signup, /?ref=CODE#signup) skip the welcome step. ---- */
const COPY = {
  signin: ['Welcome back', 'Sign in to continue your learning journey.'],
  signup: ['Create your account', 'Join SN Learning Platform. It only takes a minute.'],
  forgot: ['Reset your password', 'Enter your email and we will send you a reset link.']
};
const FORMS = { signin: $('#sf'), signup: $('#rf'), forgot: $('#ff') };
const TITLES = { welcome: 'Welcome', signin: 'Sign In', signup: 'Create Account', forgot: 'Forgot Password' };
let mode = '';
function setMode(next, { updateUrl = true, focus = false } = {}) {
  if (next !== 'welcome' && !COPY[next]) next = 'welcome';
  mode = next; clearMsg($('#am'));
  const welcome = next === 'welcome';
  $('#welcome').hidden = !welcome; $('#authPanel').hidden = welcome;
  if (!welcome) {
    for (const [k, f] of Object.entries(FORMS)) f.hidden = k !== next;
    $('#aTitle').textContent = COPY[next][0]; $('#aSub').textContent = COPY[next][1];
    $('#tabIn').setAttribute('aria-pressed', String(next === 'signin')); $('#tabUp').setAttribute('aria-pressed', String(next === 'signup'));
  }
  document.title = TITLES[next] + ' | SN Learning Platform';
  if (updateUrl) {
    // new history entry so the browser Back button returns to the previous step; the ?ref= query is always kept
    history.pushState(null, '', location.pathname + location.search + (welcome ? '' : '#' + next));
  }
  if (focus) $(welcome ? '#wTitle' : '#aTitle')?.focus({ preventScroll: true }); // moves screen-reader and keyboard focus to the new step without opening the on-screen keyboard
}
$$('[data-mode]').forEach(el => el.addEventListener('click', e => { e.preventDefault(); setMode(el.dataset.mode, { focus: true }); window.scrollTo(0, 0); }));
window.addEventListener('popstate', () => setMode(location.hash.slice(1) || 'welcome', { updateUrl: false }));
setMode(location.hash.slice(1) || 'welcome', { updateUrl: false }); // first paint: no waiting for the session check

/* ---- already signed in in this browser session: skip the launch and the form ---- */
// The session check never blocks the screen for more than 4 seconds; if it answers later with a valid session we still redirect.
{
  const meP = whoami();
  const me = await Promise.race([meP, new Promise(r => setTimeout(() => r(undefined), 4000))]);
  if (me) { goAfterAuth(me); await new Promise(() => {}); }
  launch.reveal();
  meP.then(late => { if (late) goAfterAuth(late); });
}

/* ---- show / hide password ---- */
$$('.a-eye').forEach(b => b.onclick = () => {
  const i = $('#' + b.dataset.eye), show = i.type === 'password';
  i.type = show ? 'text' : 'password'; b.setAttribute('aria-pressed', String(show)); b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
});

const m = $('#am');

/* ---- sign in ---- */
$('#sf').onsubmit = async e => {
  e.preventDefault(); clearMsg(m); $('#resend').hidden = true;
  const b = Object.fromEntries(new FormData(e.target));
  if (!b.email?.trim() || !b.password) return msg(m, 'Enter your email and password.');
  await busy($('button[type=submit]', e.target), async () => {
    try {
      await api('/auth/login', { method: 'POST', body: b });
      goAfterAuth(await whoami());
    } catch (err) { msg(m, err.message); if (err.data?.code === 'unverified') $('#resend').hidden = false; }
  });
};
$('#resend-btn').onclick = async () => {
  const email = $('#si-email').value;
  try { await api('/auth/resend-verification', { method: 'POST', body: { email } }); msg(m, 'If that account needs verification, a new link is on its way.', 'success'); } catch (err) { msg(m, err.message); }
};

/* ---- create account ---- */
{
  const f = $('#rf'), cs = $('#su-country');
  cs.innerHTML = '<option value="">Select your country</option>' + COUNTRIES.map(c => `<option>${esc(c)}</option>`).join('');
  $('#su-age').innerHTML = '<option value="">Prefer not to say</option>' + AGE_RANGES.map(c => `<option>${c}</option>`).join('');
  $('#su-lang').innerHTML = '<option value="">English (default)</option>' + LANGS.map(c => `<option>${c}</option>`).join('');
  const holder = $('#region-holder');
  const regionField = country => {
    holder.innerHTML = country === 'Nigeria'
      ? `<label for="region">State</label><div class="a-input a-sel"><select id="region" name="region"><option value="">Select state</option>${NG_STATES.map(s => `<option>${s}</option>`).join('')}</select></div>`
      : `<label for="region">State, province or region</label><div class="a-input"><input id="region" name="region" type="text" maxlength="100" autocomplete="address-level1"></div>`;
  };
  regionField('');
  cs.onchange = () => { regionField(cs.value); const w = $('#su-wa'); if (!w.value || /^\+\d{1,4}$/.test(w.value)) w.value = DIAL[cs.value] || w.value; };
  f.onsubmit = async e => {
    e.preventDefault(); clearMsg(m);
    const d = new FormData(f), b = Object.fromEntries(d);
    b.acceptTerms = d.has('acceptTerms'); b.understandsRequirements = d.has('understandsRequirements');
    if (!b.fullName?.trim() || !b.email?.trim() || !b.country || !b.whatsapp?.trim() || !b.password) return msg(m, 'Please fill in your name, email, country, WhatsApp number and password.');
    if (b.password !== b.password2) return msg(m, 'The two passwords do not match.');
    if (!b.acceptTerms || !b.understandsRequirements) return msg(m, 'Please tick both agreement boxes to continue.');
    delete b.password2;
    if (refCode) b.ref = refCode; // the server verifies the code belongs to a real member before crediting anything
    await busy($('button[type=submit]', f), async () => {
      try {
        const r = await api('/auth/register', { method: 'POST', body: b });
        try { localStorage.removeItem('sky_ref'); } catch { /* ignore */ }
        if (r.needsVerification) { f.hidden = true; msg(m, 'Account created. Check your email and open the verification link, then sign in to finish setting up. If nothing arrives in a few minutes, check spam or use "Resend verification" on the sign-in form.', 'success'); $('#tabIn').focus(); }
        else location.replace('/onboarding.html');
      } catch (err) { msg(m, err.message); }
    });
  };
}

/* ---- forgot password ---- */
$('#ff').onsubmit = async e => {
  e.preventDefault(); clearMsg(m);
  const email = $('#fp-email').value.trim();
  if (!email) return msg(m, 'Enter your email address.');
  await busy($('button[type=submit]', e.target), async () => {
    try { await api('/auth/forgot', { method: 'POST', body: { email } }); msg(m, 'If an account exists for that email, a reset link has been sent. It is valid for one hour.', 'success'); }
    catch (err) { msg(m, err.message); }
  });
};

