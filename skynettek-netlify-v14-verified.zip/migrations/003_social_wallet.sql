-- 003: member profiles for discovery, friends, private messages, referrals, wallet ledger, ebook store, withdrawals, questionnaires.
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS display_name text;
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS discoverable boolean NOT NULL DEFAULT true;
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS show_friend_count boolean NOT NULL DEFAULT true;
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS referral_code text;
ALTER TABLE user_profiles ADD COLUMN IF NOT EXISTS referred_by uuid REFERENCES users(id) ON DELETE SET NULL;
UPDATE user_profiles SET username = 'member' || substr(md5(user_id::text), 1, 8) WHERE username IS NULL;
UPDATE user_profiles SET display_name = split_part(full_name, ' ', 1) WHERE display_name IS NULL;
UPDATE user_profiles SET referral_code = 'SKY' || upper(substr(md5(user_id::text || 'ref'), 1, 6)) WHERE referral_code IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS user_profiles_username_uq ON user_profiles (lower(username));
CREATE UNIQUE INDEX IF NOT EXISTS user_profiles_refcode_uq ON user_profiles (referral_code);
CREATE INDEX IF NOT EXISTS user_profiles_referred_by_idx ON user_profiles (referred_by);

CREATE TABLE IF NOT EXISTS friend_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  addressee_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','declined','cancelled','removed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  CHECK (requester_id <> addressee_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS friend_pair_active_uq ON friend_requests (LEAST(requester_id, addressee_id), GREATEST(requester_id, addressee_id)) WHERE status IN ('pending','accepted');
CREATE INDEX IF NOT EXISTS friend_requests_addressee_idx ON friend_requests (addressee_id, status);
CREATE INDEX IF NOT EXISTS friend_requests_requester_idx ON friend_requests (requester_id, status);
CREATE TABLE IF NOT EXISTS user_blocks (
  blocker_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (blocker_id, blocked_id),
  CHECK (blocker_id <> blocked_id)
);
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_a uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_b uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_message_at timestamptz,
  a_read_seq bigint NOT NULL DEFAULT 0,
  b_read_seq bigint NOT NULL DEFAULT 0,
  a_delivered_seq bigint NOT NULL DEFAULT 0,
  b_delivered_seq bigint NOT NULL DEFAULT 0,
  last_seq bigint NOT NULL DEFAULT 0,
  activity_at timestamptz NOT NULL DEFAULT now(),
  CHECK (user_a < user_b),
  UNIQUE (user_a, user_b)
);
CREATE INDEX IF NOT EXISTS conversations_a_idx ON conversations (user_a, last_message_at DESC);
CREATE INDEX IF NOT EXISTS conversations_b_idx ON conversations (user_b, last_message_at DESC);
CREATE TABLE IF NOT EXISTS messages (
  seq bigserial PRIMARY KEY,
  id uuid NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  client_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (sender_id, client_id)
);
CREATE INDEX IF NOT EXISTS messages_conv_idx ON messages (conversation_id, seq DESC);
CREATE INDEX IF NOT EXISTS messages_updated_idx ON messages (updated_at);
CREATE TABLE IF NOT EXISTS message_reactions (
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emoji text NOT NULL CHECK (char_length(emoji) BETWEEN 1 AND 16),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);
CREATE TABLE IF NOT EXISTS message_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reported_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_id uuid REFERENCES messages(id) ON DELETE SET NULL,
  message_snapshot text,
  reason text NOT NULL,
  details text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','reviewing','actioned','dismissed')),
  handled_by uuid REFERENCES users(id),
  handled_at timestamptz,
  resolution text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS message_reports_status_idx ON message_reports (status, created_at DESC);

CREATE TABLE IF NOT EXISTS referral_rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event text NOT NULL CHECK (event IN ('registration','class','ebook')),
  source_id text NOT NULL,
  amount int NOT NULL CHECK (amount > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','available','reversed')),
  release_at timestamptz NOT NULL DEFAULT now(),
  available_at timestamptz,
  reversed_at timestamptz,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (event, source_id),
  CHECK (referrer_id <> referred_id)
);
CREATE INDEX IF NOT EXISTS referral_rewards_referrer_idx ON referral_rewards (referrer_id, status);
CREATE TABLE IF NOT EXISTS wallets (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  balance int NOT NULL DEFAULT 0 CHECK (balance >= 0),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO wallets(user_id) SELECT id FROM users WHERE role = 'member' ON CONFLICT (user_id) DO NOTHING;
CREATE TABLE IF NOT EXISTS wallet_ledger (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('referral_reward','reward_reversal','class_purchase','ebook_purchase','withdrawal_reserve','withdrawal_release','adjustment')),
  amount int NOT NULL CHECK (amount <> 0),
  reference text NOT NULL UNIQUE,
  idempotency_key text UNIQUE,
  description text,
  related_type text,
  related_id text,
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS wallet_ledger_user_idx ON wallet_ledger (user_id, id DESC);
CREATE OR REPLACE FUNCTION ledger_immutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'wallet_ledger rows cannot be changed or deleted';
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS wallet_ledger_no_change ON wallet_ledger;
CREATE TRIGGER wallet_ledger_no_change BEFORE UPDATE OR DELETE ON wallet_ledger FOR EACH ROW EXECUTE FUNCTION ledger_immutable();

ALTER TABLE trainings ADD COLUMN IF NOT EXISTS price_ngn int CHECK (price_ngn IS NULL OR price_ngn >= 0);
ALTER TABLE enrollments ADD COLUMN IF NOT EXISTS paid_with text;
ALTER TABLE enrollments ADD COLUMN IF NOT EXISTS price_paid int;
ALTER TABLE enrollments ADD COLUMN IF NOT EXISTS payment_reference text;
ALTER TABLE enrollments ADD COLUMN IF NOT EXISTS group_verified_at timestamptz;
ALTER TABLE enrollments ADD COLUMN IF NOT EXISTS group_verified_by uuid REFERENCES users(id);

ALTER TABLE ebooks ADD COLUMN IF NOT EXISTS price_ngn int CHECK (price_ngn IS NULL OR price_ngn >= 0);
ALTER TABLE ebooks ADD COLUMN IF NOT EXISTS file_key text;
ALTER TABLE ebooks ADD COLUMN IF NOT EXISTS file_name text;
ALTER TABLE ebooks ADD COLUMN IF NOT EXISTS file_size int;
CREATE TABLE IF NOT EXISTS ebook_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ebook_id uuid NOT NULL REFERENCES ebooks(id) ON DELETE RESTRICT,
  price int NOT NULL CHECK (price >= 0),
  reference text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed','refunded')),
  downloads_used int NOT NULL DEFAULT 0,
  max_downloads int NOT NULL DEFAULT 1,
  recovery_requested_at timestamptz,
  last_link_at timestamptz,
  last_download_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, ebook_id)
);
CREATE TABLE IF NOT EXISTS bank_accounts (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  bank_name text NOT NULL,
  bank_code text,
  account_name text NOT NULL,
  account_number_enc text NOT NULL,
  account_last4 text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS withdrawals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount int NOT NULL CHECK (amount >= 1000),
  fee int NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processing','paid','failed','reversed')),
  reference text NOT NULL UNIQUE,
  bank_name text NOT NULL,
  account_name text NOT NULL,
  account_number_enc text NOT NULL,
  account_last4 text NOT NULL,
  payout_reference text,
  failure_reason text,
  processed_by uuid REFERENCES users(id),
  processed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS withdrawals_status_idx ON withdrawals (status, created_at DESC);
CREATE INDEX IF NOT EXISTS withdrawals_user_idx ON withdrawals (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS questionnaire_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  questionnaire_slug text NOT NULL,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','submitted')),
  answers jsonb NOT NULL DEFAULT '{}'::jsonb,
  current_step int NOT NULL DEFAULT 0,
  result jsonb,
  definition_version int NOT NULL DEFAULT 1,
  started_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  submitted_at timestamptz,
  UNIQUE (questionnaire_slug, user_id)
);
CREATE INDEX IF NOT EXISTS questionnaire_responses_idx ON questionnaire_responses (questionnaire_slug, status, submitted_at DESC);
CREATE TABLE IF NOT EXISTS questionnaire_settings (
  slug text PRIMARY KEY,
  status text NOT NULL DEFAULT 'published' CHECK (status IN ('draft','published')),
  updated_by uuid REFERENCES users(id),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- The Forex Trading Mastery ebook: the only ebook that can be bought with the wallet (NGN 8,000). The file ships privately inside the deployment.
INSERT INTO ebooks(slug,title,description,cover_path,selar_url,price_label,sort_order,published,price_ngn,file_key,file_name,file_size)
SELECT 'forex-trading-mastery','Forex Trading Mastery: The Complete Guide','A complete guide to Forex trading education: market structure, risk management and trading discipline. Education only, with no promise of profit.','/assets/img/book-forex-trading.webp',
  COALESCE((SELECT value FROM settings WHERE key='selar_forex_url'),'https://selar.com/017j91l781'),'NGN 8,000',0,true,8000,'bundled:forex-trading-mastery.pdf','Forex_Trading_Mastery_Complete_Guide.pdf',13019694
WHERE NOT EXISTS (SELECT 1 FROM ebooks WHERE slug='forex-trading-mastery');
UPDATE ebooks SET price_ngn=8000, file_key='bundled:forex-trading-mastery.pdf', file_name='Forex_Trading_Mastery_Complete_Guide.pdf', file_size=13019694 WHERE slug='forex-trading-mastery' AND file_key IS NULL;
