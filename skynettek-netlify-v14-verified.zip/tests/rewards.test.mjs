import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { SQL, DEFAULT_CONFIG, REG_REWARD, CLASS_REWARD, EBOOK_REWARD, QUALIFYING_REQUIRED, minMessage } from '../netlify/lib/wallet.mjs';

const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? (e.name === 'node_modules' ? [] : walk(path.join(d, e.name))) : [path.join(d, e.name)]);
const read = f => fs.readFileSync(f, 'utf8');

test('default policy: ₦100 registration, ₦200 class, ₦200 ebook, 3 qualifying referrals', () => {
  assert.deepEqual([REG_REWARD, CLASS_REWARD, EBOOK_REWARD, QUALIFYING_REQUIRED], [100, 200, 200, 3]);
  assert.equal(DEFAULT_CONFIG.qualifying_required, 3);
  assert.match(minMessage(1000), /₦1,000/);
});

test('there is no lifetime earnings cap anywhere in the code, schema or pages', () => {
  const files = [...walk('netlify'), ...walk('migrations'), ...walk('public').filter(f => /\.(js|html|css)$/.test(f))];
  const hits = [];
  for (const f of files) { const t = read(f); if (/5,?000/.test(t) && /(lifetime|cap\b|maximum|max earn|earning limit)/i.test(t.split('\n').filter(l => /5,?000/.test(l)).join('\n'))) hits.push(f); }
  assert.deepEqual(hits, []);
  // crediting never compares against cumulative earnings
  assert.ok(!/SUM\(amount\)[^)]*\)\s*[<>]=?\s*5000/.test(SQL.creditReward));
});

test('crediting is one atomic, idempotent statement with server-side guards', () => {
  const s = SQL.creditReward;
  for (const part of ['INSERT INTO referral_rewards', 'UPDATE wallets', 'INSERT INTO wallet_ledger', 'INSERT INTO notifications']) assert.ok(s.includes(part), part);
  assert.ok(s.includes('ON CONFLICT (event, source_id)'));                 // no duplicate reward for the same event
  assert.ok(s.includes('$1::uuid <> $2::uuid'));                            // no self-referral
  assert.ok(s.includes('p.referred_by=$1::uuid'));                          // attribution must match the stored referrer
  assert.ok(s.includes("'reward:'||rw.id::text"));                          // one ledger key and one notification key per reward
  assert.ok(s.includes('qualifying_referrals_v'));                          // class/ebook rewards need a verified payment
  assert.ok(!/status='reversed'.*DO UPDATE/s.test(s) && s.includes("status IN ('pending','failed')")); // a reversed reward is never re-credited
});

test('notification text is built from the credited amount, not hard-coded', () => {
  assert.ok(SQL.creditReward.includes("to_char(rw.amount, 'FM999,999,999')"));
  assert.ok(!/₦100\b|₦200\b/.test(SQL.creditReward + SQL.settle));
});

test('withdrawal SQL enforces balance, minimum and the qualifying-referral rule inside the same statement that reserves funds', () => {
  const s = SQL.withdraw;
  assert.ok(s.includes('balance >= $2::int'));
  assert.ok(s.includes('$2::int >= $6::int'));
  assert.ok(/count\(DISTINCT referred_id\) FROM qualifying_referrals_v WHERE referrer_id=\$1\) >= \$5::int/.test(s));
  assert.ok(s.includes('withdrawal_reserve'));
});

test('migration: qualifying view counts only verified paid events, repair never blanket-approves', () => {
  const m = read('migrations/005_rewards_automation.sql');
  assert.ok(m.includes("e.paid_with IS DISTINCT FROM 'wallet'") && m.includes("tp.status = 'approved'") && m.includes("pp.status = 'approved'"));
  assert.ok(m.includes('reward_repair_log') && m.includes("'eligible_not_credited'") && m.includes("'awaiting_verification'") && m.includes("'unverified_payment'"));
  assert.ok(!/UPDATE referral_rewards SET status\s*=\s*'available'(?![^;]*reward_repair_log)/.test(m), 'status change must be driven by the evidence log');
  assert.ok(!/DELETE FROM|TRUNCATE|DROP TABLE/i.test(m));
});

test('migration statements split cleanly for the project migration runner', () => {
  const st = read('migrations/005_rewards_automation.sql').split(/;\s*\n/).map(x => x.trim()).filter(Boolean);
  assert.ok(st.length > 10);
  for (const x of st) assert.equal((x.match(/'/g) || []).length % 2, 0, x.slice(0, 60));
});
