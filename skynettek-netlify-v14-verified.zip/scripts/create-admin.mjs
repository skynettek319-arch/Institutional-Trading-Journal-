// Controlled admin provisioning. Run locally against your database:
//   DATABASE_URL=... node scripts/create-admin.mjs you@example.com super_admin
// The password is typed at the prompt (hidden). Nothing is hardcoded and there is no public admin signup.
import readline from 'node:readline';
import bcrypt from 'bcryptjs';
import { neon } from '@neondatabase/serverless';
const ROLES = ['super_admin', 'membership_admin', 'content_admin', 'support_admin'];
const [email, role = 'super_admin'] = process.argv.slice(2);
if (!process.env.DATABASE_URL || !email || !ROLES.includes(role)) {
  console.error('Usage: DATABASE_URL=... node scripts/create-admin.mjs <email> [' + ROLES.join('|') + ']'); process.exit(1);
}
function ask(prompt) {
  return new Promise(res => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = s => { if (s.includes(prompt)) process.stdout.write(s); };
    rl.question(prompt, a => { rl.close(); process.stdout.write('\n'); res(a); });
  });
}
const pw = await ask('Admin password (min 14 chars, letters and numbers): ');
const pw2 = await ask('Repeat password: ');
if (pw !== pw2 || pw.length < 14 || !/[A-Za-z]/.test(pw) || !/\d/.test(pw)) { console.error('Passwords differ or are too weak.'); process.exit(1); }
const sql = neon(process.env.DATABASE_URL);
const run = (t, p = []) => (typeof sql.query === "function" ? sql.query(t, p) : sql(t, p));
const hash = await bcrypt.hash(pw, 12);
const rows = await run(
  `INSERT INTO users(email,password_hash,role,email_verified,password_changed_at) VALUES($1,$2,$3,true,now())
   ON CONFLICT ((lower(email))) DO UPDATE SET role=EXCLUDED.role, password_hash=EXCLUDED.password_hash, email_verified=true, status='active', password_changed_at=now()
   RETURNING id`, [email.toLowerCase(), hash, role]);
await run('INSERT INTO audit_logs(action,target_type,target_id,details) VALUES($1,$2,$3,$4)', ['admin_provisioned', 'user', rows[0].id, JSON.stringify({ role, via: 'script' })]);
console.log(`Admin ${email} provisioned as ${role}. Sign in at /admin-login.html — you will be asked to enrol Google Authenticator on first login.`);
