// Launch animation: the complete SN icon (one <img>) fades in at the centre of a navy surface, then moves up and
// shrinks into its place at the top of the welcome screen (FLIP: only transform and opacity animate, so no layout shift).
// It plays once per browser session and never for an already signed-in member (auth.js redirects before reveal()).
const html = document.documentElement;
const MIN_SHOW = 800;      // ms the icon stays centred, so the entrance is never cut short
const MOVE = 900;          // ms for the move-up transition (keep in sync with launch.css transitions)
const EASE = 'cubic-bezier(.22,1,.36,1)';
const noop = { reveal() {} };

export function beginLaunch() {
  const mark = document.getElementById('snMark');
  if (!html.classList.contains('launching') || !mark) return noop;
  const t0 = performance.now();
  const r = mark.getBoundingClientRect();
  const vw = window.innerWidth, vh = window.innerHeight;
  const size = Math.min(176, Math.min(vw, vh) * 0.4);
  const s = size / r.width;
  const dx = vw / 2 - (r.left + r.width / 2), dy = vh / 2 - (r.top + r.height / 2);
  const centred = k => `translate(${dx}px,${dy}px) scale(${s * k})`;
  mark.style.transition = 'none'; mark.style.transform = centred(0.9); mark.style.opacity = '0';
  void mark.offsetWidth; // commit the start state
  mark.style.transition = `opacity 600ms ease, transform 800ms ${EASE}`;
  mark.style.transform = centred(1); mark.style.opacity = '1';
  let done = false;
  return {
    reveal() {
      if (done) return; done = true;
      const wait = Math.max(0, MIN_SHOW - (performance.now() - t0));
      setTimeout(() => {
        mark.style.transition = `transform ${MOVE}ms ${EASE}`;
        mark.style.transform = 'none';
        html.classList.add('launch-out');
        setTimeout(() => {
          html.classList.remove('launching', 'launch-out');
          mark.removeAttribute('style');
          try { sessionStorage.setItem('sn_launch', '1'); } catch { /* ignore */ }
        }, MOVE + 50);
      }, wait);
    }
  };
}
