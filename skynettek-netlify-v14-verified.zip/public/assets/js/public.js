/* referral capture */
try { const rc = new URLSearchParams(location.search).get('ref'); if (rc && /^[A-Za-z0-9]{4,20}$/.test(rc)) localStorage.setItem('sky_ref', rc.toUpperCase()); } catch { /* storage unavailable */ }
import { $, $$, api, esc, msg, clearMsg, busy, publicLayout, loadContent, whoami, fixLinks, COUNTRIES, DIAL, NG_STATES, AGE_RANGES, LANGS, badge, nl2br, fmtDay } from './app.js';

const page = document.body.dataset.page;
await publicLayout();
const C = await loadContent();

const FALLBACK_EBOOKS = [
  { title: '30 Days to Start Your AI Automation Company', description: 'A practical roadmap to building, selling and delivering AI-powered automations. By Chika Offor.', cover_path: '/assets/img/book-ai-automation.webp', selar_url: 'https://selar.com/87596eu737' },
  { title: 'Brain Hack: 30 Days to Transform the Way You Think, Learn & Solve Problems', description: 'A 30-day journey covering better food, a stronger body, a clearer mind and smarter thinking. By Chika Offor A.', cover_path: '/assets/img/book-brain-hack.webp', selar_url: 'https://selar.com/5q87881744' }
];
const ebooks = () => (C.ebooks?.length ? C.ebooks : FALLBACK_EBOOKS);
const bookCard = b => `<article class="card book"><img src="${esc(b.cover_path || '/assets/img/sn-icon-192.webp')}" alt="Cover of ${esc(b.title)}" loading="lazy" width="240" height="360">
  <h3>${esc(b.title)}</h3><p>${esc(b.description || '')}</p>${b.price_label ? `<p><strong>${esc(b.price_label)}</strong></p>` : ''}
  <a class="btn btn-primary" href="${esc(b.selar_url)}" target="_blank" rel="noopener noreferrer">Buy on Selar</a></article>`;
const announce = () => C.announcements?.length ? C.announcements.map(a => `<div class="notice"><strong>${esc(a.title)}</strong> <span class="muted small">${fmtDay(a.created_at)}</span><br>${nl2br(a.body)}</div>`).join('') : '';

const pages = {
  ai() { $('#ai-blurb').textContent = C.settings?.home_ai_blurb || 'Learn AI-powered video creation first, with structured lessons, practical exercises and progress tracking. AI automation and more AI skills follow.'; $('#announcements').innerHTML = announce(); },
  spacefx() { $('#fx-blurb').textContent = C.settings?.home_spacefx_blurb || 'A Forex education and trading community. Access is requested by buying the Forex Trading Mastery ebook and submitting proof of purchase for review.'; },
  books() {
    const el = $('#books');
    el.innerHTML = ebooks().map(bookCard).join('');
    fixLinks();
  },
  roadmap() {
    const live = new Map((C.categories || []).map(c => [c.slug, c]));
    $$('[data-cat]').forEach(li => {
      const on = live.has(li.dataset.cat);
      $('.slot', li).innerHTML = on ? `<span class="status-tag s-available">Available</span>${live.get(li.dataset.cat).lessons ? ` <span class="muted small">${live.get(li.dataset.cat).lessons} lesson(s) published</span>` : ' <span class="muted small">Lessons are being added</span>'}` : '<span class="status-tag s-planned">Planned</span>';
    });
  },
  forexpurchase() {
    const url = C.settings.selar_forex_url || 'https://selar.com/017j91l781';
    $$('.buy-forex').forEach(a => { a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer'; });
  },
  contact() {
    const f = $('#cf'), m = $('#cm');
    $('#cemail').textContent = C.settings.support_email || 'skynettek319@gmail.com';
    f.onsubmit = async e => {
      e.preventDefault(); clearMsg(m);
      const b = Object.fromEntries(new FormData(f));
      await busy($('button', f), async () => {
        try { await api('/contact', { method: 'POST', body: b }); f.reset(); msg(m, 'Thank you. Your message was sent and we will reply by email.', 'success'); }
        catch (err) { msg(m, err.message); }
      });
    };
  },
  reset() {
    const token = new URLSearchParams(location.search).get('token');
    const f = $('#rf'), m = $('#rm');
    if (!token) { f.hidden = true; return msg(m, 'This reset link is incomplete. Request a new one.'); }
    f.onsubmit = async e => {
      e.preventDefault(); clearMsg(m);
      const b = Object.fromEntries(new FormData(f));
      if (b.password !== b.password2) return msg(m, 'The two passwords do not match.');
      await busy($('button', f), async () => {
        try { await api('/auth/reset', { method: 'POST', body: { token, password: b.password } }); f.hidden = true; msg(m, 'Password updated. You can now sign in.', 'success'); $('#go').hidden = false; }
        catch (err) { msg(m, err.message); }
      });
    };
  },
  async verify() {
    const token = new URLSearchParams(location.search).get('token'), m = $('#vm');
    if (!token) return msg(m, 'This verification link is incomplete.');
    msg(m, 'Verifying your email…', 'info');
    try { await api('/auth/verify', { method: 'POST', body: { token } }); msg(m, 'Email verified. You can now sign in.', 'success'); $('#go').hidden = false; }
    catch (err) { msg(m, err.message); }
  }
};
await pages[page]?.();
fixLinks();

function splitLetters(el) {
  const label = el.textContent.replace(/\s+/g, ' ').trim();
  el.setAttribute('aria-label', label);
  let n = 0;
  const walk = node => {
    [...node.childNodes].forEach(c => {
      if (c.nodeType === 3) {
        const frag = document.createDocumentFragment();
        c.textContent.split(/(\s+)/).forEach(part => {
          if (!part) return;
          if (/^\s+$/.test(part)) { frag.append(' '); return; }
          const w = document.createElement('span'); w.className = 'w'; w.setAttribute('aria-hidden', 'true');
          [...part].forEach(ch => { const s = document.createElement('span'); s.className = 'ch'; s.style.setProperty('--i', n++); s.textContent = ch; w.append(s); });
          frag.append(w);
        });
        c.replaceWith(frag);
      } else walk(c);
    });
  };
  walk(el);
}
