# SN Learning Platform (formerly the SKY-NET TEK platform)

> **Latest change:** SN launch screen, welcome/auth flow, design tokens, mobile bottom navigation and SN branding. See `docs/SN-REDESIGN-REPORT.md`. **Before deploying, run `npm run migrate`: migration 006 adds posts, comments, reactions, reports and articles.**

AI Powered Workspace + SPACEFX learning ecosystem. Static pages in `public/`, API in one Netlify Function (`netlify/functions/api.mjs`), data in Neon Postgres, private screenshots in Netlify Blobs, email through Resend.

## Status: read this first

This ZIP is **complete source code that has not been deployed or run against a live database, Netlify, Neon, Resend or Google Authenticator.** What was checked: every JS file passes a syntax check, the 7 dependency-free unit tests pass, all internal links and image paths resolve. Everything else is listed in `docs/TEST-REPORT.md` as still needing your environment. Do not treat it as production-ready until you have completed that checklist.

## Quick start (about 30 minutes)

1. **Neon**: create a project at neon.tech, copy the *pooled* connection string.
2. **Install**: `npm install`
3. **Secrets**: copy `.env.example` to `.env` and fill it in. Generate the two keys with `openssl rand -hex 32`.
4. **Database**: `npm run migrate` (creates all tables, the 8 curriculum categories, your two optional ebooks and the Forex checkout setting).
5. **First admin** (only way to create one, no public signup): `npm run create-admin -- you@example.com super_admin`. Password is typed at a hidden prompt (14+ characters).
6. **Run locally**: `npx netlify dev`, open `/admin-login.html`, sign in, then scan the QR code with Google Authenticator and save the recovery codes.
7. **Deploy**: see `docs/DEPLOY.md`.

## Where things are

| Path | What |
|---|---|
| `public/*.html` | 33 pages (marketing, auth, member, admin) |
| `public/assets/js/` | `app.js` core, `public.js`, `member.js`, `admin.js` |
| `netlify/functions/api.mjs` | router, CSRF check, session and permission gates |
| `netlify/lib/routes/` | `public`, `auth`, `member`, `admin` endpoints |
| `migrations/001_init.sql` | schema (20 tables) |
| `scripts/` | `migrate.mjs`, `create-admin.mjs` |
| `tests/` | unit, access-control, and Neon integration tests |
| `docs/` | deployment, admin and 2FA guide, test report |

## Design decisions you should know about

* **New tabs**: public-site links open in a new tab (`NEW_TAB_PUBLIC` in `assets/js/app.js`; set `false` to disable). Dashboard and admin sidebars, and form redirects (register to onboarding, sign-in to dashboard), stay in the same tab because opening a new tab on every dashboard click or after a form submit makes those flows confusing.
* **The WhatsApp invitation is never in the code or database.** It is read from the `SPACEFX_WHATSAPP_INVITE` environment variable on the server, and only returned by `GET /api/spacefx/invite` when the member is active, SPACEFX is `approved`, and an approved purchase record exists. Each release is logged. Set it yourself in Netlify; it is deliberately not in `.env.example`.
* **Approval is never automatic.** The admin must tick "I verified this paid order in the Selar seller dashboard" before the server accepts an approval. Duplicate order references and identical screenshots are flagged automatically.
* **Selar has no integration here.** Verification is manual in your Selar seller dashboard.
* An invitation link cannot stop an approved member from sharing it. The system limits exposure; it cannot control WhatsApp.


## Trainings, payments, events and notifications (v2)

**Member flow (AI trainings):** register, sign in, open *Trainings and events*, tap *Enrol now*. The OPay details appear (stored in Admin settings keys `payment_*`, never public). The member pays, uploads the receipt screenshot, and waits. After you approve it in *Admin > Training enrolments*, a **Request to join SKYNETTEK AI WORK SPACE** button appears. The link is stored per training, is sent only to approved members, and every access is audit-logged.

**Member flow (SPACEFX):** buy the Forex ebook on Selar, upload a screenshot of the Selar purchase email, you approve, then **Request to join SPACEFX** appears.

**Admin:** *Training enrolments* (review receipts, approve, reject, ask for a clearer receipt, revoke), *Trainings, events and notices* (create and edit trainings and events, set the workspace link and fee, send notifications to everyone, AI members, SPACEFX members or one training's students).

**Setup after upgrading**
1. `npm run migrate` (applies `002_trainings_events.sql`, seeds the 3-day AI Video Creation training and the OPay details).
2. In Admin > Trainings, edit the seeded training: set the **fee** and the **workspace join link**.
3. Until Resend is configured, set `REQUIRE_EMAIL_VERIFICATION=false`, otherwise new members cannot verify their email and cannot sign in.
4. Notifications are in-app; decision emails need Resend.

## Version 9: web app shell, friends and messages, wallet and referrals, store, questionnaires

**Navigation:** side navigation with icon buttons (a slide-in drawer on phones, a fixed sidebar on desktop). There are no footers. Settings is the last menu item; About us and Terms of service are the last two entries inside Settings.

**New member features:** Friends (find, request, accept, block, report, friend count), Messages (private chat between accepted friends, emoji picker, reactions, sent/delivered/read status, unread counts), Wallet and referrals, Ebook store and library, eight Questionnaires, bank details and withdrawals, wallet payment for classes.

**Rules implemented**
- Referral rewards: ₦100 when a referred member registers (held 24 hours, admins can reverse), ₦200 when a referred member's class payment is approved AND an admin marks their learning group as verified, ₦200 per wallet ebook purchase. Pending rewards are not spendable or withdrawable.
- Wallet: every credit and debit is a ledger row; ledger rows cannot be changed or deleted; every money action is a single database statement that fully succeeds or fully rolls back; balances can never go below zero. Admin Reconciliation compares each balance with its ledger.
- Withdrawals: minimum ₦1,000 available balance and ₦1,000 per request; funds are reserved immediately; an admin marks a withdrawal paid only after confirming the bank transfer; failed or reversed withdrawals return the money through a ledger credit. No payout provider is connected: payouts are manual.
- Ebooks: only the Forex Trading Mastery ebook can be bought with the wallet (₦8,000). The other ebooks are Selar-only. The file is stored privately inside the deployment (`netlify/private`), is never in the public folder, and is served only after a server-side purchase check. A download counts only when the whole file has been sent.
- Messaging policy: only accepted friends can start or continue a conversation. After unfriending or blocking, the history stays visible but read-only.
- Live delivery uses long polling backed by Neon (a few seconds at most). It is not a WebSocket connection. For a very large audience, move to a managed real-time service.

**Deploy (no new Netlify variables are needed)**
1. Run `migrations/003_social_wallet.sql` once in the Neon SQL Editor.
2. Upload the zip in Netlify (Deploys, Browse to upload).
3. Open `/api/health?k=<first 6 characters of SESSION_PEPPER>&deep=1`. It must say `"problems":"none"` and `"bundledEbookFile":true`.
4. In Admin: set class prices (Classes, events and notices), check the Ebook store, and review the four draft questionnaires.

**Limits to know**
- The new SQL could not be run against a real PostgreSQL database while building. The deep health check above makes your own database validate every new statement.
- Wallet money comes only from referral rewards and admin adjustments; there is no card or bank top-up gateway.
- A member with ledger history cannot be hard-deleted (financial records are kept). Suspend the account instead.
- Four questionnaires (learning profile, AI Powered Workspace, SPACEFX, combined priorities) are the original sign-up questionnaires. The other four are draft content written for this release and should be reviewed.

## Version 10: direct sign-in, branding, five-question onboarding

* **No landing page.** `/` is the Sign in / Create account / Forgot password screen (`public/index.html`, `assets/js/auth.js`, `assets/css/auth.css`). The three views switch on one page via `#signin`, `#signup`, `#forgot`. `/signin.html`, `/register.html` and `/forgot-password.html` remain only as tiny redirect stubs for old bookmarks and emails (they carry `?ref=` through).
* **Referrals.** A `?ref=CODE` link is kept in the URL, in `localStorage` and in memory, so switching between Sign in and Create account never loses it. The server still verifies the code belongs to a real member and credits nothing until registration succeeds. Member referral links are now `/?ref=CODE#signup`.
* **Sessions.** The member cookie is a browser-session cookie (no `Max-Age`): closing the browser requires signing in again. The server-side session row still expires after 7 days. Admin cookies are unchanged.
* **Branding.** Platform pages use the Skynettek logo; AI Powered Workspace pages and cards use `ai-workspace-logo.webp`; SPACEFX pages and cards use `spacefx-logo.webp` (the same artwork as the supplied files). The onboarding path question shows the matching group logos.
* **Onboarding = exactly five questions, once.** Questions live in `netlify/lib/onboarding.mjs`. Routes: `GET /me/onboarding`, `PUT /me/onboarding/draft` (saved each step, resumable after sign-in), `POST /me/onboarding/complete` (validates all five, applies the platform choice, and only then sets `user_profiles.onboarding_completed_at`). Every private page redirects incomplete members to `/onboarding.html`, and completed members can never open it again.
* **Removed for members:** the questionnaire hub, the eight-questionnaire flow, the dashboard questionnaire counter and button, and the sidebar link. `/questionnaire.html` and `/questionnaires.html` redirect to the dashboard. The old data is untouched and admins can still read and export it from *Questionnaires*; the four draft questionnaires show as *Retired*.
* **Changing platforms later:** Settings, *Learning platforms* (the old "learning interests" wizard is gone).
* **Migration `004_onboarding_five.sql`** adds `onboarding_completed_at` and marks every existing member who finished the old onboarding as complete. Run `npm run migrate` before deploying.

## Version 11: automatic rewards, 3-referral withdrawal rule, admin alerts
See `docs/REWARDS-REPORT.md`. Run `npm run migrate` (adds migration 005, which also repairs old Pending rewards with an evidence log), then deploy so the scheduled function `rewards-reconcile` is registered. New env vars: none. Run the database tests on a disposable branch before going live.
