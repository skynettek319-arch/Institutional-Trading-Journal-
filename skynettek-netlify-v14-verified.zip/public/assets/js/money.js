import { $, $$, api, esc, msg, clearMsg, busy, modal, confirmBox, memberLayout, badge, fmtDate, icon } from './app.js';

const page = document.body.dataset.page;
const naira = n => '₦' + Number(n || 0).toLocaleString('en-NG');
const KIND = { referral_reward: 'Referral reward', reward_reversal: 'Reward reversed', class_purchase: 'Class payment', ebook_purchase: 'Ebook purchase', withdrawal_reserve: 'Withdrawal requested', withdrawal_release: 'Withdrawal returned', adjustment: 'Adjustment by admin' };
const BANKS = ['Access Bank', 'Citibank Nigeria', 'Ecobank Nigeria', 'Fidelity Bank', 'First Bank of Nigeria', 'First City Monument Bank (FCMB)', 'Globus Bank', 'Guaranty Trust Bank (GTBank)', 'Heritage Bank', 'Keystone Bank', 'Kuda Microfinance Bank', 'Moniepoint Microfinance Bank', 'OPay', 'PalmPay', 'Polaris Bank', 'Providus Bank', 'Stanbic IBTC Bank', 'Standard Chartered Bank', 'Sterling Bank', 'SunTrust Bank', 'Union Bank', 'United Bank for Africa (UBA)', 'Unity Bank', 'Wema Bank', 'Zenith Bank'];
const REWARD_LABEL = { available: 'Reward earned', pending: 'Waiting for email verification', reversed: 'Reversed', failed: 'Being processed' };
const rewardBadge = st => `<span class="status-tag s-${st === 'available' ? 'completed' : st === 'reversed' ? 'rejected' : 'draft'}">${esc(REWARD_LABEL[st] || st)}</span>`;
const WD_LABEL = { pending: 'Withdrawal requested', processing: 'Withdrawal processing', paid: 'Paid', failed: 'Not paid (funds returned)', reversed: 'Reversed (funds returned)' };
const copy = async (text, btn) => { try { await navigator.clipboard.writeText(text); const o = btn.textContent; btn.textContent = 'Copied'; setTimeout(() => (btn.textContent = o), 1500); } catch { prompt('Copy this:', text); } };
const tiles = s => `<div class="stats"><div class="stat"><b>${naira(s.earned)}</b><span>Total rewards earned</span></div><div class="stat"><b>${naira(s.balance)}</b><span>Available balance</span></div><div class="stat"><b>${naira(s.reserved)}</b><span>Withdrawal requested</span></div><div class="stat"><b>${naira(s.withdrawn)}</b><span>Paid out</span></div><div class="stat"><b>${s.referrals}</b><span>Successful referrals</span></div><div class="stat"><b>${s.qualifying} of ${s.required}</b><span>Qualifying paid referrals</span></div></div>${s.canWithdraw ? '' : `<div class="notice">${esc(s.withdrawMessage || '')}</div>`}`;

// ============================== Wallet: balances, ledger, referrals, bank details, withdrawals ==============================
async function wallet() {
  const me = await memberLayout(); if (!me) return;
  const M = $('#wm'); let tab = (location.hash || '#overview').slice(1);
  if (!['overview', 'referrals', 'withdraw'].includes(tab)) tab = 'overview';
  const tabs = [['overview', 'Wallet'], ['referrals', 'Referrals'], ['withdraw', 'Withdraw']];
  const ledgerRow = t => `<div class="item"><div class="grow"><div class="name">${esc(KIND[t.kind] || t.kind)}</div><div class="sub">${esc(t.description || '')} · ${esc(t.reference)} · ${fmtDate(t.created_at)}</div></div><span class="amt ${t.amount > 0 ? 'pos' : 'neg'}">${t.amount > 0 ? '+' : '−'}${naira(Math.abs(t.amount))}</span></div>`;

  async function overview(out) {
    const d = await api('/me/wallet'); let items = d.items, pg = 0;
    out.innerHTML = tiles(d.summary) + `<h2 style="font-size:1.1rem">Transaction history</h2><p class="muted small">Every credit and debit has a reference.</p><div id="led"></div><div class="actions" id="more-wrap"></div>`;
    const draw = () => { $('#led').innerHTML = items.length ? `<div class="list">${items.map(ledgerRow).join('')}</div>` : '<p class="muted">No transactions yet. Referral rewards and purchases will appear here.</p>';
      $('#more-wrap').innerHTML = items.length < d.total ? '<button class="btn btn-outline" id="more">Load more</button>' : '';
      $('#more')?.addEventListener('click', async () => { pg++; const n = await api('/me/wallet/transactions?page=' + pg); items = [...items, ...n.items]; draw(); }); };
    draw();
  }
  async function referrals(out) {
    const d = await api('/me/referrals');
    out.innerHTML = `<div class="card gold"><h2 style="font-size:1.1rem">Your referral link</h2><div class="copy"><code>${esc(d.link)}</code><button class="btn btn-primary btn-sm" id="cp">Copy link</button></div><p class="small muted" style="margin:.6rem 0 0">Your code: <strong>${esc(d.code)}</strong></p></div>
      <div class="stats" style="margin-top:1rem"><div class="stat"><b>${d.stats.referred}</b><span>Successful referrals</span></div><div class="stat"><b>${d.stats.qualifying} of ${d.stats.required}</b><span>Qualifying paid referrals</span></div><div class="stat"><b>${naira(d.stats.earned)}</b><span>Total rewards earned</span></div></div>
      <div class="notice">${esc(d.rules)}</div><h2 style="font-size:1.1rem">Recent rewards</h2>
      ${d.rewards.length ? `<div class="list">${d.rewards.map(x => `<div class="item"><div class="grow"><div class="name">@${esc(x.username)} · ${{ registration: 'Registered', class: 'Joined a class', ebook: 'Bought an ebook' }[x.event]}</div><div class="sub">${fmtDate(x.created_at)}</div></div>${rewardBadge(x.status)}<span class="amt">${naira(x.amount)}</span></div>`).join('')}</div>` : '<p class="muted">No rewards yet. Share your link to start earning.</p>'}`;
    $('#cp').onclick = e => copy(d.link, e.target);
  }
  async function withdraw(out) {
    const [w, b] = await Promise.all([api('/me/withdrawals'), api('/me/bank')]);
    const bank = b.bank;
    out.innerHTML = tiles(w.summary) + `<div class="grid-2"><div class="card"><h2 style="font-size:1.1rem">Bank details</h2>${bank ? `<p class="small">Saved: <strong>${esc(bank.bank_name)}</strong> · ${esc(bank.account_name)} · ${esc(bank.masked)}</p>` : '<p class="small muted">Add your Nigerian bank account to request withdrawals.</p>'}
        <form id="bf"><div class="field"><label for="bn">Bank name</label><input id="bn" list="banks" maxlength="80" required value="${esc(bank?.bank_name || '')}"><datalist id="banks">${BANKS.map(x => `<option value="${esc(x)}">`).join('')}</datalist></div>
        <div class="field"><label for="ba">Account holder name</label><input id="ba" maxlength="120" required value="${esc(bank?.account_name || '')}" autocomplete="name"></div>
        <div class="field"><label for="bu">Account number (10 digits)</label><input id="bu" inputmode="numeric" pattern="[0-9]{10}" maxlength="10" required placeholder="${bank ? 'Enter again to change' : '0123456789'}" autocomplete="off"></div>
        <div class="field"><label for="bc">Bank code <span class="optional">(optional)</span></label><input id="bc" inputmode="numeric" maxlength="6" value="${esc(bank?.bank_code || '')}"></div>
        <div class="msg" id="bm"></div><button class="btn btn-primary" type="submit">Save bank details</button></form><p class="small muted">Your account number is stored encrypted and only shown masked. SKY-NET TEK does not verify account names automatically; check them carefully.</p></div>
      <div class="card"><h2 style="font-size:1.1rem">Request a withdrawal</h2><p class="small">Minimum withdrawal: ${naira(w.minimum)}. Only your available balance can be withdrawn.</p>
        <form id="wf"><div class="field"><label for="wa">Amount (₦)</label><input id="wa" type="number" inputmode="numeric" min="${w.minimum}" step="1" required ${w.canRequest && bank ? '' : 'disabled'}></div>
        ${w.canRequest ? '' : `<div class="notice warn" role="alert">${esc(w.message || '')}</div>`}${bank ? '' : '<div class="notice">Save your bank details first.</div>'}
        <div class="msg" id="wm2"></div><button class="btn btn-primary" type="submit" ${w.canRequest && bank ? '' : 'disabled'}>Request withdrawal</button></form><p class="small muted">${esc(w.notice)}</p></div></div>
      <h2 style="font-size:1.1rem;margin-top:1.6rem">Withdrawal history</h2>${w.items.length ? `<div class="list">${w.items.map(x => `<div class="item"><div class="grow"><div class="name">${naira(x.amount)} · ${esc(x.reference)}</div><div class="sub">${esc(x.bank_name)} ••${esc(x.account_last4)} · ${fmtDate(x.created_at)}${x.payout_reference ? ' · Transfer ref ' + esc(x.payout_reference) : ''}${x.failure_reason ? ' · ' + esc(x.failure_reason) : ''}</div></div>${`<span class="status-tag s-${x.status === 'paid' ? 'completed' : ['failed','reversed'].includes(x.status) ? 'rejected' : 'draft'}">${esc(WD_LABEL[x.status] || x.status)}</span>`}</div>`).join('')}</div>` : '<p class="muted">No withdrawals yet.</p>'}`;
    $('#bf').onsubmit = async e => { e.preventDefault(); const m = $('#bm'); clearMsg(m); await busy($('button', e.target), async () => { try { await api('/me/bank', { method: 'PUT', body: { bankName: $('#bn').value, accountName: $('#ba').value, accountNumber: $('#bu').value, bankCode: $('#bc').value } }); msg(m, 'Bank details saved.', 'success'); setTimeout(draw, 700); } catch (err) { msg(m, err.message); } }); };
    $('#wf').onsubmit = async e => { e.preventDefault(); const m = $('#wm2'); clearMsg(m); const amt = Number($('#wa').value);
      if (!(await confirmBox(`Request a withdrawal of ${naira(amt)}? The amount is reserved from your wallet now.`))) return;
      await busy($('button', e.target), async () => { try { const r = await api('/me/withdrawals', { method: 'POST', body: { amount: amt } }); msg(m, `Request submitted. Reference ${r.reference}.`, 'success'); setTimeout(draw, 900); } catch (err) { msg(m, err.message); } }); };
  }
  async function draw() {
    $('#wtabs').innerHTML = tabs.map(([k, t]) => `<button role="tab" data-t="${k}" aria-selected="${k === tab}">${t}</button>`).join('');
    $$('#wtabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; location.hash = tab; clearMsg(M); draw(); });
    const out = $('#wout'); out.innerHTML = '<p class="muted"><span class="spinner"></span> Loading…</p>';
    try { await ({ overview, referrals, withdraw })[tab](out); } catch (e) { out.innerHTML = ''; msg(M, e.message); }
  }
  draw();
}

// ============================== Ebook store and library ==============================
async function store() {
  const me = await memberLayout(); if (!me) return;
  const M = $('#sm'); let tab = (location.hash || '#store').slice(1) === 'library' ? 'library' : 'store';
  async function storeTab(out) {
    const d = await api('/me/store');
    out.innerHTML = `<p class="muted">Wallet balance: <strong>${naira(d.summary.balance)}</strong>. Only available (approved) funds can be spent. <a href="/wallet.html#referrals">Earn rewards by inviting friends.</a></p>
      <div class="grid-3">${d.items.map(e => `<article class="card book"><img src="${esc(e.cover || '/assets/img/sn-icon-192.webp')}" alt="Cover of ${esc(e.title)}" width="230" height="320" loading="lazy"><h3>${esc(e.title)}</h3><p class="small">${esc(e.description || '')}</p>
        ${e.canBuyWithWallet ? `<p><strong>${naira(e.price)}</strong> <span class="muted small">paid from your wallet</span></p>` : ''}
        <div class="actions" style="margin-top:auto">${e.owned ? '<a class="btn btn-outline" href="#library" data-lib>Open in your library</a>' : e.canBuyWithWallet ? `<button class="btn btn-primary" data-buy="${e.id}" data-title="${esc(e.title)}" data-price="${e.price}">Buy with wallet</button>` : ''}
        ${e.selarUrl ? `<a class="btn btn-outline" href="${esc(e.selarUrl)}" target="_blank" rel="noopener noreferrer">Buy on Selar — External Checkout</a>` : '<button class="btn btn-outline" disabled>Selar link not available</button>'}</div>
        ${e.selarUrl ? '<p class="small muted" style="margin:.5rem 0 0">Selar purchases happen on Selar and are not added to your library here.</p>' : ''}</article>`).join('')}</div>`;
    $$('[data-lib]', out).forEach(a => a.onclick = () => { tab = 'library'; location.hash = 'library'; draw(); });
    $$('[data-buy]', out).forEach(b => b.onclick = async () => {
      if (d.summary.balance < Number(b.dataset.price)) return msg(M, `Your available balance (${naira(d.summary.balance)}) is less than ${naira(b.dataset.price)}. Earned rewards become available after review.`);
      if (!(await confirmBox(`Buy "${b.dataset.title}" for ${naira(b.dataset.price)} from your wallet?`))) return;
      await busy(b, async () => { try { await api(`/me/store/${b.dataset.buy}/buy`, { method: 'POST' }); msg(M, 'Purchase complete. Find it in your library.', 'success'); tab = 'library'; location.hash = 'library'; setTimeout(draw, 600); } catch (e) { msg(M, e.message); } });
    });
  }
  async function libraryTab(out) {
    const d = await api('/me/library');
    out.innerHTML = d.items.length ? `<div class="list">${d.items.map(p => `<div class="item"><div class="grow"><div class="name">${esc(p.title)}</div><div class="sub">Bought ${fmtDate(p.created_at)} · Ref ${esc(p.reference)} · ${naira(p.price)} · Downloaded ${p.downloads_used} of ${p.max_downloads}</div></div>${badge(p.status === 'completed' ? 'completed' : p.status)}
      ${p.downloads_used < p.max_downloads ? `<button class="btn btn-primary btn-sm" data-dl="${p.id}">Download</button>` : p.recovery_requested_at ? '<span class="small muted">Recovery requested</span>' : `<button class="btn btn-outline btn-sm" data-rec="${p.id}">Download interrupted? Request recovery</button>`}</div>`).join('')}</div>
      <p class="small muted">Each purchase includes one complete download. The download only counts once the whole file has arrived, so if it is interrupted you can try again. If your allowance shows as used, request recovery and the team will review it.</p>` : '<p class="muted">You have not bought any ebooks with your wallet yet.</p>';
    $$('[data-dl]', out).forEach(b => b.onclick = () => busy(b, async () => { try { const r = await api(`/me/library/${b.dataset.dl}/link`, { method: 'POST' }); msg(M, 'Your download is starting. Keep this page open until it finishes.', 'info'); location.href = r.url; setTimeout(draw, 20000); } catch (e) { msg(M, e.message); } }));
    $$('[data-rec]', out).forEach(b => b.onclick = () => busy(b, async () => { try { await api(`/me/library/${b.dataset.rec}/recovery`, { method: 'POST' }); msg(M, 'Recovery requested. The team will review it and you will get a notification.', 'success'); draw(); } catch (e) { msg(M, e.message); } }));
  }
  async function draw() {
    $('#stabs').innerHTML = [['store', 'Store'], ['library', 'My library']].map(([k, t]) => `<button role="tab" data-t="${k}" aria-selected="${k === tab}">${t}</button>`).join('');
    $$('#stabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; location.hash = tab; clearMsg(M); draw(); });
    const out = $('#sout'); out.innerHTML = '<p class="muted"><span class="spinner"></span> Loading…</p>';
    try { await (tab === 'store' ? storeTab : libraryTab)(out); } catch (e) { out.innerHTML = ''; msg(M, e.message); }
  }
  draw();
}

// ============================== Settings hub ==============================
async function settings() {
  const me = await memberLayout(); if (!me) return;
  const M = $('#tm');
  const [sp, bl, am] = await Promise.all([api('/me/social-profile'), api('/me/blocks'), api('/auth/me')]);
  const on = k => (am.platforms || []).some(x => x.platform === k && x.selected);
  const p = sp.profile || { username: '', displayName: '', discoverable: true, showFriendCount: true };
  const link = (href, ic, title, sub) => `<a href="${href}">${icon(ic)}<span><b>${title}</b><small>${sub}</small></span><span class="chev" aria-hidden="true">›</span></a>`;
  $('#sx').innerHTML = `
    <div class="set-group"><h2>Account</h2><div class="set-list">${link('/account.html', 'user', 'Profile and password', 'Name, WhatsApp number and password')}${link('/wallet.html#withdraw', 'wallet', 'Bank details and withdrawals', 'Where your withdrawals are paid')}${link('/submit-proof.html', 'receipt', 'SPACEFX proof of purchase', 'Upload your Selar purchase screenshot')}${link('/membership-status.html', 'shield', 'Membership status', 'See your approvals')}</div></div>
    <div class="set-group" id="platforms"><h2>Learning platforms</h2><div class="card"><form id="plf"><p class="small muted" style="margin-top:0">Choose where you want to learn. You can change this any time. SPACEFX access also needs the Forex ebook purchase and a manual review.</p>
      <label class="opt"><input type="checkbox" name="pl" value="ai" ${on('ai') ? 'checked' : ''}><span style="display:flex;align-items:center;gap:.6rem"><img class="plogo-sm" src="/assets/img/ai-workspace-logo.webp" alt="" width="44" height="44"> AI Powered Workspace</span></label>
      <label class="opt"><input type="checkbox" name="pl" value="spacefx" ${on('spacefx') ? 'checked' : ''}><span style="display:flex;align-items:center;gap:.6rem"><img class="plogo-sm" src="/assets/img/spacefx-logo.webp" alt="" width="44" height="44"> SPACEFX Trading Group</span></label>
      <div class="msg" id="plm"></div><button class="btn btn-primary" type="submit">Save platforms</button></form></div></div>
    <div class="set-group"><h2>Friends and privacy</h2><div class="card"><form id="pf"><div class="row"><div class="field"><label for="un">Username</label><input id="un" value="${esc(p.username)}" maxlength="20" pattern="[A-Za-z0-9_]{3,20}" required><div class="hint">3 to 20 letters, numbers or underscores. Friends find you by this.</div></div><div class="field"><label for="dn">Display name</label><input id="dn" value="${esc(p.displayName)}" maxlength="40" required></div></div>
      <label class="opt"><input type="checkbox" id="dc" ${p.discoverable ? 'checked' : ''}><span>Let other members find me in Find friends</span></label><label class="opt"><input type="checkbox" id="sf" ${p.showFriendCount ? 'checked' : ''}><span>Show my friend count on my profile</span></label>
      <div class="msg" id="pm"></div><button class="btn btn-primary" type="submit">Save</button></form>
      <h3 style="margin-top:1.4rem;font-size:1rem">Blocked members</h3>${bl.blocks.length ? `<div class="list">${bl.blocks.map(b => `<div class="item"><div class="grow"><div class="name">${esc(b.display_name)}</div><div class="sub">@${esc(b.username)}</div></div><button class="btn btn-outline btn-sm" data-unblock="${b.id}">Unblock</button></div>`).join('')}</div>` : '<p class="muted small">You have not blocked anyone.</p>'}</div></div>
    <div class="set-group"><h2>Privacy and risk</h2><div class="set-list">${link('/privacy.html', 'lock', 'Privacy policy', 'How your information is used')}${link('/risk.html', 'info', 'Risk disclosure', 'Forex trading carries a high level of risk')}</div></div>
    <div class="set-group"><h2>About</h2><div class="set-list">${link('/about.html', 'info', 'About us', 'Who we are and what we teach')}${link('/terms.html', 'file', 'Terms of service', 'The rules for using SKY-NET TEK Learning Space')}</div></div>`;
  $('#plf').onsubmit = async e => { e.preventDefault(); const pm = $('#plm'); clearMsg(pm); const platforms = $$('[name=pl]:checked', e.target).map(x => x.value);
    if (!platforms.length) return msg(pm, 'Choose at least one platform.');
    await busy($('button', e.target), async () => { try { await api('/me/platforms', { method: 'PUT', body: { platforms } }); msg(pm, 'Saved.', 'success'); } catch (err) { msg(pm, err.message); } }); };
  if (location.hash === '#platforms') $('#platforms')?.scrollIntoView();
  $('#pf').onsubmit = async e => { e.preventDefault(); const m = $('#pm'); clearMsg(m); await busy($('button', e.target), async () => { try { await api('/me/social-profile', { method: 'PUT', body: { username: $('#un').value, displayName: $('#dn').value, discoverable: $('#dc').checked, showFriendCount: $('#sf').checked } }); msg(m, 'Saved.', 'success'); } catch (err) { msg(m, err.message); } }); };
  $$('[data-unblock]').forEach(b => b.onclick = () => busy(b, async () => { try { await api('/me/blocks/' + b.dataset.unblock, { method: 'DELETE' }); location.reload(); } catch (e) { msg(M, e.message); } }));
}

await ({ wallet, store, settings }[page])?.();
