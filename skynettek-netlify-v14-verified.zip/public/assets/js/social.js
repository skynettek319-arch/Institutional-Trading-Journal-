import { $, $$, api, esc, msg, clearMsg, busy, modal, confirmBox, memberLayout, badge, fmtDate } from './app.js';

const page = document.body.dataset.page;
const pic = n => `<span class="pic" aria-hidden="true">${esc((n || '?')[0].toUpperCase())}</span>`;
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ============================== Friends: find, requests, list, block, report ==============================
async function friends() {
  const me = await memberLayout(); if (!me) return;
  const M = $('#fm'); let tab = 'find', summary = { friends: 0, pendingIn: 0 };
  const refresh = async () => { try { summary = await api('/me/social-summary'); } catch { /* keep old numbers */ } };
  const tabs = () => {
    $('#ftabs').innerHTML = [['find', 'Find friends'], ['requests', `Requests${summary.pendingIn ? ' (' + summary.pendingIn + ')' : ''}`], ['list', `My friends (${summary.friends})`]]
      .map(([k, t]) => `<button role="tab" data-t="${k}" aria-selected="${k === tab}">${t}</button>`).join('');
    $$('#ftabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; clearMsg(M); draw(); });
  };
  const act = async (fn, ok) => { try { await fn(); if (ok) msg(M, ok, 'success'); await refresh(); await draw(); } catch (e) { msg(M, e.message); } };
  const reportModal = (userId, name) => {
    const m = modal(`<h2>Report ${esc(name)}</h2><form id="rf"><div class="field"><label for="rr">Reason</label><select id="rr"><option value="spam">Spam</option><option value="harassment">Harassment or bullying</option><option value="inappropriate">Inappropriate content</option><option value="scam">Scam or fraud</option><option value="other">Something else</option></select></div>
      <div class="field"><label for="rd">Details <span class="optional">(optional)</span></label><textarea id="rd" maxlength="500"></textarea></div><div class="msg" id="rm"></div>
      <div class="actions"><button class="btn btn-primary" type="submit">Send report</button><button class="btn btn-outline" type="button" id="rx">Cancel</button></div></form>`);
    $('#rx', m).onclick = () => m.close();
    $('#rf', m).onsubmit = async e => { e.preventDefault(); await busy($('button[type=submit]', m), async () => { try { const r = await api('/me/reports', { method: 'POST', body: { userId, reason: $('#rr', m).value, details: $('#rd', m).value } }); m.close(); msg(M, r.message, 'success'); } catch (err) { msg($('#rm', m), err.message); } }); };
  };
  const profileModal = async username => {
    try {
      const d = await api('/me/people/' + encodeURIComponent(username));
      const m = modal(`<h2>${esc(d.person.displayName)}</h2><p class="muted">@${esc(d.person.username)}</p>
        <div class="kv">${d.person.friendCount != null ? `<span><b>${d.person.friendCount}</b> friends</span>` : ''}${d.person.interests.length ? `<span>${d.person.interests.map(esc).join(', ')}</span>` : ''}</div>
        <div class="actions"><button class="btn btn-outline" id="px">Close</button></div>`);
      $('#px', m).onclick = () => m.close();
    } catch (e) { msg(M, e.message); }
  };
  const bind = out => {
    $$('[data-a]', out).forEach(b => b.onclick = () => {
      const a = b.dataset.a, id = b.dataset.id, uid = b.dataset.uid, name = b.dataset.name || 'this member';
      if (a === 'add') return busy(b, () => act(async () => { await api('/me/friend-requests', { method: 'POST', body: { userId: uid } }); }, 'Friend request sent.'));
      if (a === 'cancel') return busy(b, () => act(() => api('/me/friend-requests/' + id, { method: 'DELETE' }), 'Request cancelled.'));
      if (a === 'accept') return busy(b, () => act(() => api(`/me/friend-requests/${id}/accept`, { method: 'POST' }), 'Friend added.'));
      if (a === 'decline') return busy(b, () => act(() => api(`/me/friend-requests/${id}/decline`, { method: 'POST' }), 'Request declined.'));
      if (a === 'view') return profileModal(b.dataset.username);
      if (a === 'message') return busy(b, async () => { try { const r = await api('/me/chat/open', { method: 'POST', body: { friendId: uid } }); location.href = '/chat.html?c=' + r.id; } catch (e) { msg(M, e.message); } });
      if (a === 'remove') return confirmBox(`Remove ${name} from your friends? Your message history stays, but you can no longer send new messages.`).then(ok => ok && act(() => api('/me/friends/' + uid, { method: 'DELETE' }), 'Friend removed.'));
      if (a === 'block') return confirmBox(`Block ${name}? They will not be able to find you or message you.`).then(ok => ok && act(() => api('/me/blocks', { method: 'POST', body: { userId: uid } }), 'Member blocked. You can unblock from Settings.'));
      if (a === 'report') return reportModal(uid, name);
    });
  };
  const row = (p, btns) => `<div class="item">${pic(p.display_name)}<div class="grow"><div class="name">${esc(p.display_name)}</div><div class="sub">@${esc(p.username)}</div></div><div class="actions" style="margin:0">${btns}</div></div>`;
  async function findTab(out) {
    out.innerHTML = `<form id="sf" class="toolbar" role="search"><div class="field" style="flex:1;min-width:200px"><label for="sq">Username or name</label><input id="sq" type="search" minlength="2" maxlength="40" placeholder="Type at least 2 characters" required></div>
      <div class="field"><label for="si">Interest</label><select id="si"><option value="">Any</option><option value="ai">AI Powered Workspace</option><option value="spacefx">SPACEFX</option></select></div><button class="btn btn-primary" type="submit">Search</button></form><div id="sr" aria-live="polite"></div>`;
    $('#sf').onsubmit = async e => {
      e.preventDefault(); const r = $('#sr'); r.innerHTML = '<p class="muted"><span class="spinner"></span> Searching…</p>';
      try {
        const d = await api(`/me/people?q=${encodeURIComponent($('#sq').value)}&interest=${$('#si').value}`);
        r.innerHTML = d.results.length ? `<div class="list">${d.results.map(p => row(p, [
          `<button class="btn btn-outline btn-sm" data-a="view" data-username="${esc(p.username)}">View</button>`,
          p.relation === 'friends' ? `<button class="btn btn-primary btn-sm" data-a="message" data-uid="${p.id}">Message</button>` : '',
          p.relation === 'none' ? `<button class="btn btn-primary btn-sm" data-a="add" data-uid="${p.id}">Add friend</button>` : '',
          p.relation === 'sent' ? `<button class="btn btn-outline btn-sm" data-a="cancel" data-id="${p.request_id}">Cancel request</button>` : '',
          p.relation === 'received' ? `<button class="btn btn-primary btn-sm" data-a="accept" data-id="${p.request_id}">Accept</button>` : ''].join(' '))).join('')}</div>` : '<p class="muted">No members found. Try a different name or username.</p>';
        bind(r);
      } catch (err) { r.innerHTML = ''; msg(M, err.message); }
    };
  }
  async function requestsTab(out) {
    const d = await api('/me/friend-requests');
    out.innerHTML = `<h2 style="font-size:1.1rem">Received</h2>${d.incoming.length ? `<div class="list">${d.incoming.map(p => row(p, `<button class="btn btn-primary btn-sm" data-a="accept" data-id="${p.id}">Accept</button> <button class="btn btn-outline btn-sm" data-a="decline" data-id="${p.id}">Decline</button>`)).join('')}</div>` : '<p class="muted">No pending requests.</p>'}
      <h2 style="font-size:1.1rem;margin-top:1.6rem">Sent</h2>${d.outgoing.length ? `<div class="list">${d.outgoing.map(p => row(p, `<button class="btn btn-outline btn-sm" data-a="cancel" data-id="${p.id}">Cancel</button>`)).join('')}</div>` : '<p class="muted">You have no pending sent requests.</p>'}`;
    bind(out);
  }
  async function listTab(out) {
    out.innerHTML = `<div class="toolbar"><div class="field" style="flex:1;min-width:200px"><label for="lq">Search your friends</label><input id="lq" type="search" maxlength="40"></div></div><div id="lr"></div>`;
    const load = async () => {
      const d = await api('/me/friends?q=' + encodeURIComponent($('#lq').value));
      $('#lr').innerHTML = d.friends.length ? `<div class="list">${d.friends.map(p => row(p, `<button class="btn btn-primary btn-sm" data-a="message" data-uid="${p.id}">Message</button> <button class="btn btn-outline btn-sm" data-a="remove" data-uid="${p.id}" data-name="${esc(p.display_name)}">Remove</button> <button class="btn btn-outline btn-sm" data-a="block" data-uid="${p.id}" data-name="${esc(p.display_name)}">Block</button> <button class="btn btn-outline btn-sm" data-a="report" data-uid="${p.id}" data-name="${esc(p.display_name)}">Report</button>`)).join('')}</div>` : '<p class="muted">No friends yet. Use Find friends to connect with other members.</p>';
      bind($('#lr'));
    };
    let t; $('#lq').oninput = () => { clearTimeout(t); t = setTimeout(load, 250); }; await load();
  }
  async function draw() {
    tabs(); const out = $('#fout');
    try { await ({ find: findTab, requests: requestsTab, list: listTab })[tab](out); } catch (e) { msg(M, e.message); }
  }
  await refresh(); if (summary.pendingIn) tab = 'requests'; await draw();
}

// ============================== Messages: private chat with emoji, reactions, live updates ==============================
const EMOJI = '😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😜 🤔 🤗 😎 🥳 😏 😌 😴 😢 😭 😤 😡 😱 😮 🙄 😬 🤝 👍 👎 👏 🙌 🙏 💪 👀 🔥 ✨ 🎉 💯 ❤️ 💙 💛 💚 🧡 💜 ✅ ❌ ⭐ 🚀 💡 📚 💻 📈 💰 ☕ 🌍 🇳🇬'.split(' ');
const REACTS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

async function chat() {
  const me = await memberLayout(); if (!me) return;
  const uid = me.user.id, root = $('#chat'), M = $('#cm');
  let convs = [], active = null, msgs = [], other = null, canSend = false, hasMore = false, readSent = 0, polling = true, fp = null;
  const tick = s => ({ sent: '✓ Sent', delivered: '✓✓ Delivered', read: '✓✓ Read' }[s] || '');
  const time = d => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  async function loadList() {
    try { convs = (await api('/me/chat/conversations')).conversations; } catch (e) { return msg(M, e.message); }
    $('#convs').innerHTML = convs.length ? `<div class="list">${convs.map(c => `<button class="item" style="width:100%;text-align:left;background:${c.id === active ? 'var(--color-surface)' : '#fff'};border:0;cursor:pointer" data-c="${c.id}">${pic(c.display_name)}<div class="grow"><div class="name">${esc(c.display_name)}</div><div class="sub">${c.last_sender === uid ? 'You: ' : ''}${esc(c.last_body || '')}</div></div>${c.unread ? `<span class="badge" style="background:var(--color-error);color:#fff;border-radius:11px;min-width:22px;text-align:center;font-size:.75rem;padding:0 6px">${c.unread}</span>` : ''}</button>`).join('')}</div>`
      : '<div class="card"><p class="muted" style="margin:0">No conversations yet. Open <a href="/friends.html">Friends</a> and tap Message on a friend to start.</p></div>';
    $$('#convs [data-c]').forEach(b => b.onclick = () => openThread(b.dataset.c));
  }
  const applyStates = (st, seqs) => msgs.forEach(m => { if (m.mine && m.status !== 'sending' && m.status !== 'failed' && m.seq) m.status = m.seq <= st.otherRead ? 'read' : m.seq <= st.otherDelivered ? 'delivered' : 'sent'; });
  function renderMsgs(keepScroll) {
    const box = $('#msgs'); if (!box) return; const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    box.innerHTML = (hasMore ? '<button class="btn btn-outline btn-sm" id="older" style="align-self:center">Load older messages</button>' : '') + msgs.map(m => {
      const counts = {}; (m.reactions || []).forEach(x => { counts[x.emoji] = counts[x.emoji] || { n: 0, mine: false }; counts[x.emoji].n++; if (x.userId === uid) counts[x.emoji].mine = true; });
      return `<div class="bubble ${m.mine ? 'me' : ''} ${m.status === 'failed' ? 'failed' : ''}" data-m="${esc(m.id || m.clientId)}"><span class="txt">${esc(m.body)}</span><span class="meta">${time(m.createdAt)} ${m.mine ? (m.status === 'sending' ? '· Sending…' : m.status === 'failed' ? '· Not sent' : '· ' + tick(m.status)) : ''}</span>
        ${m.status === 'failed' ? `<button class="btn btn-sm btn-danger" data-retry="${esc(m.clientId)}">Retry</button>` : ''}
        ${m.id && !m.pending ? `<div class="reacts">${Object.entries(counts).map(([e, c]) => `<button class="${c.mine ? 'mine' : ''}" data-react="${esc(m.id)}" data-e="${e}" aria-label="Reaction ${e}, ${c.n}">${e} ${c.n}</button>`).join('')}<button data-pick="${esc(m.id)}" aria-label="Add reaction">☺</button>${!m.mine ? `<button data-report="${esc(m.id)}" aria-label="Report message" style="font-size:.72rem">Report</button>` : ''}</div>` : ''}</div>`;
    }).join('');
    if (!keepScroll || atBottom) box.scrollTop = box.scrollHeight;
    $('#older')?.addEventListener('click', loadOlder);
    $$('[data-retry]', box).forEach(b => b.onclick = () => resend(b.dataset.retry));
    $$('[data-react]', box).forEach(b => b.onclick = () => react(b.dataset.react, msgs.find(x => x.id === b.dataset.react)?.reactions.some(x => x.userId === uid && x.emoji === b.dataset.e) ? null : b.dataset.e));
    $$('[data-pick]', box).forEach(b => b.onclick = () => { const mm = modal(`<h2>React</h2><div class="reacts" style="gap:.6rem">${REACTS.map(e => `<button data-e="${e}" style="font-size:1.6rem;min-height:44px;padding:.2rem .8rem">${e}</button>`).join('')}</div>`); $$('button', mm).forEach(x => x.onclick = () => { mm.close(); react(b.dataset.pick, x.dataset.e); }); });
    $$('[data-report]', box).forEach(b => b.onclick = () => reportMsg(b.dataset.report));
    markRead();
  }
  async function react(id, emoji) { try { await api(`/me/chat/messages/${id}/react`, { method: 'POST', body: { emoji } }); await refreshActive(); } catch (e) { msg(M, e.message); } }
  function reportMsg(id) {
    const m = modal(`<h2>Report this message</h2><form id="rf"><div class="field"><label for="rr">Reason</label><select id="rr"><option value="spam">Spam</option><option value="harassment">Harassment or bullying</option><option value="inappropriate">Inappropriate content</option><option value="scam">Scam or fraud</option><option value="other">Something else</option></select></div><div class="msg" id="rm"></div><div class="actions"><button class="btn btn-primary" type="submit">Send report</button><button class="btn btn-outline" type="button" id="rx">Cancel</button></div></form>`);
    $('#rx', m).onclick = () => m.close();
    $('#rf', m).onsubmit = async e => { e.preventDefault(); try { const r = await api('/me/reports', { method: 'POST', body: { userId: other.id, reason: $('#rr', m).value, messageId: id } }); m.close(); msg(M, r.message, 'success'); } catch (err) { msg($('#rm', m), err.message); } };
  }
  async function markRead() {
    const top = Math.max(0, ...msgs.filter(m => !m.mine && m.seq).map(m => m.seq));
    if (!active || document.hidden || top <= readSent) return; readSent = top;
    try { await api(`/me/chat/conversations/${active}/read`, { method: 'POST', body: { upToSeq: top } }); loadList(); } catch { readSent = 0; }
  }
  async function openThread(id) {
    active = id; readSent = 0; clearMsg(M); root.classList.add('has-open');
    $('#thread').innerHTML = '<p class="muted" style="padding:1rem"><span class="spinner"></span> Loading…</p>';
    try {
      const d = await api('/me/chat/conversations/' + id);
      other = d.conversation.other; msgs = d.messages; canSend = d.canSend; hasMore = d.hasMore;
      $('#thread').innerHTML = `<div class="thread-head"><button class="icon-btn" id="back" aria-label="Back to conversations" style="width:38px;height:38px">‹</button>${pic(other.displayName)}<div class="grow"><div class="name" style="font-weight:700;color:var(--color-primary)">${esc(other.displayName)}</div><div class="sub small muted">@${esc(other.username)} <span id="conn"></span></div></div></div>
        <div class="msgs" id="msgs" aria-live="polite"></div>
        ${canSend ? `<div class="composer"><button class="icon-btn" id="emo" aria-label="Open emoji picker" aria-expanded="false">☺</button><textarea id="box" rows="1" maxlength="2000" placeholder="Write a message" aria-label="Message"></textarea><button class="btn btn-primary" id="send">Send</button><div class="emoji-pop" id="pop" hidden></div></div>` : '<div class="composer"><p class="muted small" style="margin:0">You can only message accepted friends. This conversation is read-only.</p></div>'}`;
      $('#back').onclick = () => { root.classList.remove('has-open'); active = null; history.replaceState(null, '', '/chat.html'); loadList(); };
      renderMsgs(); history.replaceState(null, '', '/chat.html?c=' + id); loadList();
      if (canSend) wireComposer();
    } catch (e) { $('#thread').innerHTML = ''; msg(M, e.message); }
  }
  function wireComposer() {
    const box = $('#box'), pop = $('#pop'), emo = $('#emo');
    pop.innerHTML = EMOJI.map(e => `<button type="button" data-e="${e}" aria-label="Emoji ${e}">${e}</button>`).join('');
    emo.onclick = () => { pop.hidden = !pop.hidden; emo.setAttribute('aria-expanded', String(!pop.hidden)); };
    pop.onclick = e => { const b = e.target.closest('[data-e]'); if (!b) return; const s = box.selectionStart ?? box.value.length, t = box.selectionEnd ?? box.value.length; box.value = box.value.slice(0, s) + b.dataset.e + box.value.slice(t); const p = s + b.dataset.e.length; box.setSelectionRange(p, p); box.focus(); };
    box.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
    $('#send').onclick = send;
  }
  const newId = () => (crypto.randomUUID ? crypto.randomUUID() : 'm' + Date.now() + Math.random().toString(36).slice(2)).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40).padEnd(8, 'x');
  async function send() {
    const box = $('#box'), body = box.value.trim(); if (!body) return;
    const clientId = newId(); box.value = ''; $('#pop').hidden = true;
    msgs.push({ clientId, id: null, mine: true, body, createdAt: new Date().toISOString(), status: 'sending', reactions: [], pending: true }); renderMsgs();
    await post(clientId, body);
  }
  async function post(clientId, body) {
    const m = msgs.find(x => x.clientId === clientId); if (!m) return;
    try {
      const r = await api(`/me/chat/conversations/${active}/messages`, { method: 'POST', body: { body, clientId } });
      const dupe = msgs.find(x => x.id === r.message.id && x !== m);
      if (dupe) msgs.splice(msgs.indexOf(m), 1); else Object.assign(m, { id: r.message.id, seq: r.message.seq, createdAt: r.message.createdAt, status: 'sent', pending: false });
      renderMsgs(); loadList();
    } catch (e) { m.status = 'failed'; m.error = e.message; renderMsgs(); msg(M, e.message); }
  }
  const resend = clientId => { const m = msgs.find(x => x.clientId === clientId); if (m) { m.status = 'sending'; renderMsgs(); post(clientId, m.body); } };
  async function loadOlder() {
    const first = msgs.find(m => m.seq); if (!first) return;
    try { const d = await api(`/me/chat/conversations/${active}?before=${first.seq}`); msgs = [...d.messages, ...msgs]; hasMore = d.hasMore; renderMsgs(true); } catch (e) { msg(M, e.message); }
  }
  async function refreshActive() {
    if (!active) return;
    try {
      const d = await api('/me/chat/conversations/' + active); const byId = new Map(msgs.filter(m => m.id).map(m => [m.id, m]));
      d.messages.forEach(n => { const o = byId.get(n.id); if (o) { o.reactions = n.reactions; o.status = n.status || o.status; } else if (!msgs.some(x => x.clientId && x.pending && x.body === n.body && n.mine)) msgs.push(n); });
      msgs.sort((a, b) => (a.seq || 1e15) - (b.seq || 1e15)); canSend = d.canSend; renderMsgs(true);
    } catch { /* next poll retries */ }
  }
  const setConn = ok => { const el = $('#conn'); if (el) el.textContent = ok ? '' : '· Reconnecting…'; const b = $('#offline'); if (b) b.hidden = ok; };
  async function onChanges(d) {
    let touched = false;
    for (const m of d.messages) {
      if (m.conversationId === active && !msgs.some(x => x.id === m.id)) {
        const mine = msgs.find(x => x.pending && x.body === m.body && m.mine); if (mine) { Object.assign(mine, { id: m.id, seq: m.seq, status: 'sent', pending: false }); } else msgs.push({ ...m, reactions: [], status: m.mine ? 'sent' : null });
        touched = true;
      }
    }
    const st = d.states.find(s => s.conversationId === active); if (st) { applyStates(st); touched = true; }
    if (d.reactionChanges.some(x => x.conversationId === active)) await refreshActive();
    if (touched) renderMsgs(true);
    loadList();
    api('/me/social-summary').then(s => { const el = $('[data-badge="unread"]'); if (el) { el.hidden = !s.unread; el.textContent = s.unread; } }).catch(() => {});
  }
  async function loop() {
    try { const i = await api('/me/chat/poll?init=1'); fp = { seq: i.seq, act: i.act }; } catch { fp = { seq: 0, act: 'none' }; }
    let fails = 0;
    while (polling) {
      try {
        const ctrl = new AbortController(), t = setTimeout(() => ctrl.abort(), 13000);
        const res = await fetch(`/api/me/chat/poll?seq=${fp.seq}&act=${encodeURIComponent(fp.act)}`, { credentials: 'same-origin', signal: ctrl.signal });
        clearTimeout(t);
        if (res.status === 401) { location.href = '/'; return; }
        if (!res.ok) throw new Error('poll failed');
        const d = await res.json(); fails = 0; setConn(true);
        if (d.changed) { fp = { seq: d.seq, act: d.act }; await onChanges(d); }
      } catch { fails++; setConn(false); await sleep(Math.min(12000, 1500 * 2 ** Math.min(fails, 4))); }
      if (document.hidden) await sleep(4000);
    }
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) markRead(); });
  window.addEventListener('beforeunload', () => { polling = false; });
  await loadList();
  const want = new URLSearchParams(location.search).get('c'); if (want) openThread(want);
  loop();
}

await ({ friends, chat }[page])?.();
