import test from 'node:test';
import assert from 'node:assert/strict';
import { QUESTIONNAIRES, TYPES, allQuestions, optionsOf, validate, score, publicDef } from '../netlify/lib/questionnaires.mjs';

test('eight legacy questionnaires plus the internal onboarding record, with unique slugs', () => {
  assert.equal(QUESTIONNAIRES.length, 9);
  assert.equal(new Set(QUESTIONNAIRES.map(d => d.slug)).size, 9);
  assert.deepEqual(QUESTIONNAIRES.filter(d => d.internal).map(d => d.slug), ['onboarding']);
});
test('every question is well formed', () => {
  for (const d of QUESTIONNAIRES) {
    const ids = new Set();
    for (const q of allQuestions(d)) {
      assert.ok(TYPES.includes(q.type), `${d.slug}.${q.id} type`);
      assert.ok(!ids.has(q.id), `${d.slug} duplicate id ${q.id}`); ids.add(q.id);
      assert.ok(q.label && q.label.length > 3, `${d.slug}.${q.id} label`);
      if (['single', 'multi', 'dropdown'].includes(q.type)) assert.ok(optionsOf(q).length >= 2, `${d.slug}.${q.id} options`);
      if (q.type === 'rating') assert.ok(q.scale.max > q.scale.min);
      if (q.correct != null) assert.ok(optionsOf(q).includes(q.correct), `${d.slug}.${q.id} correct answer is an option`);
    }
  }
});
test('the browser copy never contains correct answers or scoring', () => {
  const text = JSON.stringify(publicDef(QUESTIONNAIRES.find(d => d.slug === 'forex-risk-awareness')));
  assert.ok(!text.includes('"correct"') && !text.includes('"explain"') && !text.includes('"scoring"'));
});
const skills = QUESTIONNAIRES.find(d => d.slug === 'ai-skills-assessment');
const goodSkills = { k_prompting: 4, k_video: 3, k_images: 3, k_automation: 2, k_checking: 4, p_weekly: 'Yes', p_shared: 'No', p_work: 'No', g_focus: 'AI video creation', g_hours: 6 };
test('required answers are enforced', () => {
  const { errors } = validate(skills, {});
  assert.ok(errors.k_prompting && errors.g_focus && errors.g_hours);
  assert.deepEqual(validate(skills, goodSkills).errors, {});
});
test('invalid answers are rejected', () => {
  assert.ok(validate(skills, { ...goodSkills, k_video: 9 }).errors.k_video);
  assert.ok(validate(skills, { ...goodSkills, g_focus: 'Hacking' }).errors.g_focus);
  assert.ok(validate(skills, { ...goodSkills, g_hours: 81 }).errors.g_hours);
  assert.ok(validate(skills, { ...goodSkills, g_hours: 2.5 }).errors.g_hours);
  assert.ok(validate(skills, { ...goodSkills, p_weekly: 'Maybe' }).errors.p_weekly);
  assert.equal(validate(skills, { ...goodSkills, injected: 'x' }).clean.injected, undefined);
});
test('partial saves allow missing required answers but still reject bad ones', () => {
  assert.deepEqual(validate(skills, { k_prompting: 3 }, { partial: true }).errors, {});
  assert.ok(validate(skills, { k_prompting: 99 }, { partial: true }).errors.k_prompting);
});
test('scoring follows the rules', () => {
  const r = score(skills, validate(skills, goodSkills).clean);
  assert.equal(r.max, 28); assert.equal(r.points, 4 + 3 + 3 + 2 + 4 + 1); assert.equal(r.percent, Math.round(17 / 28 * 100)); assert.equal(r.band, 'Building skills');
  const fx = QUESTIONNAIRES.find(d => d.slug === 'forex-risk-awareness');
  const ans = Object.fromEntries(allQuestions(fx).filter(q => q.correct).map(q => [q.id, q.correct])); ans.a_understand = 'Yes';
  const full = score(fx, validate(fx, ans).clean); assert.equal(full.percent, 100); assert.equal(full.band, 'Strong awareness');
  assert.ok(validate(fx, { ...ans, a_understand: 'No' }).errors.a_understand);
});
test('dates cannot be in the future', () => {
  const fb = QUESTIONNAIRES.find(d => d.slug === 'training-feedback');
  const base = { t_which: 'AI Video Creation: 3-Day Live Training', t_overall: 5, t_clarity: 5, t_relevance: 5, t_recommend: 10, t_contact: 'No' };
  assert.deepEqual(validate(fb, { ...base, t_date: '2026-10-01' }, { now: new Date('2026-10-23') }).errors, {});
  assert.ok(validate(fb, { ...base, t_date: '2027-01-01' }, { now: new Date('2026-10-23') }).errors.t_date);
  assert.ok(validate(fb, { ...base, t_date: '2026-02-31' }).errors.t_date);
  assert.equal(validate(fb, { ...base, t_date: '2026-10-01', t_recommend: 0 }, { now: new Date('2026-10-23') }).clean.t_recommend, 0);
});
