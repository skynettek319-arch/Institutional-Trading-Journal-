// Reward, referral and withdrawal workflow against a REAL Neon database. Skipped unless TEST_DATABASE_URL is set.
// Use a disposable branch/database (same env as integration.test.mjs). Migration 005 must be applied first.
import test from 'node:test';
import assert from 'node:assert/strict';
const url = process.env.TEST_DATABASE_URL;
const skip = !url && 'TEST_DATABASE_URL not set';
if (url) { process.env.DATABASE_URL = url; process.env.REQUIRE_EMAIL_VERIFICATION = 'false'; }
const mods = skip ? null : { api: await import('../netlify/functions/api.mjs'), db: await import('../netlify/lib/db.mjs'), w: await import('../netlify/lib/wallet.mjs') };
const call = (method, path, { cookie, body } = {}) => mods.api.handle(new Request('https://site.test/api' + path, { method, headers: { 'x-requested-with': 'sky', ...(cookie ? { cookie } : {}), ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined }));
let n = 0;
async function signup(ref) {
  n++; const u = { fullName: 'Reward Test ' + n, email: `rw${Date.now()}${n}@example.com`, country: 'Nigeria', region: 'Anambra', ageRange: '25-34', language: 'English', whatsapp: '+2348012345678', password: 'TestPassw0rd!!', acceptTerms: true, understandsRequirements: true, ...(ref ? { ref } : {}) };
  const r = await call('POST', '/auth/register', { body: u }); assert.equal(r.status, 200);
  const id = (await mods.db.one('SELECT id FROM users WHERE email=$1', [u.email.toLowerCase()])).id;
  const code = (await mods.db.one('SELECT referral_code FROM user_profiles WHERE user_id=$1', [id])).referral_code;
  return { id, code, cookie: r.headers.get('set-cookie').split(';')[0] };
}
const approvedProof = async id => (await mods.db.one("INSERT INTO purchase_proofs(user_id,selar_email,file_key,file_mime,file_sha256,status) VALUES($1,'x@y.co','k','image/png','h','approved') RETURNING id", [id])).id;
const bal = async id => (await mods.db.one('SELECT balance FROM wallets WHERE user_id=$1', [id])).balance;
const ledgerSum = async id => (await mods.db.one('SELECT COALESCE(SUM(amount),0)::int s FROM wallet_ledger WHERE user_id=$1', [id])).s;
const notes = async (id, like) => (await mods.db.q('SELECT body FROM notifications WHERE user_id=$1 AND body LIKE $2', [id, like])).length;

test('registration through a referral link credits the configured reward once, with a notification', { skip }, async () => {
  const a = await signup(); const b = await signup(a.code);
  assert.equal(await bal(a.id), 100); assert.equal(await bal(a.id), await ledgerSum(a.id));
  assert.equal(await notes(a.id, '%Your referral was successful%₦100%'), 1);
  assert.equal((await mods.w.rewardOnVerified(b.id)).credited, false);          // repeated event: no second credit
  assert.equal(await bal(a.id), 100);
  assert.equal((await mods.w.processReward({ event: 'registration', sourceId: a.id, referrerId: a.id, referredId: a.id })).skipped, 'no_referrer'); // self-referral
});

test('forex ebook payment: only an approved proof earns a reward, once; a reversal removes it once and drops the qualifying count', { skip }, async () => {
  const a = await signup(), b = await signup(a.code), start = await bal(a.id);
  assert.equal((await mods.w.rewardOnPayment('ebook', 'no-such-proof', b.id)).credited, false); // unverified: nothing
  const proof = await approvedProof(b.id);
  const r1 = await mods.w.rewardOnPayment('ebook', proof, b.id), r2 = await mods.w.rewardOnPayment('ebook', proof, b.id);
  assert.equal(r1.credited, true); assert.equal(r2.credited, false);
  assert.equal(await bal(a.id), start + 200);
  assert.equal((await mods.w.walletSummary(a.id)).qualifying, 1);
  await mods.db.q("UPDATE purchase_proofs SET status='revoked' WHERE id=$1", [proof]);
  assert.equal((await mods.w.reverseForSource('ebook', proof, null, 'test')).reversed, true);
  assert.equal((await mods.w.reverseForSource('ebook', proof, null, 'test')).none, true);
  assert.equal(await bal(a.id), start); assert.equal(await bal(a.id), await ledgerSum(a.id));
  assert.equal((await mods.w.walletSummary(a.id)).qualifying, 0);
});

test('there is no earnings cap: rewards keep being credited far past ₦5,000', { skip }, async () => {
  const a = await signup(), people = [await signup(a.code), await signup(a.code)];
  for (const p of people) await mods.w.processReward({ event: 'ebook', sourceId: await approvedProof(p.id), referrerId: a.id, referredId: p.id, amount: 6000 });
  const s = await mods.w.walletSummary(a.id);
  assert.ok(s.earned >= 12000); assert.equal(s.balance, await ledgerSum(a.id));
});

test('withdrawal needs 3 DISTINCT qualifying paid referrals, regardless of balance, and cannot overspend', { skip }, async () => {
  const a = await signup(), friends = [await signup(a.code), await signup(a.code), await signup(a.code)];
  await mods.db.q("INSERT INTO wallet_ledger(user_id,kind,amount,reference,idempotency_key,description) VALUES($1,'adjustment',9000,$2,$2,'test funds')", [a.id, 'TEST-' + a.id]);
  await mods.db.q('UPDATE wallets SET balance=balance+9000 WHERE user_id=$1', [a.id]);
  assert.equal((await call('PUT', '/me/bank', { cookie: a.cookie, body: { bankName: 'Test Bank', accountName: 'Reward Tester', accountNumber: '0123456789' } })).status, 200);
  await approvedProof(friends[0].id); await approvedProof(friends[0].id);          // same person twice still counts once
  await approvedProof(friends[1].id);
  const blocked = await call('POST', '/me/withdrawals', { cookie: a.cookie, body: { amount: 2000 } });
  assert.equal(blocked.status, 400); assert.match((await blocked.json()).error, /You currently have 2 of 3/);
  await approvedProof(friends[2].id);
  const before = await bal(a.id);
  const [x, y] = await Promise.all([call('POST', '/me/withdrawals', { cookie: a.cookie, body: { amount: before - 1000 } }), call('POST', '/me/withdrawals', { cookie: a.cookie, body: { amount: before - 500 } })]);
  assert.equal([x.status, y.status].filter(s => s === 200).length, 1);              // concurrent requests cannot reserve the same money
  assert.ok(await bal(a.id) >= 0); assert.equal(await bal(a.id), await ledgerSum(a.id));
  assert.equal((await mods.db.q("SELECT 1 FROM admin_alerts WHERE kind='withdrawal' AND body LIKE '%Reward Tester%'")).length >= 1, true);
});
