import { $, $$, adminApi, esc, msg, clearMsg, busy, modal, confirmBox, adminLayout, badge, fmtDate, pager } from './app.js';

const page = document.body.dataset.page;
const localInput = d => { if (!d) return ''; const x = new Date(d); return new Date(x.getTime() - x.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };
const iso = v => (v ? new Date(v).toISOString() : '');
const chk = (id, label, on) => `<label class="opt"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}> <span>${label}</span></label>`;
const field = (id, label, val = '', type = 'text', extra = '') => `<div class="field"><label for="${id}">${label}</label><input id="${id}" type="${type}" value="${esc(val)}" ${extra}></div>`;

const pages = {
  // ------------------------------------------------ trainings, events, member notices
  async programs() {
    const me = await adminLayout(); if (!me) return;
    const M = $('#pm');
    let D, tab = 'trainings';
    const tabs = [['trainings', 'Trainings'], ['events', 'Events'], ['notify', 'Send notification']];
    const load = async () => { D = await adminApi('/admin/trainings'); draw(); };

    function trainingForm(t = {}) {
      const m = modal(`<h2>${t.id ? 'Edit' : 'New'} training</h2><form id="tf">
        ${field('t_title', 'Title *', t.title, 'text', 'required maxlength="160"')}
        <div class="field"><label for="t_desc">Description</label><textarea id="t_desc" maxlength="2000">${esc(t.description || '')}</textarea></div>
        <div class="row">${field('t_start', 'Start date and time', localInput(t.starts_at), 'datetime-local')}${field('t_dur', 'Duration (for example 3 days)', t.duration_label, 'text', 'maxlength="60"')}</div>
        <div class="row">${field('t_mode', 'Format', t.mode, 'text', 'maxlength="80"')}${field('t_fee', 'Fee text shown to members (OPay receipts)', t.fee_amount, 'text', 'maxlength="40"')}</div>
        ${field('t_price', 'Wallet price in naira (members can pay from their wallet; empty = not payable from wallet)', t.price_ngn ?? '', 'number', 'min="0" step="1"')}
        <div class="row">${field('t_ws', 'Workspace name', t.workspace_name || 'SKYNETTEK AI WORK SPACE', 'text', 'maxlength="80"')}${field('t_url', 'Workspace join link (shown only to approved members)', t.join_url, 'url', 'placeholder="https://chat.whatsapp.com/..."')}</div>
        <div class="row"><div class="field"><label for="t_status">Status</label><select id="t_status">${['open', 'upcoming', 'closed'].map(x => `<option ${t.status === x ? 'selected' : ''}>${x}</option>`).join('')}</select></div>${field('t_sort', 'Display order', t.sort_order ?? 0, 'number')}</div>
        ${chk('t_pay', 'Requires payment and receipt approval', t.requires_payment !== false)}${chk('t_pub', 'Published (visible to members)', t.published !== false)}
        ${t.id ? '' : chk('t_notify', 'Notify all members about this new training', true)}
        <div class="msg" id="tfm"></div><div class="actions"><button class="btn btn-primary" type="submit">Save</button><button class="btn btn-outline" type="button" id="tfx">Cancel</button></div></form>`);
      $('#tfx', m).onclick = () => m.close();
      $('#tf', m).onsubmit = async e => {
        e.preventDefault();
        const body = { title: $('#t_title', m).value, description: $('#t_desc', m).value, startsAt: iso($('#t_start', m).value), durationLabel: $('#t_dur', m).value, mode: $('#t_mode', m).value, feeAmount: $('#t_fee', m).value, workspaceName: $('#t_ws', m).value, joinUrl: $('#t_url', m).value, status: $('#t_status', m).value, sortOrder: $('#t_sort', m).value, priceNgn: $('#t_price', m).value, requiresPayment: $('#t_pay', m).checked, published: $('#t_pub', m).checked, notifyMembers: $('#t_notify', m)?.checked === true };
        await busy($('button[type=submit]', m), async () => {
          try { await adminApi(t.id ? `/admin/trainings/${t.id}` : '/admin/trainings', { method: t.id ? 'PUT' : 'POST', body }); m.close(); await load(); msg(M, 'Training saved.', 'success'); } catch (err) { msg($('#tfm', m), err.message); }
        });
      };
    }
    function eventForm(v = {}) {
      const m = modal(`<h2>${v.id ? 'Edit' : 'New'} event</h2><form id="ef">
        ${field('e_title', 'Title *', v.title, 'text', 'required maxlength="160"')}
        <div class="field"><label for="e_desc">Description</label><textarea id="e_desc" maxlength="1500">${esc(v.description || '')}</textarea></div>
        <div class="row">${field('e_start', 'Date and time *', localInput(v.starts_at), 'datetime-local', 'required')}${field('e_loc', 'Location or platform', v.location, 'text', 'maxlength="160"')}</div>
        ${field('e_url', 'Event link (optional)', v.link_url, 'url')}
        ${chk('e_pub', 'Published (visible to members)', v.published !== false)}${v.id ? '' : chk('e_notify', 'Notify all members about this event', true)}
        <div class="msg" id="efm"></div><div class="actions"><button class="btn btn-primary" type="submit">Save</button><button class="btn btn-outline" type="button" id="efx">Cancel</button></div></form>`);
      $('#efx', m).onclick = () => m.close();
      $('#ef', m).onsubmit = async e => {
        e.preventDefault();
        const body = { title: $('#e_title', m).value, description: $('#e_desc', m).value, startsAt: iso($('#e_start', m).value), location: $('#e_loc', m).value, linkUrl: $('#e_url', m).value, published: $('#e_pub', m).checked, notifyMembers: $('#e_notify', m)?.checked === true };
        await busy($('button[type=submit]', m), async () => {
          try { await adminApi(v.id ? `/admin/events/${v.id}` : '/admin/events', { method: v.id ? 'PUT' : 'POST', body }); m.close(); await load(); msg(M, 'Event saved.', 'success'); } catch (err) { msg($('#efm', m), err.message); }
        });
      };
    }

    async function notifyTab(out) {
      out.innerHTML = `<div class="grid-2"><div class="card"><h2 style="font-size:1.2rem">Send a notification</h2><p class="small muted">Members see it in their dashboard notifications straight away.</p><form id="nf">
        ${field('n_title', 'Title *', '', 'text', 'required maxlength="120"')}<div class="field"><label for="n_body">Message *</label><textarea id="n_body" required maxlength="1000"></textarea></div>
        <div class="field"><label for="n_aud">Send to</label><select id="n_aud"><option value="all">All active members</option><option value="ai">Members who chose AI Powered Workspace</option><option value="spacefx">Members who chose SPACEFX</option><option value="training">Members enrolled in a training</option></select></div>
        <div class="field" id="n_tw" hidden><label for="n_tr">Training</label><select id="n_tr">${D.trainings.map(t => `<option value="${t.id}">${esc(t.title)}</option>`).join('')}</select></div>
        <div class="msg" id="nfm"></div><button class="btn btn-primary" type="submit">Send notification</button></form></div>
        <div class="card"><h2 style="font-size:1.2rem">Recent notifications sent</h2><div id="nh"><span class="spinner"></span></div></div></div>`;
      const aud = $('#n_aud', out); aud.onchange = () => { $('#n_tw', out).hidden = aud.value !== 'training'; };
      const hist = async () => {
        const { items } = await adminApi('/admin/broadcasts');
        $('#nh', out).innerHTML = items.length ? items.map(i => `<p class="small"><strong>${esc(i.details.title)}</strong><br><span class="muted">${fmtDate(i.created_at)} · ${esc(i.details.audience)} · ${i.details.recipients} recipient(s)</span></p>`).join('') : '<p class="muted small">Nothing sent yet.</p>';
      };
      $('#nf', out).onsubmit = async e => {
        e.preventDefault(); const mm = $('#nfm', out); clearMsg(mm);
        if (!await confirmBox('Send this notification now?')) return;
        await busy($('button', e.target), async () => {
          try { const r = await adminApi('/admin/broadcast', { method: 'POST', body: { title: $('#n_title', out).value, body: $('#n_body', out).value, audience: aud.value, trainingId: aud.value === 'training' ? $('#n_tr', out).value : undefined } }); e.target.reset(); msg(mm, `Sent to ${r.recipients} member(s).`, 'success'); hist(); } catch (err) { msg(mm, err.message); }
        });
      };
      hist();
    }

    function draw() {
      $('#ptabs').innerHTML = tabs.map(([k, t]) => `<button role="tab" data-t="${k}" aria-selected="${k === tab}">${t}</button>`).join('');
      $$('#ptabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; clearMsg(M); draw(); });
      const out = $('#pout');
      if (tab === 'trainings') {
        out.innerHTML = `<div class="actions" style="margin-top:0"><button class="btn btn-primary" id="new">Add training</button></div><div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>Training</th><th>Starts</th><th>Fee</th><th>Status</th><th>Enrolled</th><th>Pending</th><th>Approved</th><th></th></tr></thead><tbody>${D.trainings.map(t => `<tr><td><strong>${esc(t.title)}</strong>${t.published ? '' : ' <span class="status-tag">Hidden</span>'}<br><span class="small muted">${t.join_url ? 'Workspace link set' : 'No workspace link yet'}</span></td><td>${t.starts_at ? fmtDate(t.starts_at) : '—'}</td><td>${esc(t.fee_amount || '—')}</td><td>${badge(t.status)}</td><td>${t.enrolled}</td><td>${t.pending}</td><td>${t.approved}</td><td style="white-space:nowrap"><button class="btn btn-outline btn-sm" data-e="${t.id}">Edit</button> <button class="btn btn-danger btn-sm" data-d="${t.id}">Delete</button></td></tr>`).join('') || '<tr><td colspan="8" class="muted">No trainings yet.</td></tr>'}</tbody></table></div>`;
        $('#new', out).onclick = () => trainingForm();
        $$('[data-e]', out).forEach(b => b.onclick = () => trainingForm(D.trainings.find(x => x.id === b.dataset.e)));
        $$('[data-d]', out).forEach(b => b.onclick = async () => { if (!await confirmBox('Delete this training and all its enrolments? This cannot be undone.')) return; try { await adminApi(`/admin/trainings/${b.dataset.d}`, { method: 'DELETE' }); await load(); } catch (err) { msg(M, err.message); } });
      } else if (tab === 'events') {
        out.innerHTML = `<div class="actions" style="margin-top:0"><button class="btn btn-primary" id="new">Add event</button></div><div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>Event</th><th>When</th><th>Where</th><th>Visible</th><th></th></tr></thead><tbody>${D.events.map(v => `<tr><td><strong>${esc(v.title)}</strong></td><td>${fmtDate(v.starts_at)}</td><td>${esc(v.location || '—')}</td><td>${v.published ? 'Yes' : 'No'}</td><td style="white-space:nowrap"><button class="btn btn-outline btn-sm" data-e="${v.id}">Edit</button> <button class="btn btn-danger btn-sm" data-d="${v.id}">Delete</button></td></tr>`).join('') || '<tr><td colspan="5" class="muted">No events yet.</td></tr>'}</tbody></table></div>`;
        $('#new', out).onclick = () => eventForm();
        $$('[data-e]', out).forEach(b => b.onclick = () => eventForm(D.events.find(x => x.id === b.dataset.e)));
        $$('[data-d]', out).forEach(b => b.onclick = async () => { if (!await confirmBox('Delete this event?')) return; try { await adminApi(`/admin/events/${b.dataset.d}`, { method: 'DELETE' }); await load(); } catch (err) { msg(M, err.message); } });
      } else notifyTab(out);
    }
    try { await load(); } catch (e) { msg(M, e.message); }
  },

  // ------------------------------------------------ enrolment and payment review
  async enrollments() {
    const me = await adminLayout(); if (!me) return;
    const canTrain = me.perms.includes('*') || me.perms.includes('trainings:write');
    if (canTrain) {
      $('#etw').hidden = false;
      try { const d = await adminApi('/admin/trainings'); $('#etr').innerHTML += d.trainings.map(t => `<option value="${t.id}">${esc(t.title)}</option>`).join(''); } catch { /* filter is optional */ }
    }
    let pg = 0;
    const load = async () => {
      const p = new URLSearchParams({ page: pg, status: $('#est').value, trainingId: canTrain ? $('#etr').value : '' });
      try {
        const d = await adminApi('/admin/enrollments?' + p);
        $('#rows').innerHTML = d.enrollments.length ? d.enrollments.map(r => `<tr><td>${esc(r.full_name || '')}<br><span class="small muted">${esc(r.email)}</span></td><td>${esc(r.title)}</td><td>${esc(r.whatsapp || '—')}</td><td>${fmtDate(r.updated_at)}</td><td>${badge(r.status)} ${r.flagged ? badge('flagged') : ''}</td><td><button class="btn btn-primary btn-sm" data-id="${r.id}">Review</button></td></tr>`).join('') : '<tr><td colspan="6" class="muted">Nothing in this queue.</td></tr>';
        $$('button[data-id]', $('#rows')).forEach(b => b.onclick = () => review(b.dataset.id));
        pager($('#pg'), d.total, d.pageSize, pg, n => { pg = n; load(); });
      } catch (e) { $('#rows').innerHTML = `<tr><td colspan="6">${esc(e.message)}</td></tr>`; }
    };
    $('#efilters').onsubmit = e => { e.preventDefault(); pg = 0; load(); };
    async function review(id) {
      const d = await adminApi('/admin/enrollments/' + id), en = d.enrollment, last = d.payments[0];
      const pending = en.status === 'awaiting_review', canWrite = me.perms.includes('*') || me.perms.includes('enroll:write');
      const m = modal(`<h2>Review enrolment</h2><p>${badge(en.status)} ${last?.flagged ? badge('flagged') : ''}</p>
        <p>${en.paid_with === 'wallet' ? badge('paid') + ' Paid from wallet' + (en.payment_reference ? ' · ' + esc(en.payment_reference) : '') : ''} ${en.group_verified_at ? badge('approved') + ' Group verified' : ''}</p><p><strong>${esc(en.full_name || '')}</strong> · ${esc(en.email)}<br>WhatsApp: ${esc(en.whatsapp || '—')} · ${esc(en.country || '')}<br>Training: <strong>${esc(en.title)}</strong>${en.fee_amount ? ' · Fee: ' + esc(en.fee_amount) : ''}</p>
        ${last ? `<p class="small">Paid from account name: <strong>${esc(last.payer_name)}</strong> · Amount: ${esc(last.amount_paid || 'not stated')} · Reference: ${esc(last.reference || 'not provided')} · Date: ${esc(last.paid_on ? String(last.paid_on).slice(0, 10) : 'not provided')}<br>Submitted ${fmtDate(last.created_at)}</p>${last.flagged ? `<div class="notice bad"><strong>Flag:</strong> ${esc(last.flag_reason)}</div>` : ''}<div id="img"><span class="spinner"></span> Loading private receipt…</div>` : '<div class="notice">No receipt has been uploaded yet.</div>'}
        <div class="notice small">A screenshot is not proof. Open your <strong>OPay app</strong>, find this credit by amount, sender name or reference, and confirm the money arrived before approving.</div>
        ${canWrite ? `<div class="field"><label for="note">Internal note</label><textarea id="note">${esc(last?.admin_note || '')}</textarea></div>
        <div class="field"><label for="reason">Reason (required to reject, ask for a clearer receipt or revoke; shown to the member)</label><input id="reason" type="text" maxlength="500"></div>
        <label class="opt"><input type="checkbox" id="verified"> I confirmed this payment in my OPay account</label>` : ''}
        <div class="msg" id="em"></div>
        <div class="actions">${canWrite && pending ? '<button class="btn btn-primary" id="approve">Approve</button><button class="btn btn-outline" id="resubmit">Request clearer receipt</button><button class="btn btn-danger" id="reject">Reject</button>' : ''}${canWrite && en.status === 'approved' && !en.group_verified_at ? '<button class="btn btn-primary" id="gv">Mark learning group as verified</button>' : ''}${canWrite && en.status === 'approved' ? '<button class="btn btn-danger" id="revoke">Revoke place</button>' : ''}<button class="btn btn-outline" id="close">Close</button></div>
        <h3 style="margin-top:1.4rem">Receipt history</h3>${d.payments.map(p => `<p class="small">${fmtDate(p.created_at)} · ${badge(p.status)}${p.rejection_reason ? ' · ' + esc(p.rejection_reason) : ''}</p>`).join('') || '<p class="muted small">None.</p>'}`);
      $('#close', m).onclick = () => m.close();
      if (last) try { const r = await adminApi(`/admin/receipts/${last.id}`); $('#img', m).innerHTML = `<img class="proof-img" src="${URL.createObjectURL(await r.blob())}" alt="Submitted payment receipt">`; } catch (e) { $('#img', m).textContent = e.message; }
      $('#gv', m)?.addEventListener('click', async () => { if (!(await confirmBox('Confirm that you checked this member really joined the learning group? A referral reward may be released.'))) return; try { await adminApi(`/admin/enrollments/${id}/group-verify`, { method: 'POST', body: {} }); m.close(); load(); } catch (e) { msg($('#em', m), e.message); } });
      for (const action of ['approve', 'reject', 'resubmit', 'revoke']) {
        const b = $('#' + action, m); if (!b) continue;
        b.onclick = async () => {
          if (action === 'revoke' && !await confirmBox('Revoke this place? The member will lose access to the workspace link.')) return;
          try { await adminApi(`/admin/enrollments/${id}/decision`, { method: 'POST', body: { action, reason: $('#reason', m).value, note: $('#note', m).value, verifiedPayment: $('#verified', m).checked } }); m.close(); load(); } catch (e) { msg($('#em', m), e.message); }
        };
      }
    }
    load();
  }
};
await pages[page]?.();
