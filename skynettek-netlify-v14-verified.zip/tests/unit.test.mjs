import test from 'node:test';
import assert from 'node:assert/strict';
import { emailOf, phone, password, imageKind, decodeImage, httpsUrl, SELAR_HOSTS, uuid } from '../netlify/lib/validate.mjs';
import { cleanAnswers, QUESTIONS } from '../netlify/lib/questions.mjs';
import { can, permsOf } from '../netlify/lib/perms.mjs';

test('email and phone validation', () => {
  assert.equal(emailOf(' A@B.co '), 'a@b.co');
  assert.throws(() => emailOf('nope'));
  assert.equal(phone('+234 801 234 5678'), '+2348012345678');
  assert.throws(() => phone('08012345678'));
});
test('password policy', () => {
  assert.throws(() => password('short1'));
  assert.throws(() => password('onlyletterslong'));
  assert.equal(password('goodpassw0rd'), 'goodpassw0rd');
  assert.throws(() => password('goodpassw0rd', 14));
});
test('image uploads are checked by content, not name', () => {
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]);
  assert.equal(imageKind(png), 'image/png');
  assert.equal(imageKind(Buffer.from('<?php echo 1;')), null);
  assert.equal(imageKind(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>')), null);
  assert.throws(() => decodeImage({ name: 'x.png', data: Buffer.from('<script>alert(1)</script>').toString('base64') }, 1000));
  assert.throws(() => decodeImage({ data: png.toString('base64') }, 5));
  assert.equal(decodeImage({ data: png.toString('base64') }, 1000).mime, 'image/png');
});
test('Selar URLs must be https on a Selar host', () => {
  assert.ok(httpsUrl('https://selar.com/017j91l781', 'x', SELAR_HOSTS));
  assert.throws(() => httpsUrl('http://selar.com/x', 'x', SELAR_HOSTS));
  assert.throws(() => httpsUrl('https://evil.example/selar.com', 'x', SELAR_HOSTS));
});
test('uuid guard', () => { assert.throws(() => uuid('1; DROP TABLE users')); });
test('questionnaire validation', () => {
  const ok = { fxLevel: 'Intermediate', fxStudied: 'Not yet started', fxObjective: 'Study risk management', fxWhy: 'Hobby', fxChallenge: 'Managing risk', fxJournal: 'No', fxHours: '3-5 hours', fxGoal30: 'Plan', fxRisk: 'Yes' };
  assert.equal(cleanAnswers(QUESTIONS.spacefx, ok).fxRisk, 'Yes');
  assert.throws(() => cleanAnswers(QUESTIONS.spacefx, { ...ok, fxLevel: 'Wizard' }));
  assert.throws(() => cleanAnswers(QUESTIONS.spacefx, { ...ok, fxGoal30: '' }));
  assert.equal(cleanAnswers(QUESTIONS.spacefx, { ...ok, hacked: 'x' }).hacked, undefined);
});
test('role permissions', () => {
  assert.ok(can('super_admin', 'anything'));
  assert.ok(can('membership_admin', 'proofs:write'));
  assert.ok(!can('content_admin', 'proofs:write'));
  assert.ok(!can('support_admin', 'members:answers'));
  assert.ok(!can('support_admin', '*'));
  assert.deepEqual(permsOf('nobody'), []);
});
