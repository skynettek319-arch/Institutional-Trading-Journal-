CREATE TABLE trainings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  starts_at timestamptz,
  duration_label text,
  mode text,
  fee_amount text,
  requires_payment boolean NOT NULL DEFAULT true,
  workspace_name text NOT NULL DEFAULT 'SKYNETTEK AI WORK SPACE',
  join_url text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('upcoming','open','closed')),
  published boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  training_id uuid NOT NULL REFERENCES trainings(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'awaiting_payment' CHECK (status IN ('awaiting_payment','awaiting_review','approved','rejected','resubmit_requested','revoked')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, training_id)
);
CREATE INDEX enrollments_status_idx ON enrollments (status, created_at DESC);
CREATE INDEX enrollments_training_idx ON enrollments (training_id);
CREATE TABLE training_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id uuid NOT NULL REFERENCES enrollments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payer_name text NOT NULL,
  amount_paid text,
  reference text,
  paid_on date,
  file_key text NOT NULL,
  file_mime text NOT NULL,
  file_sha256 text NOT NULL,
  notes text,
  flagged boolean NOT NULL DEFAULT false,
  flag_reason text,
  status text NOT NULL DEFAULT 'awaiting_review' CHECK (status IN ('awaiting_review','approved','rejected','resubmit_requested','revoked')),
  rejection_reason text,
  admin_note text,
  decided_by uuid REFERENCES users(id),
  decided_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tpay_enrollment_idx ON training_payments (enrollment_id, created_at DESC);
CREATE INDEX tpay_sha_idx ON training_payments (file_sha256);
CREATE INDEX tpay_ref_idx ON training_payments (lower(reference));
CREATE TABLE events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  starts_at timestamptz NOT NULL,
  location text,
  link_url text,
  published boolean NOT NULL DEFAULT true,
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX events_start_idx ON events (starts_at);
INSERT INTO settings(key,value) VALUES
 ('payment_bank','OPay'),
 ('payment_account_number','7055707482'),
 ('payment_account_name','CHIKA AUGUSTINE OFFOR')
 ON CONFLICT (key) DO NOTHING;
INSERT INTO trainings(title,description,duration_label,mode,status,sort_order) VALUES
 ('AI Video Creation: 3-Day Live Training','Three days of hands-on training on creating videos with AI tools, from the first idea to a finished export. After your payment is confirmed you can request to join SKYNETTEK AI WORK SPACE where the sessions take place.','3 days','Live on SKYNETTEK AI WORK SPACE','open',1)
