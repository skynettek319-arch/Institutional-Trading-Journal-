// Access-control tests that need no database: they hit paths rejected before any query runs.
// Requires `npm install` first.
import test from 'node:test';
import assert from 'node:assert/strict';
const { handle } = await import('../netlify/functions/api.mjs');
const call = (method, path, { headers = {}, body } = {}) =>
  handle(new Request('https://site.test/api' + path, { method, headers: { ...headers }, body: body ? JSON.stringify(body) : undefined }));

test('state-changing requests without the CSRF header are refused', async () => {
  assert.equal((await call('POST', '/auth/login', { body: { email: 'a@b.co', password: 'x' } })).status, 403);
});
test('cross-origin state-changing requests are refused', async () => {
  const r = await call('POST', '/auth/logout', { headers: { 'x-requested-with': 'sky', origin: 'https://evil.test' } });
  assert.equal(r.status, 403);
});
test('anonymous visitors cannot reach member data or the invitation', async () => {
  for (const p of ['/me/dashboard', '/spacefx/invite', '/lessons', '/me/proofs', '/me/trainings']) assert.equal((await call('GET', p)).status, 401, p);
});
test('anonymous visitors cannot reach any admin API', async () => {
  for (const p of ['/admin/overview', '/admin/members', '/admin/proofs', '/admin/proofs/00000000-0000-0000-0000-000000000000/file', '/admin/content/all', '/admin/audit', '/admin/admins', '/admin/me', '/admin/trainings', '/admin/enrollments', '/admin/broadcasts'])
    assert.equal((await call('GET', p)).status, 401, p);
  assert.equal((await call('POST', '/admin/proofs/00000000-0000-0000-0000-000000000000/decision', { headers: { 'x-requested-with': 'sky' }, body: { action: 'approve' } })).status, 401);
});
test('forged cookies are not accepted as admin when no database session exists', async () => {
  // A cookie value alone is meaningless: sessions are looked up by hash server-side.
  // (This one needs DATABASE_URL; it is skipped otherwise.)
  if (!process.env.DATABASE_URL) return;
  const r = await call('GET', '/admin/overview', { headers: { cookie: 'asid=forged-value' } });
  assert.equal(r.status, 401);
});
