// Old bookmarks and email links (/signin.html, /register.html, /forgot-password.html, questionnaire pages) land here and move on.
// The query string (including ?ref=) is carried over so referral codes are never lost.
const t = document.body.dataset.to || 'signin';
const search = location.search;
if (t === 'dashboard') location.replace('/dashboard.html');
else location.replace('/' + search + '#' + t);
