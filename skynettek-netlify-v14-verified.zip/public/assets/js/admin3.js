// Admin: articles (create, edit, publish, delete) and community moderation (reports, recent posts).
import { $, $$, adminApi, esc, msg, clearMsg, busy, modal, confirmBox, adminLayout, fmtDate, fileToBase64, nl2br } from './app.js';
import { tabBar } from './community.js';
const page = document.body.dataset.page;
const has = (me, p) => me.perms.includes('*') || me.perms.includes(p);

async function aarticles() {
  const me = await adminLayout(); if (!me) return;
  const M = $('#am'), out = $('#aout');
  async function load() {
    try {
      const { articles } = await adminApi('/admin/articles');
      out.innerHTML = articles.length ? `<div class="table-wrap"><table><thead><tr><th>Title</th><th>Category</th><th>Status</th><th>Updated</th><th><span class="sr-only">Actions</span></th></tr></thead><tbody>${articles.map(a => `<tr><td>${esc(a.title)}<br><small class="muted">/${esc(a.slug)}</small></td><td>${esc(a.category)}${a.platform ? ' · ' + esc(a.platform) : ''}</td><td>${a.status === 'published' ? '<span class="badge ok">Published</span>' : '<span class="badge">Draft</span>'}</td><td>${fmtDate(a.updated_at)}</td><td><button class="btn btn-outline btn-sm" data-edit="${esc(a.id)}">Edit</button></td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No articles yet. Create the first one.</p>';
      $$('[data-edit]', out).forEach(b => b.onclick = () => edit(b.dataset.edit));
    } catch (e) { msg(M, e.message); }
  }
  async function edit(id) {
    let a = { title: '', slug: '', summary: '', body: '', category: 'General', author_name: 'SN Learning', platform: '', cover_key: '', status: 'draft' };
    if (id) try { a = (await adminApi('/admin/articles/' + id)).article; } catch (e) { return msg(M, e.message); }
    const m = modal(`<h3>${id ? 'Edit' : 'New'} article</h3><form id="af" novalidate>
      <div class="field"><label for="at">Title</label><input id="at" maxlength="160" value="${esc(a.title)}"></div>
      <div class="field"><label for="as">Web address (optional)</label><input id="as" maxlength="80" value="${esc(a.slug)}" placeholder="made from the title if empty"></div>
      <div class="field"><label for="asu">Summary (up to 300 characters)</label><textarea id="asu" rows="2" maxlength="300">${esc(a.summary)}</textarea></div>
      <div class="field"><label for="ab">Article text</label><textarea id="ab" rows="12">${esc(a.body)}</textarea><p class="small muted">Separate paragraphs with a blank line. Start a line with “## ” for a heading. Start lines with “- ” for a bullet list. Plain text only.</p></div>
      <div class="field"><label for="ac">Category</label><input id="ac" maxlength="40" value="${esc(a.category)}"></div>
      <div class="field"><label for="aa">Author name</label><input id="aa" maxlength="60" value="${esc(a.author_name)}"></div>
      <div class="field"><label for="ap">Learning path (only for AI or Forex articles)</label><select id="ap"><option value="">None</option><option value="ai" ${a.platform === 'ai' ? 'selected' : ''}>AI Powered Workspace</option><option value="spacefx" ${a.platform === 'spacefx' ? 'selected' : ''}>SPACEFX</option></select></div>
      <div class="field"><label for="acv">Cover image (PNG, JPEG or WEBP, up to 2 MB)</label><input id="acv" type="file" accept="image/png,image/jpeg,image/webp">${a.cover_key ? '<p class="small muted">A cover is set. Choose a file to replace it.</p>' : ''}</div>
      <div class="field"><label class="check"><input type="checkbox" id="apub" ${a.status === 'published' ? 'checked' : ''}> Published (visible to members)</label></div>
      <div class="msg" id="afm" role="status"></div>
      <div class="actions"><button class="btn btn-primary" type="submit">Save</button><button class="btn btn-outline" type="button" id="ax">Cancel</button>${id ? '<button class="btn btn-danger" type="button" id="adel">Delete</button>' : ''}</div></form>`);
    $('#ax', m).onclick = () => m.close();
    $('#adel', m)?.addEventListener('click', async () => { if (!(await confirmBox('Delete this article permanently? Members who saved it will lose it.'))) return; try { await adminApi('/admin/articles/' + id, { method: 'DELETE' }); m.close(); msg(M, 'Article deleted.', 'success'); load(); } catch (e) { msg($('#afm', m), e.message); } });
    $('#af', m).onsubmit = e => { e.preventDefault(); busy($('button[type=submit]', m), async () => {
      try {
        let cover = a.cover_key || null; const f = $('#acv', m).files[0];
        if (f) { if (f.size > 2 * 1024 * 1024) throw new Error('The cover image is larger than 2 MB.'); cover = (await adminApi('/admin/upload-thumb', { method: 'POST', body: { file: await fileToBase64(f) } })).key; }
        const body = { title: $('#at', m).value, slug: $('#as', m).value, summary: $('#asu', m).value, body: $('#ab', m).value, category: $('#ac', m).value, authorName: $('#aa', m).value, platform: $('#ap', m).value || null, coverKey: cover, published: $('#apub', m).checked };
        await adminApi(id ? '/admin/articles/' + id : '/admin/articles', { method: id ? 'PUT' : 'POST', body });
        m.close(); msg(M, 'Article saved.', 'success'); load();
      } catch (err) { msg($('#afm', m), err.message); } }); };
  }
  $('#anew').onclick = () => edit(null); load();
}

async function acommunity() {
  const me = await adminLayout(); if (!me) return;
  const M = $('#am'), out = $('#aout');
  const decide = async (id, action) => {
    const note = action === 'dismiss' ? null : prompt('Optional note for the audit log (not shown to the member):', '') ?? null;
    if (action !== 'dismiss' && !(await confirmBox(action === 'remove' ? 'Remove this content from the community?' : 'Hide this content?'))) return;
    try { await adminApi(`/admin/community/reports/${id}/decide`, { method: 'POST', body: { action, note } }); msg(M, 'Done.', 'success'); loadReports(); } catch (e) { msg(M, e.message); }
  };
  async function loadReports(status = 'open') {
    out.innerHTML = '<p class="muted"><span class="spinner"></span> Loading…</p>';
    try {
      const { reports } = await adminApi('/admin/community/reports?status=' + status);
      out.innerHTML = reports.length ? reports.map(r => `<div class="card" style="margin-bottom:.8rem"><strong>${esc(r.target_type === 'post' ? 'Post' : 'Comment')} by ${esc(r.author)}</strong> <span class="badge">${esc(r.reason)}</span> ${r.report_count > 1 ? `<span class="badge warn">${r.report_count} reports</span>` : ''}
        <p style="margin:.5rem 0;white-space:pre-wrap">${esc(r.snapshot || '')}</p><p class="small muted">Reported by ${esc(r.reporter)} · ${fmtDate(r.created_at)}${r.details ? ' · “' + esc(r.details) + '”' : ''} · post is ${esc(r.post_status)}</p>
        ${status === 'open' ? `<div class="actions"><button class="btn btn-danger btn-sm" data-d="remove" data-id="${esc(r.id)}">Remove</button><button class="btn btn-outline btn-sm" data-d="hide" data-id="${esc(r.id)}">Hide</button><button class="btn btn-outline btn-sm" data-d="dismiss" data-id="${esc(r.id)}">Dismiss</button></div>` : `<span class="badge">${esc(r.status)}</span>`}</div>`).join('') : `<p class="muted">No ${status} reports.</p>`;
      $$('[data-d]', out).forEach(b => b.onclick = () => decide(b.dataset.id, b.dataset.d));
    } catch (e) { out.innerHTML = ''; msg(M, e.message); }
  }
  async function loadPosts() {
    out.innerHTML = '<p class="muted"><span class="spinner"></span> Loading…</p>';
    try {
      const { posts } = await adminApi('/admin/community/posts');
      out.innerHTML = posts.length ? `<div class="table-wrap"><table><thead><tr><th>Author</th><th>Post</th><th>Status</th><th><span class="sr-only">Actions</span></th></tr></thead><tbody>${posts.map(p => `<tr><td>${esc(p.author)}<br><small class="muted">${fmtDate(p.created_at)}</small></td><td style="white-space:pre-wrap;max-width:420px">${esc(p.body.slice(0, 240))}${p.has_image ? ' <small class="muted">[photo]</small>' : ''}</td><td>${esc(p.status)}</td><td><select aria-label="Set status" data-id="${esc(p.id)}"><option value="">Change…</option>${['published', 'hidden', 'removed'].filter(s => s !== p.status).map(s => `<option>${s}</option>`).join('')}</select></td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">No posts yet.</p>';
      $$('select[data-id]', out).forEach(s => s.onchange = async () => { if (!s.value) return; try { await adminApi(`/admin/community/posts/${s.dataset.id}/status`, { method: 'POST', body: { status: s.value } }); msg(M, 'Post updated.', 'success'); loadPosts(); } catch (e) { msg(M, e.message); } });
    } catch (e) { out.innerHTML = ''; msg(M, e.message); }
  }
  tabBar($('#mtabs'), [['open', 'Open reports'], ['actioned', 'Actioned'], ['dismissed', 'Dismissed'], ['posts', 'Latest posts']], k => { clearMsg(M); k === 'posts' ? loadPosts() : loadReports(k); });
}
await ({ aarticles, acommunity }[page])?.();
