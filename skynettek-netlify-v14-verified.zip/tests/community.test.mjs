// Posts, comments, reactions, reports and articles: pure-logic and structural checks. Dependency-free: `node --test tests/community.test.mjs`
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { cleanText, postInput, commentInput, articleInput, parseArticleBody, slugify, readingMinutes, encodeCursor, decodeCursor, pageSize, likeEscape, clientId } from '../netlify/lib/community.mjs';
import { can } from '../netlify/lib/perms.mjs';

const routes = fs.readFileSync('netlify/lib/routes/community.mjs', 'utf8');
const mig = fs.readFileSync('migrations/006_community_articles.sql', 'utf8');
const throwsStatus = (fn, status = 400) => assert.throws(fn, e => e.status === status);

test('post and comment input: trimmed, length-limited, control characters removed', () => {
  assert.equal(postInput({ body: '  Hello\r\n\r\n\r\n\r\nWorld\u0007  ' }).body, 'Hello\n\nWorld');
  throwsStatus(() => postInput({ body: '   ' })); throwsStatus(() => postInput({ body: 'x'.repeat(2001) })); assert.equal(postInput({ body: 'x'.repeat(2000) }).body.length, 2000);
  throwsStatus(() => commentInput({ body: 'x'.repeat(1001) }));
  assert.equal(postInput({ body: 'hi', audience: 'everyone' }).audience, 'members', 'unknown audience falls back to the safe default');
  assert.equal(postInput({ body: 'hi', audience: 'friends' }).audience, 'friends');
  assert.equal(cleanText('a\u202Eb', 'x', { max: 9 }), 'ab', 'bidi override characters removed');
});
test('clientId (idempotency key) accepts only safe tokens', () => { assert.equal(clientId(null), null); assert.equal(clientId('abcdefgh-1234'), 'abcdefgh-1234'); throwsStatus(() => clientId('short')); throwsStatus(() => clientId('has space 12345')); throwsStatus(() => clientId('x'.repeat(65))); });
test('cursors round-trip, keep microseconds, and reject tampering', () => {
  const id = '11111111-1111-4111-8111-111111111111', ts = '2026-10-26T10:00:00.123456Z';
  assert.deepEqual(decodeCursor(encodeCursor(ts, id)), { ts, id });
  assert.deepEqual(decodeCursor(''), { ts: null, id: null });
  for (const bad of ['abc', Buffer.from("2026-10-26T10:00:00.123Z|" + id).toString('base64url'), Buffer.from(ts + "|'; DROP TABLE posts;--").toString('base64url')]) throwsStatus(() => decodeCursor(bad));
  assert.equal(pageSize('999'), 30); assert.equal(pageSize('0'), 10); assert.equal(pageSize('abc'), 10); assert.equal(pageSize('5'), 5);
});
test('articles: slug, reading time, validation, structured body (never HTML)', () => {
  assert.equal(slugify('Ünïcode: AI Tools!! 2026'), 'unicode-ai-tools-2026');
  assert.equal(readingMinutes('word '.repeat(450)), 2); assert.equal(readingMinutes(''), 1);
  const a = articleInput({ title: 'How AI is changing work', body: 'This is a long enough article body.', platform: 'ai', published: true });
  assert.equal(a.slug, 'how-ai-is-changing-work'); assert.equal(a.publish, true); assert.equal(a.platform, 'ai');
  throwsStatus(() => articleInput({ title: 'Hi', body: 'x'.repeat(30) })); throwsStatus(() => articleInput({ title: 'Valid title', body: 'short' }));
  throwsStatus(() => articleInput({ title: 'Valid title', body: 'x'.repeat(30), platform: 'crypto' })); throwsStatus(() => articleInput({ title: 'Valid title', body: 'x'.repeat(30), coverKey: '../../etc/passwd' }));
  assert.deepEqual(parseArticleBody('## Head\n\nPara\nline\n\n- a\n- b\n\n<script>alert(1)</script>'), [{ type: 'h', text: 'Head' }, { type: 'p', text: 'Para\nline' }, { type: 'ul', items: ['a', 'b'] }, { type: 'p', text: '<script>alert(1)</script>' }]);
  assert.equal(likeEscape('50%_off\\'), '50\\%\\_off\\\\');
});
test('migration 006 is compatible with scripts/migrate.mjs and creates every table, index and constraint the routes rely on', () => {
  const statements = mig.split(/;\s*\n/).map(s => s.trim()).filter(Boolean);
  assert.equal(statements.length, 16, '6 tables + 10 indexes');
  for (const s of statements) { assert.equal((s.match(/\(/g) || []).length, (s.match(/\)/g) || []).length, 'balanced parentheses: ' + s.slice(0, 60)); assert.ok(/^(--[^\n]*\n)*\s*(CREATE|ALTER)/.test(s), 'starts with DDL: ' + s.slice(0, 60)); }
  for (const t of ['posts', 'post_reactions', 'post_comments', 'post_reports', 'articles', 'article_bookmarks']) assert.match(mig, new RegExp(`CREATE TABLE IF NOT EXISTS ${t} \\(`));
  assert.match(mig, /posts_client_uq ON posts \(author_id, client_id\) WHERE client_id IS NOT NULL/);
  assert.match(routes, /ON CONFLICT \(author_id, client_id\) WHERE client_id IS NOT NULL DO NOTHING/, 'conflict target matches the partial unique index');
  assert.match(mig, /audience IN \('members','friends'\)/); assert.match(mig, /UNIQUE \(reporter_id, target_type, target_id\)/); assert.match(mig, /ON DELETE CASCADE/);
});
test('every member route requires a member session; every admin route requires the right permission', () => {
  const defs = [...routes.matchAll(/r\('(GET|POST|PUT|DELETE)', '([^']+)', ([^,]+),/g)].map(m => ({ method: m[1], path: m[2], opts: m[3] }));
  assert.ok(defs.length >= 23, 'routes found: ' + defs.length);
  for (const d of defs) {
    if (d.path.startsWith('/me/')) assert.equal(d.opts.trim(), 'M', `${d.method} ${d.path} must use { auth: 'member' }`);
    else assert.ok(/^\{ \.\.\.C|^C$|^MOD$/.test(d.opts.trim()), `${d.method} ${d.path} must be an admin route`);
  }
  assert.match(routes, /const M = \{ auth: 'member' \}/); assert.match(routes, /const C = \{ auth: 'admin', perm: 'content:write' \}/); assert.match(routes, /const MOD = \{ auth: 'admin', perm: 'community:moderate' \}/);
  assert.match(routes, /r\('DELETE', '\/admin\/articles\/:id', \{ \.\.\.C, reauth: true \}/, 'article deletion needs re-authentication like other destructive admin actions');
  assert.ok(routes.indexOf("'/me/articles/categories'") < routes.indexOf("'/me/articles/:slug'"), 'static route is registered before the :slug route');
});
test('SQL safety: member-supplied text is only ever passed as a bound parameter', () => {
  const ALLOWED = /\$\{(?:TS\([^)]*\)|BLOCKED\([^)]*\)|COLS|FROM|VIS|KEYSET|SQL\.[A-Za-z.]+(?:\([^)]*\))?|where|a|b|withBody \? 'a\.body,' : ''|[a-z]+\.length|col)\}/g;
  const sqlLines = routes.split('\n').filter(l => /\b(SELECT|INSERT INTO|UPDATE|DELETE FROM)\b/.test(l) && !/notify\(/.test(l));
  assert.ok(sqlLines.length > 20);
  for (const l of sqlLines) assert.ok(!/\$\{/.test(l.replace(ALLOWED, '').replace(/\$\$\{params\.length\}/g, '')), 'unbound interpolation in SQL: ' + l.trim().slice(0, 100));
  for (const part of ['p.status=\'published\'', 'user_blocks', 'friend_requests', "u.status='active'"]) assert.ok(routes.includes(part), 'visibility rule present: ' + part);
  assert.match(routes, /p\.audience='members' OR p\.author_id=\$1 OR EXISTS/, 'friends-only posts are limited to the author and accepted friends');
  assert.match(routes, /ESCAPE '\\\\'/, 'LIKE search escapes wildcards');
});
test('UPDATE statements use the portable "UPDATE table AS alias" form', () => { assert.ok(!/UPDATE \w+ [a-z]+ SET/.test(routes), 'an alias without AS is PostgreSQL-only'); });
test('moderation permission exists for the right roles only', () => {
  assert.ok(can('super_admin', 'community:moderate') && can('support_admin', 'community:moderate') && can('membership_admin', 'community:moderate'));
  assert.ok(!can('content_admin', 'community:moderate')); assert.ok(can('content_admin', 'content:write') && !can('support_admin', 'content:write'));
});
test('front end never puts user text into innerHTML unescaped', () => {
  const js = fs.readFileSync('public/assets/js/community.js', 'utf8');
  const tpl = [...js.matchAll(/\$\{([^}]+)\}/g)].map(m => m[1]).filter(x => /\b(p|c|a|x|r)\.(body|title|summary|category|author|slug|coverUrl|imageUrl|message)\b|displayName|username|\.text\b|\.items/.test(x));
  assert.ok(tpl.length > 10);
  for (const x of tpl) assert.ok(/esc\(|nl2br\(|encodeURIComponent\(/.test(x) || /^[a-z.]+\.(readingMinutes|likes|comments)$/.test(x.trim()), 'unescaped: ' + x);
});
