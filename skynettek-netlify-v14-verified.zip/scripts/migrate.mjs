// Usage: DATABASE_URL=... npm run migrate
import fs from 'node:fs';
import path from 'node:path';
import { neon } from '@neondatabase/serverless';
if (!process.env.DATABASE_URL) { console.error('Set DATABASE_URL first.'); process.exit(1); }
const sql = neon(process.env.DATABASE_URL);
const run = (t, p = []) => (typeof sql.query === "function" ? sql.query(t, p) : sql(t, p));
const dir = path.resolve('migrations');
await run('CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())');
const done = new Set((await run('SELECT name FROM schema_migrations')).map(r => r.name));
for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.sql')).sort()) {
  if (done.has(f)) { console.log('skip', f); continue; }
  const statements = fs.readFileSync(path.join(dir, f), 'utf8').split(/;\s*\n/).map(s => s.trim()).filter(Boolean);
  for (const s of statements) await run(s);
  await run('INSERT INTO schema_migrations(name) VALUES($1)', [f]);
  console.log('applied', f, `(${statements.length} statements)`);
}
console.log('Migrations complete.');
