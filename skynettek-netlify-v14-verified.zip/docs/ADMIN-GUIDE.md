# Administrator guide

## Creating administrators
There is no public admin signup. Run, with `DATABASE_URL` set:

    npm run create-admin -- person@example.com membership_admin

Roles: `super_admin` (everything), `membership_admin` (members, purchase review, support), `content_admin` (lessons, ebooks, announcements, settings), `support_admin` (read members, support messages). Role checks run on the server for every request. Support admins cannot see questionnaire answers or purchase screenshots.

## Google Authenticator (TOTP)
1. Sign in at `/admin-login.html` with email and password.
2. First time only: scan the QR code with Google Authenticator (or enter the key manually), type the 6-digit code, then save the 10 recovery codes (shown once; stored only as hashes).
3. Every later sign-in asks for the 6-digit code after the password. A code can be used once. Five wrong codes lock that account for 15 minutes.
4. Lost phone: use a recovery code (single use) and then Security > "Replace authenticator device". If you have no codes, another super administrator uses Security > Reset 2FA for you. If you are the only super administrator and lose both, run `create-admin` again for your email (it resets the password) and clear 2FA directly in the database: `UPDATE users SET totp_enabled=false, totp_secret_enc=NULL WHERE email='you@example.com';`
5. Sensitive actions (suspend, revoke approval, role change, delete, export, recovery codes) ask for your password again.

## Reviewing a SPACEFX purchase
1. Open Purchase verification, click Review.
2. Compare the member's Selar email and order reference with the order in your **Selar seller dashboard**.
3. Check the "Possible reuse" box if shown.
4. Approve (requires the Selar confirmation tick), Request clearer proof, or Reject (reason required and shown to the member). Approved access can later be reversed.
Every decision records who, when and why.

## Publishing lessons
Content > Categories: publish a category to make it live. Content > Lessons: add title, video link (YouTube/Vimeo embed; other https links open as a button), notes, thumbnail; tick Published. Members see only published lessons in published categories.
