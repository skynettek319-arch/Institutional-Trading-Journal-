import { $, api, esc } from './app.js';
const naira = n => '₦' + Number(n || 0).toLocaleString('en-NG');
{
  const [s, w, ref] = await Promise.allSettled([api('/me/social-summary'), api('/me/wallet'), api('/me/referrals')]);
  const v = x => (x.status === 'fulfilled' ? x.value : null);
  const sum = v(s), wal = v(w), rf = v(ref);
  $('#xtop').innerHTML = `<div class="stats">
    <a class="stat" href="/friends.html"><b>${sum ? sum.friends : '–'}</b><span>Friends</span></a>
    <a class="stat" href="/friends.html"><b>${sum ? sum.pendingIn : '–'}</b><span>Friend requests</span></a>
    <a class="stat" href="/chat.html"><b>${sum ? sum.unread : '–'}</b><span>Unread messages</span></a>
    <a class="stat" href="/wallet.html"><b>${wal ? naira(wal.summary.balance) : '–'}</b><span>Wallet balance</span></a>
    <a class="stat" href="/wallet.html#referrals"><b>${rf ? rf.stats.referred : '–'}</b><span>Members referred</span></a></div>
    <div class="actions" style="margin:0 0 1.4rem"><a class="btn btn-primary" href="/friends.html">Find friends</a><a class="btn btn-outline" href="/chat.html">Messages</a><a class="btn btn-outline" href="/store.html">Ebook store</a></div>
    ${rf ? `<div class="card gold" style="margin-bottom:1.4rem"><strong>Invite friends and earn.</strong> <span class="small">Your link: <code class="secret">${esc(rf.link)}</code></span> <a class="btn btn-outline btn-sm" href="/wallet.html#referrals">Copy and details</a></div>` : ''}`;
}
