# Rewards, referrals and withdrawals: implementation report (v11)

## 1. Why rewards stayed "Pending"
* Every registration reward was created with `release_at = now() + 24 hours` and status `pending`.
* The only code that moved a `pending` reward to `available` ran **when the referrer opened their wallet or referrals page**. If they did not visit, the reward stayed Pending indefinitely. There was no scheduled job.
* The ₦200 class reward was only created after an administrator also pressed *Group verified*, a second manual step on top of payment approval.
* Email verification was not part of the registration reward rule at all, so the 24h timer was the only gate.
* Forex ebook payments (the SPACEFX proof approval) never created a reward or counted toward anything.
* No ₦5,000 cap exists in the code, schema or pages (searched every file; a test now guards this).

## 2. What changed
* **Registration reward** (default ₦100): credited the moment the referred member's email is verified (immediately when verification is switched off). Until then the row is `pending` with the reason "waiting for email verification". This is a genuine condition, not a timer.
* **Class reward** (default ₦200): credited when an administrator approves the training payment. Group verification no longer matters.
* **Forex ebook reward** (default ₦200): credited when the ebook payment proof is approved.
* All three go through one database statement (`creditReward`) that writes the reward row, the wallet balance, the ledger line and the member notification together. Guards inside that statement: not self, the referrer must be the stored referrer, and the payment must exist as an approved record. A repeat is a no-op. A reversed reward is never re-credited.
* Reward amounts, the minimum withdrawal and the required qualifying referrals live in the `reward_config` table (Admin, Wallet, *Reward settings*). No amount is hard-coded in a message.
* **No lifetime cap.** Lifetime earnings, available balance, reserved funds and paid-out are separate figures from the ledger and wallet.
* Statuses: `available` (shown as Reward earned / Credited), `pending` (waiting for a genuine condition), `reversed`, `failed` (being retried). Processing failures are stored in `reward_retries`.

## 3. Automation
* On registration, on email verification, on enrollment approval and on ebook proof approval the reward is processed inline.
* A scheduled function `rewards-reconcile` (every 10 minutes) retries failed credits, heals rewards a crash skipped (only for events after the policy start), releases verified registration rewards, and compares every wallet to its ledger. Mismatches raise an admin alert and nothing is changed automatically.
* Notifications are inserted in the same statement as the credit and are keyed (`reward:<id>`), so they are recorded even if the member is offline, appear in notification history on next login, and cannot be duplicated.
* Revoking an approved enrollment or ebook proof reverses its reward once. If the money has already been spent, nothing goes negative: the administrator gets an alert.

## 4. Withdrawals
* Rule (enforced in the route **and inside the SQL that reserves the funds**): balance >= amount >= minimum, a saved bank account, and at least 3 distinct referred people with a verified paid class or the forex ebook. Registration alone, unpaid, rejected, revoked or duplicate payments do not count. One person counts once even with several purchases.
* Accounting: funds are debited into a reserve at request time and returned exactly once if the request fails or is reversed. Paying only changes the status (the money already left the balance).
* The member sees only a simple status (Withdrawal requested / processing / Paid). The text never says the transfer is manual.
* Admin gets an in-app alert (Admin, Wallet, *Needs attention*) with name, username, member id, amount, bank, account holder, **last four digits**, date, reference and status, plus a link. The full account number is only shown on the withdrawal's *Bank details* view (permission, recent re-authentication and audit log apply) and is never put in alerts, member notifications, URLs or logs.
* Duplicate double-clicks are rejected within 60 seconds; concurrent requests cannot reserve the same money (single conditional UPDATE).
* The administrator marks the request Paid with a reference; the member is notified.

## 5. Payment approval and access
Existing flows were kept: administrators review proofs/receipts and approve or reject with a reason; approval records the admin and time, unlocks only that member's access (SPACEFX invite, training joining) and notifies them; rejection never unlocks or rewards. Approval now also triggers the reward and the qualifying-referral record.

## 6. Existing records (migration 005)
Every `pending` reward was classified with evidence into `reward_repair_log`:
* **eligible_not_credited** (referred member verified, or an approved paid enrolment / completed purchase exists): credited once, with ledger line `RWD-<id>` and a notification.
* **awaiting_verification**: left pending (credited automatically when they verify).
* **unverified_payment / invalid**: left untouched and flagged.
* **eligible_missing_reward** (approved paid classes that never got a reward because of the old group-verification rule): **not** credited automatically. They are listed for an administrator decision (*Credit missing class rewards*).
* **balance_mismatch**: wallets that disagree with their ledger are only flagged.
Nothing was deleted, no balance was reset, history is preserved.

## 7. Tests
Run `npm test`. Offline tests (no database): default policy, no earnings cap anywhere, SQL guards (atomic credit, no self-referral, attribution, verified payment required, no re-credit of reversals, amount-based message text, withdrawal rule inside the reserve statement), migration safety and statement splitting.
Database tests (`tests/rewards.integration.test.mjs`, need `TEST_DATABASE_URL`): registration reward once + notification, duplicate and self-referral blocked, unverified payment rejected, ebook reward once, reversal once and qualifying count drop, rewards well beyond ₦5,000, 2-of-3 blocked then 3 distinct allowed, concurrent withdrawals cannot overspend, admin alert created.

## 8. Status and what you must still do
* **The new SQL has not been executed against a real database in the build environment** (no Postgres was available). The offline tests check the statements' structure only. Run migration `005`, then `TEST_DATABASE_URL=… npm test` on a disposable Neon branch before going live.
* Not covered by tests: a paid training enrolment end to end (needs an admin session and training fixtures) and the browser screens for the new admin tabs.
* No bank-account verification provider is connected: bank details are format-checked only (the member screen says so). Adding Paystack/Flutterwave name resolution needs your API key.
* Decision points you can change: wallet-funded purchases do not count as paid referrals and earn no reward; registration rewards are credited immediately after email verification (the old 24-hour review period is gone, which removes a fraud check); the minimum number of qualifying referrals cannot be set below 3.
