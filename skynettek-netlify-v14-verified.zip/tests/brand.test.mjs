// SN Learning Platform: brand, launch screen, PWA and palette checks. Dependency-free: `node --test tests/brand.test.mjs`
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const pub = p => path.join('public', p);
const read = p => fs.readFileSync(pub(p), 'utf8');
const png = p => { const b = fs.readFileSync(pub(p)); assert.equal(b.toString('latin1', 1, 4), 'PNG', p + ' is a PNG'); return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), alpha: b[25] === 6 }; };
const htmlFiles = fs.readdirSync('public').filter(f => f.endsWith('.html'));
const jsFiles = fs.readdirSync('public/assets/js').map(f => 'assets/js/' + f);

test('SN icon: source kept untouched and derivatives have the expected sizes', () => {
  assert.deepEqual([png('assets/img/sn-icon-source.png').w, png('assets/img/sn-icon-source.png').h], [1254, 1254], 'original upload preserved');
  assert.deepEqual(Object.values(png('assets/img/icon-192.png')).slice(0, 2), [192, 192]);
  assert.deepEqual(Object.values(png('assets/img/icon-512.png')).slice(0, 2), [512, 512]);
  assert.deepEqual(Object.values(png('assets/img/icon-maskable-512.png')).slice(0, 2), [512, 512]);
  assert.deepEqual(Object.values(png('assets/img/apple-touch-icon.png')).slice(0, 2), [180, 180]);
  assert.equal(png('assets/img/sn-icon.png').w, png('assets/img/sn-icon.png').h, 'master derivative is square (no distortion)');
  assert.ok(png('assets/img/sn-icon.png').alpha, 'master derivative has transparent corners');
});

test('manifest names the app SN Learning Platform and every icon exists', () => {
  const m = JSON.parse(read('manifest.webmanifest'));
  assert.equal(m.name, 'SN Learning Platform');
  assert.equal(m.display, 'standalone');
  assert.equal(m.start_url, '/');
  assert.match(m.theme_color, /^#071A3D$/i);
  for (const i of m.icons) assert.ok(fs.existsSync(pub(i.src)), 'missing ' + i.src);
  assert.ok(m.icons.some(i => i.purpose === 'maskable') && m.icons.some(i => i.sizes === '512x512' && i.purpose === 'any'));
});

test('the parent-company logo files are not referenced by any page or script', () => {
  const bad = [];
  for (const f of htmlFiles) if (/sky-net-tek-(logo|mark)/.test(read(f))) bad.push(f);
  for (const f of jsFiles) if (/sky-net-tek-(logo|mark)/.test(read(f))) bad.push(f);
  assert.deepEqual(bad, []);
  assert.ok(fs.existsSync(pub('assets/img/sky-net-tek-logo.webp')), 'official asset is kept on disk, not deleted');
});

test('SPACEFX and AI Powered Workspace assets are intact and still used on their pages', () => {
  assert.ok(fs.existsSync(pub('assets/img/spacefx-logo.webp')) && fs.existsSync(pub('assets/img/ai-workspace-logo.webp')));
  assert.match(read('platforms.html'), /spacefx-logo\.webp/);
  assert.match(read('platforms.html'), /ai-workspace-logo\.webp/);
  assert.match(read('assets/js/member.js'), /spacefx-logo\.webp/);
  assert.match(read('assets/js/member.js'), /ai-workspace-logo\.webp/);
});

test('welcome screen: exact copy, one whole icon image, CSP-safe (no inline script), local assets resolve', () => {
  const h = read('index.html');
  assert.match(h, /Welcome to SN Learning Platform/);
  assert.match(h, /Learn\. Build Skills\. Grow\./);
  assert.match(h, />Sign In</); assert.match(h, />Create Account</);
  assert.equal((h.match(/id="snMark"/g) || []).length, 1, 'exactly one animated icon element');
  assert.match(h, /<img id="snMark"[^>]*sn-icon-512\.webp/);
  assert.ok(!/<script(?![^>]*\bsrc=)[^>]*>/i.test(h), 'no inline <script> (CSP is script-src self)');
  assert.ok(!/\son[a-z]+="/i.test(h), 'no inline event handlers');
  assert.match(h, /<script src="\/assets\/js\/launch-gate\.js">/);
  for (const m of h.matchAll(/(?:src|href)="(\/[^"#?]+)"/g)) if (/\.(png|webp|css|js|webmanifest)$/.test(m[1])) assert.ok(fs.existsSync(pub(m[1])), 'broken reference ' + m[1]);
});

test('launch honours reduced motion and never replays within a session', () => {
  const gate = read('assets/js/launch-gate.js'), css = read('assets/css/launch.css');
  assert.match(gate, /prefers-reduced-motion: reduce/); assert.match(gate, /sessionStorage/);
  assert.match(css, /@media\(prefers-reduced-motion:reduce\)[\s\S]*\.launch\{display:none\}/);
  assert.match(css, /snFailVeil/, 'CSS failsafe reveals the page if the script stalls');
});

test('auth screen renders the requested mode before the session check (no flash of the welcome screen on deep links)', () => {
  const a = fs.readFileSync('public/assets/js/auth.js', 'utf8');
  const first = a.indexOf("setMode(location.hash.slice(1) || 'welcome', { updateUrl: false }); // first paint");
  assert.ok(first > 0 && first < a.indexOf('const meP = whoami()'), 'initial setMode runs before the awaited session check');
});
test('authentication wiring is preserved (same endpoints, same fields, no new auth system)', () => {
  const a = read('assets/js/auth.js');
  for (const ep of ["'/auth/login'", "'/auth/register'", "'/auth/forgot'", "'/auth/resend-verification'"]) assert.ok(a.includes(ep), 'missing ' + ep);
  assert.match(a, /acceptTerms/); assert.match(a, /understandsRequirements/); assert.match(a, /b\.ref = refCode/);
  assert.match(a, /goAfterAuth/); assert.match(read('assets/js/app.js'), /requireMember/);
});

test('CSP in netlify.toml is not weakened', () => {
  const t = fs.readFileSync('netlify.toml', 'utf8');
  assert.match(t, /script-src 'self'(;|")/); assert.ok(!/script-src[^;"]*unsafe-inline/.test(t));
});

test('palette: text and control pairs meet WCAG AA (4.5:1 text, 3:1 large/UI)', () => {
  const L = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; };
  const cr = (a, b) => { const [x, y] = [L(a), L(b)].sort((p, q) => q - p); return (x + .05) / (y + .05); };
  const pairs = [['#102344', '#FFFFFF', 4.5], ['#102344', '#F4F8FD', 4.5], ['#56667F', '#FFFFFF', 4.5], ['#56667F', '#F4F8FD', 4.5], ['#56667F', '#E8F0FB', 4.5], ['#56667F', '#EEF4FC', 4.5], ['#56667F', '#F1F6FD', 4.5], ['#56667F', '#FFF9EE', 4.5], ['#1558B8', '#E8F0FB', 4.5], ['#1558B8', '#F8FBFF', 4.5], ['#FFFFFF', '#1558B8', 4.5],
    ['#1558B8', '#FFFFFF', 4.5], ['#1558B8', '#F4F8FD', 4.5], ['#FFFFFF', '#071A3D', 4.5], ['#42D8FF', '#071A3D', 4.5], ['#D7E1F0', '#071A3D', 4.5], ['#B42318', '#FFFFFF', 4.5], ['#17794A', '#FFFFFF', 4.5], ['#9A5B00', '#FFFFFF', 4.5]];
  for (const [fg, bg, min] of pairs) assert.ok(cr(fg, bg) >= min, `${fg} on ${bg} = ${cr(fg, bg).toFixed(2)}`);
});
