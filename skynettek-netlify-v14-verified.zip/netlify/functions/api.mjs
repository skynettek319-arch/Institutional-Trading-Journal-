import { json, HttpError, clientIp, parseCookies, readBody } from '../lib/http.mjs';
import { getSession } from '../lib/security.mjs';
import { ADMIN_ROLES, can } from '../lib/perms.mjs';
import * as pub from '../lib/routes/public.mjs';
import * as auth from '../lib/routes/auth.mjs';
import * as member from '../lib/routes/member.mjs';
import * as admin from '../lib/routes/admin.mjs';
import * as training from '../lib/routes/training.mjs';
import * as questionnaires from '../lib/routes/questionnaires.mjs';
import * as social from '../lib/routes/social.mjs';
import * as chat from '../lib/routes/chat.mjs';
import * as wallet from '../lib/routes/wallet.mjs';
import * as adminExtra from '../lib/routes/admin-extra.mjs';
import * as community from '../lib/routes/community.mjs';

const routes = [];
const r = (method, path, opts, handler) => {
  if (typeof opts === 'function') { handler = opts; opts = {}; }
  const keys = [];
  const re = new RegExp('^' + path.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, opts, handler });
};
[pub, auth, member, admin, training, questionnaires, social, chat, wallet, adminExtra, community].forEach(m => m.register(r));

export async function handle(req) {
  try {
    const url = new URL(req.url);
    const path = url.pathname.replace(/^\/api/, '') || '/';
    if (!['GET', 'HEAD'].includes(req.method)) {
      // CSRF: custom header cannot be sent cross-site without CORS preflight; cookies are SameSite=Strict as well.
      if (req.headers.get('x-requested-with') !== 'sky') throw new HttpError(403, 'Invalid request');
      const origin = req.headers.get('origin');
      if (origin && new URL(origin).host !== url.host) throw new HttpError(403, 'Invalid origin');
    }
    const route = routes.find(x => x.method === req.method && x.re.test(path));
    if (!route) throw new HttpError(404, 'Not found');
    const m = path.match(route.re);
    const params = {};
    route.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
    const ctx = { req, url, params, ip: clientIp(req), q: url.searchParams, cookies: parseCookies(req) };
    ctx.body = () => readBody(req);
    const o = route.opts;
    if (o.auth === 'member') {
      const s = await getSession(ctx.cookies.sid, 'member');
      if (!s || s.role !== 'member') throw new HttpError(401, 'Please sign in');
      ctx.user = s;
    } else if (o.auth === 'admin') {
      const s = await getSession(ctx.cookies.asid, 'admin');
      if (!s || !ADMIN_ROLES.includes(s.role)) throw new HttpError(401, 'Administrator sign-in required');
      if (o.perm && !can(s.role, o.perm)) throw new HttpError(403, 'You do not have permission for this action');
      if (o.reauth) admin.needReauth(s);
      ctx.admin = s;
    } else if (o.auth === 'pending') {
      const s = await getSession(ctx.cookies.apsid, 'admin_pending');
      if (!s || !ADMIN_ROLES.includes(s.role)) throw new HttpError(401, 'Please sign in again');
      ctx.pending = s;
    } else if (o.auth === 'adminOrPending') {
      const a = await getSession(ctx.cookies.asid, 'admin');
      if (a && ADMIN_ROLES.includes(a.role)) { ctx.admin = a; ctx.actor = a; }
      else {
        const s = await getSession(ctx.cookies.apsid, 'admin_pending');
        if (!s || !ADMIN_ROLES.includes(s.role)) throw new HttpError(401, 'Please sign in again');
        ctx.pending = s; ctx.actor = s;
      }
    }
    return await route.handler(ctx);
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.message, ...(e.extra || {}) }, e.status);
    console.error('[api]', e);
    return json({ error: 'Something went wrong. Please try again.' }, 500);
  }
}
export default handle;
export const config = { path: '/api/*' };
