// Scheduled safety net (every 10 minutes): retries failed reward credits, heals any reward a crash may have skipped,
// releases registration rewards whose only condition (email verified) is now met, and checks that balances match the ledger.
// Everything it does is idempotent, so running it twice can never double-credit.
import { runRewardMaintenance } from '../lib/wallet.mjs';

export default async () => {
  try {
    const out = await runRewardMaintenance();
    return new Response(JSON.stringify({ ok: true, ...out }), { headers: { 'content-type': 'application/json' } });
  } catch (e) {
    console.error('rewards-reconcile failed:', String(e?.message || e).slice(0, 200));
    return new Response(JSON.stringify({ ok: false }), { status: 500 });
  }
};
export const config = { schedule: '*/10 * * * *' };
