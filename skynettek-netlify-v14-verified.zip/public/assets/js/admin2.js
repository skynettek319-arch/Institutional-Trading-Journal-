import { $, $$, adminApi, esc, msg, clearMsg, busy, modal, confirmBox, adminLayout, badge, fmtDate } from './app.js';

const page = document.body.dataset.page;
const naira = n => '₦' + Number(n || 0).toLocaleString('en-NG');
const has = (me, p) => me.perms.includes('*') || me.perms.includes(p);
const download = async (path, name) => { const r = await adminApi(path); const b = await r.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); a.remove(); };

// ============================== Questionnaires: list, publish/draft, responses, export ==============================
async function aquestionnaires() {
  const me = await adminLayout(); if (!me) return;
  const M = $('#am'), canRead = has(me, 'questionnaires:read'), canWrite = has(me, 'questionnaires:write');
  async function load() {
    const d = await adminApi('/admin/questionnaires');
    $('#aout').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Questionnaire</th><th>Content</th><th>Questions</th><th>Submitted</th><th>In progress</th><th>Status</th><th></th></tr></thead><tbody>${d.items.map(i => `<tr><td><strong>${esc(i.title)}</strong><br><span class="small muted">${esc(i.audience)}</span></td>
      <td>${i.contentStatus === 'original' ? '<span class="status-tag s-completed">Original</span>' : '<span class="status-tag s-draft">Draft content</span>'}<br><span class="small muted">${i.mode === 'engine' ? 'Step-by-step form' : 'Part of sign-up'}</span></td><td>${i.questions}</td><td>${i.submitted}</td><td>${i.drafts}</td>
      <td>${i.mode === 'engine' && !i.internal && !i.retired && canWrite ? `<select data-st="${i.slug}" aria-label="Status of ${esc(i.title)}"><option value="published" ${i.status === 'published' ? 'selected' : ''}>Published</option><option value="draft" ${i.status === 'draft' ? 'selected' : ''}>Hidden (draft)</option></select>` : i.retired ? '<span class="status-tag s-draft">Retired (members no longer see it)</span>' : badge(i.status)}</td>
      <td style="white-space:nowrap">${canRead ? `<button class="btn btn-outline btn-sm" data-r="${i.slug}">Responses</button> <button class="btn btn-outline btn-sm" data-x="${i.slug}">Export CSV</button>` : ''}</td></tr>`).join('')}</tbody></table></div>
      <p class="small muted">"Draft content" means the questions were written as a first version and should be reviewed before you rely on the results. Hidden questionnaires are not shown to members.</p>`;
    $$('[data-st]').forEach(s => s.onchange = async () => { try { await adminApi(`/admin/questionnaires/${s.dataset.st}/status`, { method: 'PUT', body: { status: s.value } }); msg(M, 'Status updated.', 'success'); } catch (e) { msg(M, e.message); load(); } });
    $$('[data-x]').forEach(b => b.onclick = () => busy(b, async () => { try { await download(`/admin/questionnaires/${b.dataset.x}/export`, `questionnaire-${b.dataset.x}.csv`); } catch (e) { msg(M, e.message); } }));
    $$('[data-r]').forEach(b => b.onclick = () => responses(b.dataset.r, d.items.find(x => x.slug === b.dataset.r)));
  }
  async function responses(slug, item) {
    let pg = 0;
    $('#resp').innerHTML = `<h2 style="margin-top:2rem;font-size:1.3rem">${esc(item.title)}: responses</h2><form id="rf" class="toolbar"><div class="field"><label for="rq">Search name or email</label><input id="rq" type="search" maxlength="80"></div><div class="field"><label for="rst">Status</label><select id="rst"><option value="">All</option><option value="submitted">Submitted</option><option value="draft">In progress</option></select></div><button class="btn btn-primary btn-sm" type="submit">Filter</button></form><div id="rt"></div><div class="pager" id="rp"></div>`;
    const go = async () => {
      try {
        const d = await adminApi(`/admin/questionnaires/${slug}/responses?page=${pg}&status=${$('#rst').value}&q=${encodeURIComponent($('#rq').value)}`);
        $('#rt').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Member</th><th>Status</th><th>Date</th><th>Result</th><th></th></tr></thead><tbody>${d.rows.map(r => `<tr><td>${esc(r.full_name || '')}<br><span class="small muted">${esc(r.email)}</span></td><td>${badge(r.status === 'submitted' ? 'completed' : 'in_progress')}</td><td>${fmtDate(r.submitted_at || r.updated_at)}</td><td>${r.result ? r.result.percent + '% · ' + esc(r.result.band) : '—'}</td><td><button class="btn btn-outline btn-sm" data-v="${r.user_id}">View</button></td></tr>`).join('') || '<tr><td colspan="5" class="muted">No responses.</td></tr>'}</tbody></table></div>`;
        $('#rp').innerHTML = `${pg > 0 ? '<button class="btn btn-outline btn-sm" id="pp">Previous</button>' : ''}<span class="small muted">Page ${pg + 1}</span>${(pg + 1) * d.pageSize < d.total ? '<button class="btn btn-outline btn-sm" id="pn">Next</button>' : ''}`;
        $('#pp')?.addEventListener('click', () => { pg--; go(); }); $('#pn')?.addEventListener('click', () => { pg++; go(); });
        $$('[data-v]').forEach(b => b.onclick = async () => { try { const x = await adminApi(`/admin/questionnaires/${slug}/responses/${b.dataset.v}`);
          const m = modal(`<h2>${esc(x.questionnaire.title)}</h2><p><strong>${esc(x.member?.full_name || '')}</strong> · ${esc(x.member?.email || '')}</p>${x.meta?.result ? `<p>Result: ${x.meta.result.percent}% · ${esc(x.meta.result.band)}</p>` : ''}<ul class="review-list">${x.items.map(i => `<li><b>${esc(i.label)}</b>${esc(Array.isArray(i.answer) ? i.answer.join(', ') : String(i.answer))}${i.other ? ' (' + esc(i.other) + ')' : ''}</li>`).join('')}</ul><div class="actions"><button class="btn btn-outline" id="cx">Close</button></div>`); $('#cx', m).onclick = () => m.close(); } catch (e) { msg(M, e.message); } });
      } catch (e) { msg(M, e.message); }
    };
    $('#rf').onsubmit = e => { e.preventDefault(); pg = 0; go(); }; go(); $('#resp').scrollIntoView({ behavior: 'smooth' });
  }
  try { await load(); } catch (e) { msg(M, e.message); }
}

// ============================== Ebook store ==============================
async function astore() {
  const me = await adminLayout(); if (!me) return;
  const M = $('#am');
  async function load() {
    const d = await adminApi('/admin/store');
    $('#aout').innerHTML = d.ebooks.map(e => `<form class="card" data-e="${e.id}" style="margin-bottom:1rem"><h2 style="font-size:1.15rem">${esc(e.title)} ${e.published ? badge('published') : badge('draft')}</h2><div class="kv"><span>Sold with wallet: <b>${e.sold}</b></span><span>File: <b>${e.has_file ? esc(e.file_name || 'uploaded') + ' (' + Math.round((e.file_size || 0) / 1048576 * 10) / 10 + ' MB)' : 'none'}</b></span></div>
      <div class="row"><div class="field"><label>Title</label><input name="title" value="${esc(e.title)}" maxlength="200" required></div><div class="field"><label>Wallet price (₦) <span class="optional">(empty = Selar only)</span></label><input name="price" type="number" min="0" step="1" value="${e.price_ngn ?? ''}"></div></div>
      <div class="field"><label>Description</label><textarea name="description" maxlength="1500">${esc(e.description || '')}</textarea></div>
      <div class="row"><div class="field"><label>Selar product link</label><input name="selar" type="url" value="${esc(e.selar_url || '')}" placeholder="https://selar.com/…"></div><div class="field"><label>Display order</label><input name="order" type="number" value="${e.sort_order}"></div></div>
      <label class="opt"><input type="checkbox" name="pub" ${e.published ? 'checked' : ''}><span>Published (visible to members)</span></label>
      <div class="field"><label>Replace ebook file (PDF or EPUB, up to 25 MB)</label><input type="file" name="file" accept=".pdf,.epub,application/pdf,application/epub+zip"><div class="hint">Stored privately. Members can only download it after buying it with their wallet.</div></div>
      <div class="msg" data-m></div><button class="btn btn-primary" type="submit">Save</button></form>`).join('') +
      `<h2 style="font-size:1.2rem;margin-top:1.6rem">Download recovery requests</h2>${d.recovery.length ? `<div class="list">${d.recovery.map(r => `<div class="item"><div class="grow"><div class="name">${esc(r.title)}</div><div class="sub">${esc(r.email)} · ${esc(r.reference)} · downloaded ${r.downloads_used}/${r.max_downloads} · asked ${fmtDate(r.recovery_requested_at)}</div></div><button class="btn btn-primary btn-sm" data-re="${r.id}">Re-enable one download</button></div>`).join('')}</div>` : '<p class="muted">No requests.</p>'}`;
    $$('[data-re]').forEach(b => b.onclick = async () => { if (!(await confirmBox('Allow one more download for this purchase? This is recorded in the audit log.'))) return; try { await adminApi(`/admin/store/purchases/${b.dataset.re}/reissue`, { method: 'POST', body: {} }); load(); } catch (e) { msg(M, e.message); } });
    $$('form[data-e]').forEach(f => f.onsubmit = async ev => {
      ev.preventDefault(); const m = $('[data-m]', f), id = f.dataset.e; clearMsg(m);
      await busy($('button[type=submit]', f), async () => {
        try {
          const file = f.elements.file.files[0];
          if (file) {
            if (file.size > 25 * 1048576) throw new Error('The file is larger than 25 MB.');
            const total = Math.ceil(file.size / (3 * 1048576)), uploadId = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(36).slice(2)).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 36);
            for (let i = 0; i < total; i++) {
              const buf = new Uint8Array(await file.slice(i * 3 * 1048576, (i + 1) * 3 * 1048576).arrayBuffer()); let bin = ''; for (let k = 0; k < buf.length; k += 8192) bin += String.fromCharCode(...buf.subarray(k, k + 8192));
              msg(m, `Uploading part ${i + 1} of ${total}…`, 'info');
              await adminApi(`/admin/store/${id}/file-chunk`, { method: 'POST', body: { uploadId, index: i, total, data: btoa(bin), fileName: file.name } });
            }
          }
          await adminApi('/admin/store/' + id, { method: 'PUT', body: { title: f.elements.title.value, description: f.elements.description.value, priceNgn: f.elements.price.value, selarUrl: f.elements.selar.value, sortOrder: f.elements.order.value, published: f.elements.pub.checked } });
          msg(m, 'Saved.', 'success'); setTimeout(load, 900);
        } catch (e) { msg(m, e.message); }
      });
    });
  }
  try { await load(); } catch (e) { msg(M, e.message); }
}

// ============================== Wallet, rewards, withdrawals ==============================
async function awallet() {
  const me = await adminLayout(); if (!me) return;
  const M = $('#am'), W = has(me, 'wallet:write'); const TABS = ['alerts', 'withdrawals', 'rewards', 'config', 'lookup', 'reconcile']; const h0 = location.hash.slice(1); let tab = TABS.includes(h0) ? h0 : 'alerts';
  const tabs = [['alerts', 'Needs attention'], ['withdrawals', 'Withdrawals'], ['rewards', 'Rewards'], ['config', 'Reward settings'], ['lookup', 'Member wallet'], ['reconcile', 'Reconciliation']];
  async function top() { const d = await adminApi('/admin/wallet/overview'), t = d.totals;
    $('#atop').innerHTML = `<div class="stats"><div class="stat"><b>${naira(t.balances)}</b><span>Total member balances</span></div><div class="stat"><b>${naira(t.pending_rewards)}</b><span>Awaiting email verification</span></div><div class="stat"><b>${naira(t.credited_rewards)}</b><span>Rewards credited</span></div><div class="stat"><b>${naira(t.reserved)}</b><span>Reserved for withdrawals</span></div><div class="stat"><b>${naira(t.paid_out)}</b><span>Paid out</span></div><div class="stat"><b>${t.open_withdrawals}</b><span>Open withdrawals</span></div><div class="stat"><b style="color:${d.mismatches ? 'var(--color-error)' : 'var(--color-success)'}">${d.mismatches}</b><span>Ledger mismatches</span></div></div>`; }
  const act = async (fn) => { try { await fn(); clearMsg(M); await top(); await draw(); } catch (e) { msg(M, e.message); } };
  async function withdrawals(out) {
    out.innerHTML = `<div class="toolbar"><div class="field"><label for="ws">Status</label><select id="ws"><option value="pending">Pending</option><option value="processing">Processing</option><option value="">All</option><option value="paid">Paid</option><option value="failed">Failed</option><option value="reversed">Reversed</option></select></div></div><div id="wl"></div>`;
    const load = async () => { const d = await adminApi('/admin/withdrawals?status=' + $('#ws').value);
      $('#wl').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Member</th><th>Amount</th><th>Bank</th><th>Status</th><th>Requested</th><th></th></tr></thead><tbody>${d.withdrawals.map(w => `<tr><td>${esc(w.full_name || '')}<br><span class="small muted">${esc(w.email)}</span></td><td><strong>${naira(w.amount)}</strong><br><span class="small muted">${esc(w.reference)}</span></td><td>${esc(w.bank_name)}<br><span class="small muted">${esc(w.account_name)} ••${esc(w.account_last4)}</span></td><td>${badge(w.status)}${w.payout_reference ? `<br><span class="small muted">Ref ${esc(w.payout_reference)}</span>` : ''}${w.failure_reason ? `<br><span class="small muted">${esc(w.failure_reason)}</span>` : ''}</td><td>${fmtDate(w.created_at)}</td>
        <td style="white-space:nowrap">${W ? `${['pending', 'processing'].includes(w.status) ? `<button class="btn btn-outline btn-sm" data-bank="${w.id}">Bank details</button> ` : ''}${w.status === 'pending' ? `<button class="btn btn-outline btn-sm" data-do="processing" data-id="${w.id}">Start</button> ` : ''}${['pending', 'processing'].includes(w.status) ? `<button class="btn btn-primary btn-sm" data-do="paid" data-id="${w.id}">Mark paid</button> <button class="btn btn-danger btn-sm" data-do="failed" data-id="${w.id}">Failed</button>` : ''}${w.status === 'paid' ? `<button class="btn btn-danger btn-sm" data-do="reversed" data-id="${w.id}">Reverse</button>` : ''}` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">Nothing here.</td></tr>'}</tbody></table></div><p class="small muted">Only mark a withdrawal paid after you have confirmed the bank transfer yourself. Failed or reversed withdrawals return the money to the member's wallet automatically.</p>`;
      $$('[data-bank]').forEach(b => b.onclick = () => act(async () => { const x = await adminApi(`/admin/withdrawals/${b.dataset.bank}/bank`); const m = modal(`<h2>Bank details</h2><p><strong>${esc(x.accountName)}</strong><br>${esc(x.bankName)}<br><span class="copy"><code>${esc(x.accountNumber)}</code></span></p><p>Amount: <strong>${naira(x.amount)}</strong><br>Reference: ${esc(x.reference)}<br>${esc(x.email)}</p><div class="actions"><button class="btn btn-outline" id="cx">Close</button></div>`); $('#cx', m).onclick = () => m.close(); }));
      $$('[data-do]').forEach(b => b.onclick = () => {
        const a = b.dataset.do, id = b.dataset.id;
        if (a === 'processing') return act(() => adminApi(`/admin/withdrawals/${id}/action`, { method: 'POST', body: { action: a } }));
        const m = modal(`<h2>${{ paid: 'Mark as paid', failed: 'Mark as failed', reversed: 'Reverse this payout' }[a]}</h2><form id="af">${a === 'paid' ? '<div class="field"><label for="pr">Bank transfer reference</label><input id="pr" required minlength="4" maxlength="120"></div><label class="opt"><input type="checkbox" id="vf"><span>I confirmed this transfer went through</span></label>' : '<div class="field"><label for="rs2">Reason (shown to the member)</label><input id="rs2" required minlength="5" maxlength="300"></div>'}<div class="msg" id="am2"></div><div class="actions"><button class="btn btn-primary" type="submit">Confirm</button><button type="button" class="btn btn-outline" id="cx">Cancel</button></div></form>`);
        $('#cx', m).onclick = () => m.close();
        $('#af', m).onsubmit = async e => { e.preventDefault(); try { await adminApi(`/admin/withdrawals/${id}/action`, { method: 'POST', body: { action: a, payoutReference: $('#pr', m)?.value, verified: $('#vf', m)?.checked === true, reason: $('#rs2', m)?.value } }); m.close(); await top(); load(); } catch (err) { msg($('#am2', m), err.message); } };
      });
    };
    $('#ws').onchange = load; await load();
  }
  async function rewards(out) {
    out.innerHTML = `<div class="toolbar"><div class="field"><label for="rw">Status</label><select id="rw"><option value="">All</option><option value="available">Credited</option><option value="pending">Waiting for verification</option><option value="failed">Failed</option><option value="reversed">Reversed</option></select></div></div><div id="rl"></div>`;
    const load = async () => { const d = await adminApi('/admin/rewards?status=' + $('#rw').value);
      $('#rl').innerHTML = `<div class="table-wrap"><table><thead><tr><th>Referrer</th><th>Referred member</th><th>Event</th><th>Amount</th><th>Status</th><th></th></tr></thead><tbody>${d.rewards.map(r => `<tr><td>${esc(r.referrer_email)}</td><td>${esc(r.referred_email)}</td><td>${esc(r.event)}<br><span class="small muted">${fmtDate(r.created_at)}</span></td><td>${naira(r.amount)}</td><td>${badge(r.status)}${r.status === 'pending' ? `<br><span class="small muted">Releases ${fmtDate(r.release_at)}</span>` : ''}${r.pending_reason ? `<br><span class="small muted">${esc(r.pending_reason)}</span>` : ''}${r.note ? `<br><span class="small muted">${esc(r.note)}</span>` : ''}</td><td style="white-space:nowrap">${W && r.status !== 'reversed' ? `<button class="btn btn-danger btn-sm" data-rev="${r.id}">Reverse</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">No rewards.</td></tr>'}</tbody></table></div>`;
      $$('[data-rev]').forEach(b => b.onclick = () => { const m = modal(`<h2>Reverse this reward</h2><form id="af"><div class="field"><label for="rs2">Reason</label><input id="rs2" required minlength="8" maxlength="300"></div><div class="msg" id="am2"></div><div class="actions"><button class="btn btn-danger" type="submit">Reverse</button><button type="button" class="btn btn-outline" id="cx">Cancel</button></div></form>`); $('#cx', m).onclick = () => m.close(); $('#af', m).onsubmit = async e => { e.preventDefault(); try { await adminApi(`/admin/rewards/${b.dataset.rev}/reverse`, { method: 'POST', body: { reason: $('#rs2', m).value } }); m.close(); await top(); load(); } catch (err) { msg($('#am2', m), err.message); } }; });
    };
    $('#rw').onchange = load; await load();
  }
  async function alerts(out) {
    const d = await adminApi('/admin/alerts');
    out.innerHTML = (d.alerts.length ? `<div class="list">${d.alerts.map(a => `<div class="item" style="align-items:flex-start"><div class="grow"><div class="name">${esc(a.title)}</div><div class="sub" style="white-space:pre-line">${esc(a.body)}</div><div class="small muted">${fmtDate(a.created_at)}${a.link ? ` · <a href="${esc(a.link)}">Open</a>` : ''}</div></div>${W && !a.resolved_at ? `<button class="btn btn-outline btn-sm" data-res="${a.id}">Done</button>` : ''}</div>`).join('')}</div>` : '<p class="muted">Nothing needs your attention. Rewards, balances and notifications are running automatically.</p>')
      + (W ? '<div class="actions" style="margin-top:1rem"><button class="btn btn-outline btn-sm" id="runjob">Run reward check now</button></div>' : '');
    $$('[data-res]').forEach(b => b.onclick = () => act(() => adminApi(`/admin/alerts/${b.dataset.res}/resolve`, { method: 'POST', body: {} })));
    $('#runjob')?.addEventListener('click', () => act(async () => { const r = await adminApi('/admin/rewards/run', { method: 'POST', body: {} }); msg(M, `Check finished. Retried ${r.retried}, healed ${r.healed}, released ${r.released}, balance mismatches ${r.mismatches}.`, 'success'); }));
  }
  async function config(out) {
    const d = await adminApi('/admin/rewards/config'), c = d.config, log = await adminApi('/admin/rewards/repair-log');
    const f = (k, l) => `<div class="field"><label for="c-${k}">${l}</label><input id="c-${k}" type="number" min="0" step="1" value="${c[k]}" ${W ? '' : 'disabled'} required></div>`;
    out.innerHTML = `<form id="cf" class="card"><h2 style="font-size:1.1rem">Reward amounts and withdrawal rules</h2><p class="small muted">There is no cap on lifetime earnings. Changes apply to future rewards only.</p>
      <div class="row">${f('registration', 'Registration reward (₦)')}${f('class', 'Paid class reward (₦)')}${f('ebook', 'Forex ebook reward (₦)')}</div>
      <div class="row">${f('min_withdrawal', 'Minimum withdrawal (₦, at least 1,000)')}${f('qualifying_required', 'Qualifying paid referrals needed to withdraw (at least 3)')}</div>
      <div class="msg" id="cm"></div>${W ? '<button class="btn btn-primary" type="submit">Save settings</button>' : ''}</form>
      <h2 style="font-size:1.1rem;margin-top:1.6rem">Repair history</h2><p class="small muted">What the automatic repair did with old Pending rewards, and the evidence used.</p>
      ${W && log.items.some(x => x.action === 'needs_decision') ? '<div class="actions"><button class="btn btn-outline btn-sm" id="bf">Credit missing class rewards (approved real payments only)</button></div>' : ''}
      <div class="table-wrap"><table><thead><tr><th>Result</th><th>Action</th><th>Amount</th><th>Evidence</th></tr></thead><tbody>${log.items.map(x => `<tr><td>${esc(x.classification.replaceAll('_', ' '))}</td><td>${esc(x.action.replaceAll('_', ' '))}</td><td>${x.amount ? naira(x.amount) : ''}</td><td class="small">${esc(x.evidence || '')}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No records.</td></tr>'}</tbody></table></div>`;
    $('#cf').onsubmit = async e => { e.preventDefault(); const body = {}; for (const k of Object.keys(c)) body[k] = $('#c-' + k).value; try { await adminApi('/admin/rewards/config', { method: 'PUT', body }); msg($('#cm'), 'Saved.', 'success'); } catch (err) { msg($('#cm'), err.message); } };
    $('#bf')?.addEventListener('click', async () => { if (!(await confirmBox('Credit the missing class rewards now? Only approved real payments are credited, and each is credited once.'))) return; act(async () => { const r = await adminApi('/admin/rewards/backfill', { method: 'POST', body: {} }); msg(M, `Credited ${r.credited}. Not eligible: ${r.notEligible}.`, 'success'); }); });
  }
  async function lookup(out) {
    out.innerHTML = `<form id="lf" class="toolbar"><div class="field" style="flex:1;min-width:220px"><label for="le">Member email</label><input id="le" type="email" required></div><button class="btn btn-primary" type="submit">Look up</button></form><div id="lr"></div>`;
    $('#lf').onsubmit = async e => { e.preventDefault(); try { const d = await adminApi('/admin/wallet/lookup?email=' + encodeURIComponent($('#le').value)); const s = d.summary;
      $('#lr').innerHTML = `<h2 style="font-size:1.15rem">${esc(d.member.full_name || '')} · ${esc(d.member.email)}</h2><div class="stats"><div class="stat"><b>${naira(s.balance)}</b><span>Available</span></div><div class="stat"><b>${naira(s.pending)}</b><span>Pending rewards</span></div><div class="stat"><b>${naira(s.reserved)}</b><span>Reserved</span></div><div class="stat"><b>${naira(s.withdrawn)}</b><span>Withdrawn</span></div></div>
        ${W ? `<form id="ad" class="card"><h3>Manual adjustment</h3><p class="small muted">Credits and debits are permanent ledger entries and are recorded in the audit log with your name.</p><div class="row"><div class="field"><label for="am1">Amount (₦, negative to debit)</label><input id="am1" type="number" step="1" required></div><div class="field"><label for="ar">Reason</label><input id="ar" required minlength="8" maxlength="300"></div></div><div class="msg" id="adm"></div><button class="btn btn-primary" type="submit">Apply adjustment</button></form>` : ''}
        <h3 style="margin-top:1.4rem">Latest ledger entries</h3><div class="list">${d.ledger.map(t => `<div class="item"><div class="grow"><div class="name">${esc(t.kind)}</div><div class="sub">${esc(t.description || '')} · ${esc(t.reference)} · ${fmtDate(t.created_at)}</div></div><span class="amt ${t.amount > 0 ? 'pos' : 'neg'}">${t.amount > 0 ? '+' : '−'}${naira(Math.abs(t.amount))}</span></div>`).join('') || '<p class="muted" style="padding:1rem">No entries.</p>'}</div>`;
      $('#ad')?.addEventListener('submit', async ev => { ev.preventDefault(); const amount = Number($('#am1').value); if (!(await confirmBox(`Apply ${amount > 0 ? 'a credit' : 'a debit'} of ${naira(Math.abs(amount))} to ${d.member.email}?`))) return; try { await adminApi('/admin/wallet/adjust', { method: 'POST', body: { email: d.member.email, amount, reason: $('#ar').value } }); msg($('#adm'), 'Adjustment applied.', 'success'); await top(); $('#lf').requestSubmit(); } catch (err) { msg($('#adm'), err.message); } });
    } catch (err) { msg(M, err.message); } };
  }
  async function reconcile(out) { const d = await adminApi('/admin/wallet/reconcile'); out.innerHTML = d.mismatches.length ? `<div class="notice bad">These wallets do not match their ledger. Do not edit balances by hand; investigate each one.</div><div class="table-wrap"><table><thead><tr><th>Member id</th><th>Balance</th><th>Ledger total</th></tr></thead><tbody>${d.mismatches.map(m => `<tr><td class="small">${esc(m.user_id)}</td><td>${naira(m.balance)}</td><td>${naira(m.ledger)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="notice ok"><strong>All wallets match their ledger.</strong> Every balance equals the sum of its recorded transactions.</div>'; }
  async function draw() {
    $('#atabs').innerHTML = tabs.map(([k, t]) => `<button role="tab" data-t="${k}" aria-selected="${k === tab}">${t}</button>`).join('');
    $$('#atabs button').forEach(b => b.onclick = () => { tab = b.dataset.t; clearMsg(M); draw(); });
    const out = $('#aout'); out.innerHTML = '<p class="muted"><span class="spinner"></span></p>';
    try { await ({ alerts, withdrawals, rewards, config, lookup, reconcile })[tab](out); } catch (e) { out.innerHTML = ''; msg(M, e.message); }
  }
  try { await top(); await draw(); } catch (e) { msg(M, e.message); }
}

// ============================== Reports and moderation ==============================
async function amoderation() {
  const me = await adminLayout(); if (!me) return;
  const M = $('#am'), canAct = has(me, 'moderation:write'), canSuspend = has(me, 'members:write');
  const load = async () => {
    try {
      const d = await adminApi('/admin/reports?status=' + $('#rs').value);
      $('#aout').innerHTML = d.reports.length ? `<div class="list">${d.reports.map(r => `<div class="item" style="align-items:flex-start;flex-wrap:wrap"><div class="grow"><div class="name">${esc(r.reason)} · ${badge(r.status === 'open' ? 'pending' : r.status === 'dismissed' ? 'closed' : r.status === 'actioned' ? 'completed' : 'processing')}</div>
        <div class="sub" style="white-space:normal">Reported: ${esc(r.reported_email)} (@${esc(r.reported_username || '')}) · by ${esc(r.reporter_email)} · ${fmtDate(r.created_at)}</div>${r.message_snapshot ? `<blockquote style="margin:.5rem 0;padding:.5rem .8rem;border-left:3px solid var(--color-accent);background:var(--color-surface)">${esc(r.message_snapshot)}</blockquote>` : ''}${r.details ? `<div class="small">${esc(r.details)}</div>` : ''}${r.resolution ? `<div class="small muted">Resolution: ${esc(r.resolution)}</div>` : ''}</div>
        ${canAct && ['open', 'reviewing'].includes(r.status) ? `<button class="btn btn-primary btn-sm" data-a="${r.id}">Take action</button>` : ''}</div>`).join('')}</div>` : '<p class="muted">No reports.</p>';
      $$('[data-a]').forEach(b => b.onclick = () => {
        const m = modal(`<h2>Review report</h2><form id="af"><div class="field"><label for="st">Outcome</label><select id="st"><option value="reviewing">Keep reviewing</option><option value="actioned">Action taken</option><option value="dismissed">Dismiss (no violation)</option></select></div><div class="field"><label for="rn">Note (kept in the audit trail)</label><input id="rn" required minlength="3" maxlength="500"></div>${canSuspend ? '<label class="opt"><input type="checkbox" id="sp"><span>Suspend the reported member\'s account</span></label>' : ''}<div class="msg" id="am2"></div><div class="actions"><button class="btn btn-primary" type="submit">Save</button><button type="button" class="btn btn-outline" id="cx">Cancel</button></div></form>`);
        $('#cx', m).onclick = () => m.close();
        $('#af', m).onsubmit = async e => { e.preventDefault(); try { await adminApi(`/admin/reports/${b.dataset.a}/action`, { method: 'POST', body: { status: $('#st', m).value, resolution: $('#rn', m).value, suspend: $('#sp', m)?.checked === true } }); m.close(); load(); } catch (err) { msg($('#am2', m), err.message); } };
      });
    } catch (e) { msg(M, e.message); }
  };
  $('#rs').onchange = load; load();
}

await ({ aquestionnaires, astore, awallet, amoderation }[page])?.();
