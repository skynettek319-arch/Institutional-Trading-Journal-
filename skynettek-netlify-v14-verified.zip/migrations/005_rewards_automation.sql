-- 005: automatic rewards, qualifying-referral rule for withdrawals, admin alerts, and an evidence-based repair of old Pending rewards.
-- No lifetime earnings cap exists anywhere in this schema. Nothing here deletes or rewrites history: the ledger stays append-only.
ALTER TABLE referral_rewards DROP CONSTRAINT IF EXISTS referral_rewards_status_check;
ALTER TABLE referral_rewards ADD CONSTRAINT referral_rewards_status_check CHECK (status IN ('pending','available','reversed','failed'));
ALTER TABLE referral_rewards ADD COLUMN IF NOT EXISTS pending_reason text;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS dedupe_key text;
CREATE UNIQUE INDEX IF NOT EXISTS notifications_dedupe_idx ON notifications (dedupe_key) WHERE dedupe_key IS NOT NULL;
CREATE TABLE IF NOT EXISTS reward_config (
  key text PRIMARY KEY,
  value int NOT NULL CHECK (value >= 0),
  updated_by uuid REFERENCES users(id),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO reward_config(key,value) VALUES ('registration',100),('class',200),('ebook',200),('min_withdrawal',1000),('qualifying_required',3),('policy_start_epoch', extract(epoch from now())::int) ON CONFLICT (key) DO NOTHING;
CREATE TABLE IF NOT EXISTS reward_retries (
  id bigserial PRIMARY KEY,
  event text NOT NULL,
  source_id text NOT NULL,
  referrer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount int NOT NULL,
  attempts int NOT NULL DEFAULT 1,
  last_error text,
  next_attempt_at timestamptz NOT NULL DEFAULT now() + interval '5 minutes',
  done_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (event, source_id)
);
CREATE TABLE IF NOT EXISTS admin_alerts (
  id bigserial PRIMARY KEY,
  kind text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  link text,
  dedupe_key text UNIQUE,
  resolved_at timestamptz,
  resolved_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS admin_alerts_open_idx ON admin_alerts (created_at DESC) WHERE resolved_at IS NULL;
CREATE TABLE IF NOT EXISTS reward_repair_log (
  id bigserial PRIMARY KEY,
  reward_id uuid,
  user_id uuid,
  event text,
  amount int,
  classification text NOT NULL,
  evidence text,
  action text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE OR REPLACE VIEW qualifying_referrals_v AS
SELECT p.referred_by AS referrer_id, x.user_id AS referred_id, x.product, x.payment_reference, x.source, x.source_id, x.verified_at
FROM (
  SELECT e.user_id, t.title AS product, e.payment_reference, 'class'::text AS source, e.id::text AS source_id, e.updated_at AS verified_at
  FROM enrollments e JOIN trainings t ON t.id = e.training_id
  WHERE e.status = 'approved' AND e.paid_with IS DISTINCT FROM 'wallet'
    AND EXISTS (SELECT 1 FROM training_payments tp WHERE tp.enrollment_id = e.id AND tp.status = 'approved')
  UNION ALL
  SELECT pp.user_id, 'Forex trading ebook'::text, pp.order_ref, 'ebook_proof'::text, pp.id::text, COALESCE(pp.decided_at, pp.created_at)
  FROM purchase_proofs pp WHERE pp.status = 'approved'
) x
JOIN user_profiles p ON p.user_id = x.user_id
JOIN users u ON u.id = x.user_id AND u.status = 'active'
WHERE p.referred_by IS NOT NULL AND p.referred_by <> x.user_id;
INSERT INTO wallets(user_id) SELECT DISTINCT referrer_id FROM referral_rewards ON CONFLICT (user_id) DO NOTHING;
INSERT INTO reward_repair_log(reward_id,user_id,event,amount,classification,evidence,action)
SELECT r.id, r.referrer_id, r.event, r.amount,
  CASE
    WHEN ru.id IS NULL OR ru.status <> 'active' THEN 'invalid_needs_investigation'
    WHEN r.event = 'registration' AND ru.email_verified THEN 'eligible_not_credited'
    WHEN r.event = 'registration' THEN 'awaiting_verification'
    WHEN r.event = 'class' AND EXISTS (SELECT 1 FROM enrollments e WHERE e.id::text = r.source_id AND e.status = 'approved'
         AND (e.paid_with = 'wallet' OR EXISTS (SELECT 1 FROM training_payments tp WHERE tp.enrollment_id = e.id AND tp.status = 'approved'))) THEN 'eligible_not_credited'
    WHEN r.event = 'ebook' AND EXISTS (SELECT 1 FROM ebook_purchases pu WHERE pu.id::text = r.source_id AND pu.status = 'completed') THEN 'eligible_not_credited'
    ELSE 'unverified_payment'
  END,
  CASE
    WHEN ru.id IS NULL OR ru.status <> 'active' THEN 'referred member missing or not active'
    WHEN r.event = 'registration' AND ru.email_verified THEN 'referred member verified their email'
    WHEN r.event = 'registration' THEN 'referred member has not verified their email yet'
    WHEN r.event IN ('class','ebook') THEN 'checked the payment or purchase record for source ' || r.source_id
    ELSE 'no evidence'
  END,
  'none'
FROM referral_rewards r LEFT JOIN users ru ON ru.id = r.referred_id
WHERE r.status = 'pending' AND NOT EXISTS (SELECT 1 FROM reward_repair_log l WHERE l.reward_id = r.id);
UPDATE reward_repair_log SET action = CASE WHEN classification = 'eligible_not_credited' THEN 'credit' WHEN classification = 'awaiting_verification' THEN 'left_pending' ELSE 'flagged_for_admin' END WHERE action = 'none';
WITH due AS (
  UPDATE referral_rewards r SET status = 'available', available_at = now(), pending_reason = NULL
  FROM reward_repair_log l
  WHERE l.reward_id = r.id AND l.action = 'credit' AND r.status = 'pending'
    AND NOT EXISTS (SELECT 1 FROM wallet_ledger x WHERE x.reference = 'RWD-' || r.id::text)
  RETURNING r.id, r.referrer_id, r.amount, r.event),
tot AS (SELECT referrer_id, SUM(amount)::int AS total FROM due GROUP BY referrer_id),
bal AS (UPDATE wallets w SET balance = w.balance + tot.total, updated_at = now() FROM tot WHERE w.user_id = tot.referrer_id RETURNING w.user_id),
led AS (INSERT INTO wallet_ledger(user_id,kind,amount,reference,idempotency_key,description,related_type,related_id)
  SELECT d.referrer_id, 'referral_reward', d.amount, 'RWD-' || d.id::text, 'reward:' || d.id::text, 'Referral reward (' || d.event || ')', 'referral_reward', d.id::text FROM due d RETURNING id),
nt AS (INSERT INTO notifications(user_id,title,body,dedupe_key)
  SELECT d.referrer_id, 'Reward added to your balance', '₦' || to_char(d.amount, 'FM999,999,999') || ' from a referral has been added to your available balance.', 'reward:' || d.id::text FROM due d ON CONFLICT DO NOTHING RETURNING id)
UPDATE reward_repair_log l SET action = 'credited' FROM due d WHERE l.reward_id = d.id;
INSERT INTO reward_repair_log(user_id,event,amount,classification,evidence,action)
SELECT p.referred_by, 'class', 200, 'eligible_missing_reward', 'approved paid enrollment ' || e.id::text || ' has no reward row (the old rule also required group verification)', 'needs_decision'
FROM enrollments e JOIN user_profiles p ON p.user_id = e.user_id
WHERE e.status = 'approved' AND p.referred_by IS NOT NULL
  AND (e.paid_with = 'wallet' OR EXISTS (SELECT 1 FROM training_payments tp WHERE tp.enrollment_id = e.id AND tp.status = 'approved'))
  AND NOT EXISTS (SELECT 1 FROM referral_rewards r WHERE r.event = 'class' AND r.source_id = e.id::text)
  AND NOT EXISTS (SELECT 1 FROM reward_repair_log l WHERE l.classification = 'eligible_missing_reward' AND l.evidence LIKE '%' || e.id::text || '%');
INSERT INTO reward_repair_log(user_id,classification,evidence,action)
SELECT w.user_id, 'balance_mismatch', 'wallet balance ' || w.balance || ' but ledger total ' || COALESCE(SUM(l.amount), 0), 'flagged_for_admin'
FROM wallets w LEFT JOIN wallet_ledger l ON l.user_id = w.user_id GROUP BY w.user_id, w.balance HAVING w.balance <> COALESCE(SUM(l.amount), 0);
INSERT INTO admin_alerts(kind,title,body,link,dedupe_key)
SELECT 'repair', 'Rewards repair needs a look', (SELECT count(*) FROM reward_repair_log WHERE action IN ('flagged_for_admin','needs_decision'))::text || ' reward records were flagged during the repair. Open Rewards for the list.', '/admin-wallet.html#rewards', 'repair:005'
WHERE EXISTS (SELECT 1 FROM reward_repair_log WHERE action IN ('flagged_for_admin','needs_decision'))
ON CONFLICT DO NOTHING
