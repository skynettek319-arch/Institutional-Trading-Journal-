# Test report

Generated in a sandbox with no network, no Neon database, no Netlify and no email provider.

## Passed (verified here)
* `node --check` on every JS file (server, scripts, browser, tests).
* `tests/unit.test.mjs`: 7 of 7 pass (email/phone/password rules, image magic-byte validation rejects PHP/SVG/script disguised as images, Selar URL host allow-list, UUID guard, questionnaire validation drops unknown keys, role permission matrix).
* All internal links and image paths across 33 pages resolve.
* No inline scripts in any page (compatible with the strict CSP in `netlify.toml`).

## Written but NOT run (run these after `npm install`)
* `tests/access.test.mjs` (no database needed): CSRF header required; cross-origin refused; anonymous requests to member, invitation and every admin endpoint return 401.
* `tests/integration.test.mjs` (needs `TEST_DATABASE_URL` on a disposable Neon branch): invitation refused before approval, refused when only a status flag was flipped, released only to the approved member; members cannot reach admin APIs; invalid onboarding answers rejected.

Run: `npm test`

## Needs your environment (not verified)
| Item | How to test |
|---|---|
| Migrations on Neon | `npm run migrate`, confirm 20 tables |
| Registration, verification email, reset email | Register with a real inbox after configuring Resend |
| Google Authenticator enrolment and login | Enrol, sign out, sign in with code, try a wrong code, try a used recovery code |
| Proof upload to Netlify Blobs and admin preview | Submit a PNG, open it in the review modal, try uploading a .txt renamed .png (must be rejected) |
| Approval reveals the invitation, rejection does not | Full run through the UI with two accounts |
| Duplicate detection | Submit the same screenshot from a second account, confirm the flag |
| Role limits | Sign in as each role and confirm blocked pages return an error |
| Mobile layout | Check every page at 360 px width |
| Email alert to skynettek319@gmail.com | Submit proof and confirm delivery |
| Security headers | Check response headers on the live site |

## Known limitations
* Rate limits are database-backed per email and per IP; they are not a replacement for a CDN/WAF.
* Netlify Functions accept bodies up to about 6 MB, so proofs are capped at 4 MB.
* Selar verification is manual by design.
* The legal pages are templates and need review by a qualified lawyer.


## v2 additions: what was and was not verified
Verified in a sandbox with stubbed dependencies and a fake database: all JS files pass syntax checks, 7/7 unit tests pass, every internal link and image resolves, and 98 SQL statements were checked for placeholder and parameter consistency while exercising enrol, payment details, receipt upload (validation and acceptance), join gating before and after approval, admin create training and event, broadcasts, approve and reject rules, and that payment details are absent from public content.

NOT verified: the SQL itself against real PostgreSQL (no database available here), real Netlify Blobs and email, and visual rendering and animations in a browser. Run `npm run migrate` against a Neon test branch, then `npm test`, then click through the flows on a deploy preview before launch.


## Version 9 tests (run during the build)
- Unit tests: 15 pass (questionnaire structure, validation, scoring, privacy of answers, plus the original security tests).
- Flow tests with a stand-in database: 71 checks pass. They cover sign-in protection of every private route, friend requests (self, blocked, duplicate), chat (friends only, empty and oversized messages, retries do not duplicate, read-only after unfriending, emoji), wallet class payment, insufficient balance, lost payment race, withdrawals at ₦850, ₦999 and ₦1,000, bank details, wallet-only ebook purchase, secure download (link does not use the allowance, allowance used only after the full file is sent, tampered link refused), questionnaires (invalid answers, required answers, scoring, second submit refused) and admin money actions.
- SQL: 111 statements checked for matching placeholders and brackets, and the deep health check parses all 116 statements and checks on your real database.
- Browser rendering: 11 pages on a phone and a desktop size had no sideways scrolling, no footers and no script errors; the emoji picker inserts into the message box.

Not tested here: the SQL against a real PostgreSQL server, Netlify Blobs and bundled-file paths in production, real email, two real browsers chatting at the same time (only the server logic and the polling loop were exercised).
